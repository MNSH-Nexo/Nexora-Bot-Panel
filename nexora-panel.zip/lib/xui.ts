/**
 * lib/xui.ts — v3 (VPS-patched by installer)
 * تغییرات: redirect:manual + form-encoded fallback + session TTL + timeout 20s
 */

function getPanelConfig() {
  const url      = (process.env.PANEL_URL      ?? "").trim().replace(/\/$/, "");
  const username = (process.env.PANEL_USERNAME ?? "admin").trim();
  const password = (process.env.PANEL_PASSWORD ?? "").trim();
  return { url, username, password };
}

function withTlsBypass<T>(fn: () => Promise<T>): Promise<T> {
  const prev = process.env.NODE_TLS_REJECT_UNAUTHORIZED;
  process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
  return fn().finally(() => {
    if (prev === undefined) delete process.env.NODE_TLS_REJECT_UNAUTHORIZED;
    else process.env.NODE_TLS_REJECT_UNAUTHORIZED = prev;
  });
}

function extractCookies(res: Response): string {
  if (typeof res.headers.getSetCookie === "function") {
    const cs = res.headers.getSetCookie();
    if (cs.length > 0) return cs.map((c: string) => c.split(";")[0]).join("; ");
  }
  const s = res.headers.get("set-cookie") ?? "";
  return s ? s.split(";")[0] : "";
}

function mergeCookies(base: string, over: string): string {
  if (!base) return over;
  if (!over)  return base;
  if (base === over) return base;
  try {
    const parse = (s: string) => Object.fromEntries(
      s.split(";").map(p => { const [k,...v] = p.trim().split("="); return [k.trim(), v.join("=")] as [string,string]; })
    );
    const merged = { ...parse(base), ...parse(over) };
    return Object.entries(merged).filter(([k]) => k).map(([k,v]) => v ? `${k}=${v}` : k).join("; ");
  } catch { return over || base; }
}

function extractCsrfToken(html: string): string {
  const m = html.match(/<meta\s+name=["']csrf-token["']\s+content=["']([^"']+)["']/i)
         ?? html.match(/<meta\s+content=["']([^"']+)["']\s+name=["']csrf-token["']/i)
         ?? html.match(/csrfToken['":\s]+["']([a-zA-Z0-9_-]{20,})["']/i);
  return m?.[1] ?? "";
}

let _sessionCookie = "";
let _csrfToken     = "";
let _loggedIn      = false;
let _lastLoginAt   = 0;

function resetSession() {
  _sessionCookie = ""; _csrfToken = ""; _loggedIn = false; _lastLoginAt = 0;
}

async function fetchCsrfToken(panelUrl: string): Promise<{ cookie: string; csrf: string }> {
  return withTlsBypass(async () => {
    try {
      const res = await fetch(`${panelUrl}/`, {
        method: "GET", redirect: "manual",
        headers: { Accept: "text/html,*/*", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36", "Accept-Language": "en-US,en;q=0.9" },
        signal: AbortSignal.timeout(20_000),
      });
      const initCookie = extractCookies(res);
      if (res.status >= 300 && res.status < 400) {
        const loc = res.headers.get("location") ?? "";
        if (loc) {
          try {
            const res2 = await fetch(loc.startsWith("http") ? loc : `${panelUrl}${loc}`, {
              headers: { Accept: "text/html,*/*", "User-Agent": "Mozilla/5.0", ...(initCookie ? { Cookie: initCookie } : {}) },
              signal: AbortSignal.timeout(20_000),
            });
            const html2 = await res2.text();
            return { cookie: mergeCookies(initCookie, extractCookies(res2)), csrf: extractCsrfToken(html2) };
          } catch { /* ignore */ }
        }
      }
      const html = await res.text();
      return { cookie: initCookie, csrf: extractCsrfToken(html) };
    } catch { return { cookie: "", csrf: "" }; }
  });
}

async function performLogin(panelUrl: string, username: string, password: string, initialCookie: string, csrfToken: string): Promise<string | null> {
  return withTlsBypass(async () => {
    const base: Record<string,string> = {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Origin": panelUrl, "Referer": `${panelUrl}/`,
      ...(initialCookie ? { Cookie: initialCookie } : {}),
      ...(csrfToken     ? { "X-CSRF-Token": csrfToken } : {}),
    };

    // روش ۱: JSON
    const tryJson = async (): Promise<string | null> => {
      const res = await fetch(`${panelUrl}/login`, {
        method: "POST", redirect: "manual",
        headers: { ...base, "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({ username, password }),
        signal: AbortSignal.timeout(20_000),
      });
      const sc = extractCookies(res);
      if (sc) return mergeCookies(initialCookie, sc);
      if ((res.status >= 300 && res.status < 400) || res.ok) {
        const loc = res.headers.get("location") ?? "";
        if (loc) {
          try {
            const r2 = await fetch(loc.startsWith("http") ? loc : `${panelUrl}${loc}`, { redirect:"manual", headers:{...base, Cookie: initialCookie}, signal: AbortSignal.timeout(10_000) });
            const sc2 = extractCookies(r2);
            if (sc2) return mergeCookies(initialCookie, sc2);
          } catch { /* ignore */ }
        }
        try {
          const body = await res.text();
          if (body.includes('"success":true')) return initialCookie || null;
        } catch { /* ignore */ }
      }
      return null;
    };

    // روش ۲: form-encoded
    const tryForm = async (): Promise<string | null> => {
      const res = await fetch(`${panelUrl}/login`, {
        method: "POST", redirect: "manual",
        headers: { ...base, "Content-Type": "application/x-www-form-urlencoded", Accept: "text/html,*/*" },
        body: new URLSearchParams({ username, password }).toString(),
        signal: AbortSignal.timeout(20_000),
      });
      const sc = extractCookies(res);
      return sc ? mergeCookies(initialCookie, sc) : null;
    };

    const r1 = await tryJson();
    if (r1) return r1;
    return await tryForm();
  });
}

export async function xuiLogin(): Promise<string | null> {
  const { url, username, password } = getPanelConfig();
  if (!url || !password) return null;
  try {
    const { cookie: ic, csrf } = await fetchCsrfToken(url);
    const sc = await performLogin(url, username, password, ic, csrf);
    if (!sc) return null;
    _sessionCookie = sc; _csrfToken = csrf; _loggedIn = true; _lastLoginAt = Date.now();
    return sc;
  } catch { resetSession(); return null; }
}

async function xuiFetchWithSession(url: string, init: RequestInit = {}): Promise<Response | null> {
  if (!_loggedIn || (Date.now() - _lastLoginAt) > 30 * 60 * 1000) {
    if (!await xuiLogin()) return null;
  }
  return withTlsBypass(async () => {
    const { url: pu } = getPanelConfig();
    const h: Record<string,string> = {
      ...(init.headers as Record<string,string> ?? {}),
      Cookie: _sessionCookie, "User-Agent": "Mozilla/5.0", Referer: `${pu}/`,
      ..._csrfToken ? { "X-CSRF-Token": _csrfToken } : {},
    };
    const res = await fetch(url, { ...init, headers: h, signal: init.signal ?? AbortSignal.timeout(20_000) });
    if (res.status === 401 || res.status === 403) {
      resetSession();
      if (!await xuiLogin()) return null;
      return withTlsBypass(() => fetch(url, { ...init, headers: { ...(init.headers as Record<string,string> ?? {}), Cookie: _sessionCookie, "X-CSRF-Token": _csrfToken, "User-Agent": "Mozilla/5.0" }, signal: AbortSignal.timeout(20_000) }));
    }
    return res;
  });
}

export async function xuiGetInbounds(): Promise<Array<Record<string, unknown>> | null> {
  const { url } = getPanelConfig();
  if (!url) return null;
  try {
    const res = await xuiFetchWithSession(`${url}/panel/api/inbounds/list`, { headers: { Accept: "application/json" } });
    if (!res || !res.ok) return null;
    const data = await res.json() as { success: boolean; obj?: unknown[] };
    if (!data.success) return null;
    return (data.obj as Array<Record<string, unknown>>) ?? null;
  } catch { return null; }
}

export type XuiServerStatus = {
  cpu: number; cpuCores: number;
  mem: { used: number; total: number }; swap: { used: number; total: number }; disk: { used: number; total: number };
  uptime: number; loads: number[]; xrayState: string; xrayVersion: string; panelVersion: string;
  netIO: { up: number; down: number }; tcpCount: number; udpCount: number;
};

export async function xuiGetServerStatus(): Promise<XuiServerStatus | null> {
  const { url } = getPanelConfig();
  if (!url) return null;
  try {
    const res = await xuiFetchWithSession(`${url}/panel/api/server/status`, { headers: { Accept: "application/json" } });
    if (!res || !res.ok) return null;
    const data = await res.json() as { success: boolean; obj?: Record<string, unknown> };
    if (!data.success || !data.obj) return null;
    const o = data.obj;
    const mem  = o.mem  as { current: number; total: number } | undefined;
    const swap = o.swap as { current: number; total: number } | undefined;
    const disk = o.disk as { current: number; total: number } | undefined;
    const xray = o.xray as { state: string; version: string } | undefined;
    const netIO = o.netIO as { up: number; down: number } | undefined;
    return {
      cpu: typeof o.cpu === "number" ? Math.round(o.cpu) : 0,
      cpuCores: typeof o.cpuCores === "number" ? o.cpuCores : 1,
      mem:  { used: mem?.current  ?? 0, total: mem?.total  ?? 0 },
      swap: { used: swap?.current ?? 0, total: swap?.total ?? 0 },
      disk: { used: disk?.current ?? 0, total: disk?.total ?? 0 },
      uptime:       typeof o.uptime === "number" ? o.uptime : 0,
      loads:        Array.isArray(o.loads) ? (o.loads as number[]) : [0,0,0],
      xrayState:    xray?.state   ?? "unknown",
      xrayVersion:  xray?.version ?? "",
      panelVersion: typeof o.panelVersion === "string" ? o.panelVersion : "",
      netIO:    { up: netIO?.up ?? 0, down: netIO?.down ?? 0 },
      tcpCount: typeof o.tcpCount === "number" ? o.tcpCount : 0,
      udpCount: typeof o.udpCount === "number" ? o.udpCount : 0,
    };
  } catch { return null; }
}

export async function xuiPing(): Promise<{ reachable: boolean; loginOk: boolean; csrfFound: boolean; error?: string }> {
  const { url, password } = getPanelConfig();
  if (!url)      return { reachable: false, loginOk: false, csrfFound: false, error: "PANEL_URL not set" };
  if (!password) return { reachable: false, loginOk: false, csrfFound: false, error: "PANEL_PASSWORD not set" };
  try {
    const { url: u, username, password: pass } = getPanelConfig();
    const { cookie: ic, csrf } = await fetchCsrfToken(u);
    const sc = await performLogin(u, username, pass, ic, csrf);
    if (sc) { _sessionCookie = sc; _csrfToken = csrf; _loggedIn = true; _lastLoginAt = Date.now(); }
    return { reachable: true, loginOk: !!sc, csrfFound: !!csrf };
  } catch (e: unknown) {
    return { reachable: false, loginOk: false, csrfFound: false, error: e instanceof Error ? e.message : String(e) };
  }
}

export function getPanelStatus(): { configured: boolean; url: string; username: string } {
  const { url, username, password } = getPanelConfig();
  return { configured: !!(url && password), url, username };
}

export function clearXuiSession(): void { resetSession(); }

export interface XuiNewClient { email: string; subId: string; subLink: string; inboundId: number; }

export async function xuiAddClient(inboundId: number, email: string, trafficGb = 0, expireDays = 30, limitIp = 0, tgId = 0): Promise<XuiNewClient | null> {
  const { url } = getPanelConfig();
  if (!url) return null;
  const subId = Array.from(crypto.getRandomValues(new Uint8Array(8))).map(b => b.toString(16).padStart(2,"0")).join("");
  const totalBytes = trafficGb  > 0 ? trafficGb  * 1024 * 1024 * 1024 : 0;
  const expiryTs   = expireDays > 0 ? Date.now() + expireDays * 86400 * 1000 : 0;
  const payload = { client: { email, totalGB: totalBytes, expiryTime: expiryTs, tgId, limitIp, enable: true, subId, reset: 0 }, inboundIds: [inboundId] };
  const res = await xuiFetchWithSession(`${url}/panel/api/clients/add`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
  if (!res || !res.ok) return null;
  const data = await res.json() as { success?: boolean };
  if (!data.success) return null;
  const subBase = url.replace(/\/[a-zA-Z0-9_-]{10,}$/, "");
  return { email, subId, subLink: `${subBase}/sub/${subId}`, inboundId };
}
