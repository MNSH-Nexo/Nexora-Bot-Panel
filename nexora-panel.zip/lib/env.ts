import { z } from 'zod'

const envSchema = z.object({
  // DATABASE_URL is optional — the web panel works without a database connection
  DATABASE_URL: z.string().url().optional(),
  NEXT_PUBLIC_API_URL: z.string().url().optional().default('http://localhost:13000'),
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
})

export type Env = z.infer<typeof envSchema>

const result = envSchema.safeParse(process.env)

if (!result.success) {
  // Warn only — do not crash the panel on missing optional vars
  console.warn('⚠️  Environment variables warning:', result.error.format())
}

export const env = result.success
  ? result.data
  : {
      DATABASE_URL: undefined,
      NEXT_PUBLIC_API_URL: 'http://localhost:13000',
      NODE_ENV: (process.env.NODE_ENV ?? 'production') as 'development' | 'production' | 'test',
    }
