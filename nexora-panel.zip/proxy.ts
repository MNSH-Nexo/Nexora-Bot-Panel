import { NextRequest, NextResponse } from "next/server";

/**
 * proxy.ts — Nexora Web Admin Panel Security (Next.js 16)
 *
 * امنیت دو لایه:
 *
 *  لایه ۱ — WebPath Guard (مثل پنل 3X-UI):
 *    اگر WEB_PANEL_PATH تنظیم شده (مثلاً /mySecret):
 *    - هر URL بدون آن webpath → 404 (حتی /login مستقیم)
 *    - کاربر بدون دانستن آدرس مخفی، هیچ صفحه‌ای نمی‌بینه
 *
 *  لایه ۲ — Auth Guard:
 *    - dashboard و api (غیر از /api/auth/* و /api/health) → session لازم دارن
 *    - بدون session → redirect به login
 *
 *  مهم: root webpath → REDIRECT (نه rewrite) تا URL مرورگر عوض بشه
 *    /{webpath}              → redirect → /{webpath}/login
 *    /{webpath}/login        → rewrite  → /login       (داخل Next.js)
 *    /{webpath}/dashboard/*  → rewrite  → /dashboard/* (داخل Next.js)
 *    /{webpath}/api/*        → rewrite  → /api/*       (داخل Next.js)
 */

// ── config (runtime) ─────────────────────────────────────────
function getWebPath(): string {
  const raw = (process.env.WEB_PANEL_PATH ?? "").trim().replace(/\/$/, "");
  if (!raw) return "";
  return raw.startsWith("/") ? raw : `/${raw}`;
}

function hasSession(req: NextRequest): boolean {
  const token = req.cookies.get("nexora_session")?.value ?? "";
  if (token.length < 20) return false;
  try {
    const decoded = Buffer.from(token, "base64").toString("utf8");
    return decoded.split(":").length >= 3;
  } catch {
    return false;
  }
}

function notFoundHtml(): NextResponse {
  return new NextResponse(
    `<!DOCTYPE html><html lang="fa" dir="rtl">
<head><meta charset="utf-8"><title>404</title>
<style>*{margin:0;padding:0;box-sizing:border-box}
body{background:#080810;color:#333;font-family:system-ui,sans-serif;
display:flex;align-items:center;justify-content:center;
min-height:100vh;flex-direction:column;gap:12px}
h1{font-size:5rem;color:#1a1a2e;font-weight:900;letter-spacing:-4px}
p{font-size:.8rem}</style></head>
<body><h1>404</h1><p>صفحه‌ای یافت نشد</p></body></html>`,
    { status: 404, headers: { "content-type": "text/html; charset=utf-8" } }
  );
}

/** webPath رو به response header اضافه می‌کنه تا client بتونه بخونه */
function withWebPathHeader(res: NextResponse, webPath: string): NextResponse {
  if (webPath) res.headers.set("x-web-path", webPath);
  return res;
}

// ── proxy function ────────────────────────────────────────────
export function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const webPath = getWebPath();

  // ── فایل‌های استاتیک — همیشه مجاز ───────────────────────
  if (
    pathname.startsWith("/_next/") ||
    pathname.startsWith("/favicon")
  ) {
    return NextResponse.next();
  }

  // ══════════════════════════════════════════════════════════
  //  حالت با WebPath (مثل پنل 3X-UI)
  // ══════════════════════════════════════════════════════════
  if (webPath && webPath.length > 1) {

    // ۱. مسیر باید با webpath شروع بشه — وگرنه 404
    const matchesWebPath =
      pathname === webPath ||
      pathname.startsWith(webPath + "/");

    if (!matchesWebPath) {
      return notFoundHtml();
    }

    // ۲. مسیر داخلی (بعد از حذف webpath prefix)
    const inner = pathname === webPath ? "" : pathname.slice(webPath.length);

    // ۳. root webpath → REDIRECT تا URL مرورگر عوض بشه
    // اگه rewrite کنیم، مرورگر pathname = /webpath/ نگه می‌داره
    // و getPathPrefix() در login/page.tsx نمی‌تونه webpath رو پیدا کنه
    // → fetch بدون webpath → 404
    if (inner === "" || inner === "/") {
      const destUrl = req.nextUrl.clone();
      destUrl.pathname = hasSession(req)
        ? `${webPath}/dashboard`
        : `${webPath}/login`;
      return NextResponse.redirect(destUrl);
    }

    // ۴. مسیرهای عمومی (بدون نیاز به session)
    const isPublic =
      inner === "/login" ||
      inner.startsWith("/login?") ||
      inner.startsWith("/api/auth/") ||
      inner === "/api/health" ||
      inner === "/api/brand";   // GET brand is public (used by DynamicHead before login)

    // ۵. Auth guard — مسیرهای protected
    if (!isPublic && !hasSession(req)) {
      const loginUrl = req.nextUrl.clone();
      loginUrl.pathname = `${webPath}/login`;
      loginUrl.search = "";
      return withWebPathHeader(NextResponse.redirect(loginUrl), webPath);
    }

    // ۶. Rewrite: /{webpath}/dashboard → /dashboard (Next.js internal routing)
    const rewriteUrl = req.nextUrl.clone();
    rewriteUrl.pathname = inner;
    return withWebPathHeader(NextResponse.rewrite(rewriteUrl), webPath);
  }

  // ══════════════════════════════════════════════════════════
  //  حالت بدون WebPath — فقط auth guard
  // ══════════════════════════════════════════════════════════
  const isPublic =
    pathname === "/login" ||
    pathname.startsWith("/login?") ||
    pathname.startsWith("/api/auth/") ||
    pathname === "/api/health" ||
    pathname === "/api/brand";   // GET brand is public (used by DynamicHead before login)

  if (!isPublic && !hasSession(req)) {
    if (
      pathname.startsWith("/dashboard") ||
      (pathname.startsWith("/api/") && !pathname.startsWith("/api/auth/"))
    ) {
      const loginUrl = req.nextUrl.clone();
      loginUrl.pathname = webPath ? `${webPath}/login` : "/login";
      return NextResponse.redirect(loginUrl);
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon\\.ico).*)"],
};

// Next.js 16 requires a named "middleware" export from proxy.ts
export { proxy as middleware };
