import type { NextConfig } from 'next';

/**
 * next.config.ts — Nexora Web Admin Panel
 *
 * متغیرهای محیطی (PANEL_URL, BOT_DB_PATH, ...) در runtime خونده می‌شن:
 *   - روی سرور: از طریق EnvironmentFile در systemd (inject می‌شه به next start)
 *   - در dev: Next.js به صورت خودکار .env.local رو از cwd لود می‌کنه
 *
 * هیچ env var ای در build-time bake نمی‌شه — پس build یک بار ساخته می‌شه
 * و روی هر سرور با هر .env.local کار می‌کنه.
 */
const nextConfig: NextConfig = {
  reactStrictMode: false,
  typescript: {
    ignoreBuildErrors: true,
  },
  serverExternalPackages: ["better-sqlite3"],
  // dev sandbox origins
  allowedDevOrigins: ["*"],
};

export default nextConfig;

