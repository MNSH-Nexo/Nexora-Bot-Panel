"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Shield, Eye, EyeOff, Lock, User } from "lucide-react";

/** پیشوند path فعلی مرورگر تا /login — برای API call های relative */
function getPathPrefix(): string {
  if (typeof window === "undefined") return "";
  const path = window.location.pathname;
  const idx = path.lastIndexOf("/login");
  return idx > 0 ? path.slice(0, idx) : "";
}

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    // هر بار مستقیم از URL می‌خونیم — نه از state — تا race condition نباشه
    const prefix = getPathPrefix();
    try {
      const res = await fetch(`${prefix}/api/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      if (res.ok) {
        const dest = prefix ? `${prefix}/dashboard` : "/dashboard";
        router.push(dest);
      } else {
        const data = await res.json().catch(() => ({}));
        setError(data.error === "Invalid credentials"
          ? "نام کاربری یا رمز عبور اشتباه است"
          : "خطا در ورود — دوباره تلاش کنید");
        setLoading(false);
      }
    } catch {
      setError("خطا در اتصال به سرور");
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen nexora-bg flex items-center justify-center p-4">
      {/* Glow blob */}
      <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-primary/8 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-sm relative animate-in-up">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex w-14 h-14 rounded-2xl bg-primary/20 border border-primary/40 items-center justify-center mb-4">
            <Shield className="w-7 h-7 text-primary" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">NEXORA</h1>
          <p className="text-sm text-muted-foreground mt-1">Admin Panel</p>
        </div>

        {/* Card */}
        <div className="rounded-2xl border border-border/60 bg-card/80 backdrop-blur-sm p-6 space-y-4">
          <form onSubmit={handleLogin} className="space-y-4">
            {/* Username */}
            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block font-medium">نام کاربری</label>
              <div className="relative">
                <User className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="admin"
                  dir="ltr"
                  autoComplete="username"
                  className="w-full pr-10 pl-4 py-2.5 rounded-xl bg-input border border-border text-sm text-foreground focus:outline-none focus:border-primary/60 transition-colors"
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="text-xs text-muted-foreground mb-1.5 block font-medium">رمز عبور</label>
              <div className="relative">
                <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type={showPass ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  dir="ltr"
                  autoComplete="current-password"
                  className="w-full pr-10 pl-10 py-2.5 rounded-xl bg-input border border-border text-sm text-foreground focus:outline-none focus:border-primary/60 transition-colors"
                />
                <button type="button" onClick={() => setShowPass(!showPass)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <p className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
                {error}
              </p>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={loading || !username || !password}
              className={`w-full py-2.5 rounded-xl text-sm font-semibold transition-all ${
                loading || !username || !password
                  ? "bg-secondary text-muted-foreground cursor-not-allowed"
                  : "bg-primary text-primary-foreground hover:bg-primary/90"
              }`}
            >
              {loading ? "در حال ورود..." : "ورود به پنل"}
            </button>
          </form>
        </div>

        <p className="text-center text-xs text-muted-foreground/40 mt-6">
          دسترسی فقط از طریق آدرس مخصوص امکان‌پذیر است
        </p>
      </div>
    </div>
  );
}
