import { redirect } from "next/navigation";

// این صفحه فقط وقتی WEB_PANEL_PATH تنظیم نشده اجرا می‌شه
// اگه webpath تنظیم شده باشه، middleware درخواست به / رو 404 می‌کنه
export default function Home() {
  redirect("/dashboard");
}
