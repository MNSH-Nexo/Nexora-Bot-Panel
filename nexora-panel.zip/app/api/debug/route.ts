/**
 * GET /api/debug
 * وضعیت واقعی env vars، DB، و اتصال 3X-UI — فقط برای admin
 */
import { NextRequest, NextResponse } from "next/server";
import { requireAuth, getBotDb, getBotDbPath, getDbDiagnostics } from "@/lib/botdb";

export async function GET(req: NextRequest) {
  if (!requireAuth(req as unknown as Request)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const panelUrl      = process.env.PANEL_URL?.trim()      ?? "";
  const panelUsername = process.env.PANEL_USERNAME?.trim()  ?? "";
  const panelPassword = process.env.PANEL_PASSWORD?.trim()  ?? "";
  const botToken      = process.env.BOT_TOKEN?.trim()       ?? "";
  const adminIds      = process.env.ADMIN_IDS?.trim()       ?? "";
  const botDbPath     = process.env.BOT_DB_PATH?.trim()     ?? "";
  const webPanelPort  = process.env.WEB_PANEL_PORT?.trim()  ?? "";

  // چک DB
  const resolvedDb = getBotDbPath();
  const dbDiag     = getDbDiagnostics();

  // تست اتصال واقعی به DB
  let dbConnectOk = false;
  let dbUserCount = 0;
  try {
    const db = getBotDb(true);
    if (db) {
      const row = db.prepare("SELECT COUNT(*) as c FROM users").get() as { c: number } | undefined;
      dbUserCount = row?.c ?? 0;
      dbConnectOk = true;
      db.close();
    }
  } catch { /* ignore */ }

  // تست اتصال به 3X-UI (با TLS ignore برای self-signed certs)
  const { xuiPing } = await import("@/lib/xui");
  const xuiResult = await xuiPing();
  const xuiReachable = xuiResult.reachable;
  const xuiLoginOk   = xuiResult.loginOk;
  const xuiError     = xuiResult.error ?? null;

  return NextResponse.json({
    env: {
      PANEL_URL:      panelUrl      ? panelUrl      : "❌ NOT SET",
      PANEL_USERNAME: panelUsername ? panelUsername : "❌ NOT SET",
      PANEL_PASSWORD: panelPassword ? "✔ set"       : "❌ NOT SET",
      BOT_TOKEN:      botToken      ? `${botToken.slice(0, 10)}...` : "❌ NOT SET",
      ADMIN_IDS:      adminIds      || "❌ NOT SET",
      BOT_DB_PATH:    botDbPath     || "❌ NOT SET (will use fallback)",
      WEB_PANEL_PORT: webPanelPort  || "❌ NOT SET",
    },
    db: {
      resolved_path:  resolvedDb ?? "❌ NOT FOUND",
      connect_ok:     dbConnectOk,
      user_count:     dbUserCount,
      path_checks:    dbDiag,
    },
    xui: {
      panel_url:   panelUrl || "❌ NOT SET",
      reachable:   xuiReachable,
      login_ok:    xuiLoginOk,
      error:       xuiError,
    },
  });
}
