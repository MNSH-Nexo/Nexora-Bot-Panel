/**
 * GET  /api/brand  → { panelName, logoUrl, faviconUrl, tabTitle, source }
 * POST /api/brand (JSON) → save panelName / tabTitle / logoUrl / faviconUrl
 * POST /api/brand (multipart, field=logo)    → upload + resize → /public/brand/panel-logo.webp
 * POST /api/brand (multipart, field=favicon) → upload + resize → /public/brand/panel-favicon.png
 *
 * Resize strategy (server-side, pure Node — no native addons):
 *   • اگر حجم فایل < 2 MB و ابعاد نامعلوم → همانطور ذخیره
 *   • اگر sharp نصب بود → resize 256×256 (logo) / 64×64 (favicon)
 *   • بدون sharp → raw buffer ذخیره می‌شود (client باید pre-resize کند)
 *   Cache-bust: timestamp را به URL اضافه می‌کنیم تا مرورگر کش قدیمی را نگیرد
 */
import { NextRequest, NextResponse } from "next/server";
import { getBotDb, requireAuth, getSetting, setSetting } from "@/lib/botdb";
import fs from "fs";
import path from "path";

export const runtime = "nodejs";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

const KEYS = {
  name:    "web_panel_name",
  logo:    "web_panel_logo_url",
  favicon: "web_panel_favicon_url",
  title:   "web_panel_tab_title",
};

const PUBLIC_DIR  = path.join(process.cwd(), "public");
const BRAND_DIR   = path.join(PUBLIC_DIR, "brand");
const MAX_BYTES   = 5 * 1024 * 1024; // 5 MB
const LOGO_SIZE   = 256;
const FAVICON_SIZE = 64;

/** سعی می‌کند با sharp (اگه نصب باشد) resize کند، وگرنه raw buffer برمی‌گرداند */
async function resizeImage(
  buf: Buffer,
  size: number,
  outputFormat: "png" | "webp" = "png",
): Promise<{ data: Buffer; ext: string }> {
  try {
    // dynamic import — اگه sharp نصب نبود، error می‌اندازد
    const sharp = (await import("sharp")).default;
    const data = await sharp(buf)
      .resize(size, size, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
      .toFormat(outputFormat)
      .toBuffer();
    return { data, ext: outputFormat };
  } catch {
    // sharp نیست — raw ذخیره کن
    return { data: buf, ext: outputFormat };
  }
}

export async function GET(_req: NextRequest) {
  const db = getBotDb(true);
  const panelName  = db ? getSetting(db, KEYS.name,    "NEXORA") : "NEXORA";
  const logoUrl    = db ? getSetting(db, KEYS.logo,    "")       : "";
  const faviconUrl = db ? getSetting(db, KEYS.favicon, "")       : "";
  const tabTitle   = db ? getSetting(db, KEYS.title,   "")       : "";
  if (db) db.close();
  return NextResponse.json({
    panelName, logoUrl, faviconUrl, tabTitle,
    source: db ? "live" : "unavailable",
  });
}

export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const contentType = req.headers.get("content-type") ?? "";

  if (contentType.includes("multipart/form-data")) {
    const form = await req.formData().catch(() => null);
    if (!form) return NextResponse.json({ error: "invalid form data" }, { status: 400 });

    fs.mkdirSync(BRAND_DIR, { recursive: true });

    const ts = Date.now(); // cache-bust timestamp
    const saved: string[] = [];
    const result: Record<string, string> = {};

    // ── Logo ──────────────────────────────────────────────────
    const logoFile = form.get("logo") as File | null;
    if (logoFile) {
      if (logoFile.size > MAX_BYTES) {
        return NextResponse.json({ error: `لوگو بزرگ‌تر از 5 MB است (${(logoFile.size / 1024 / 1024).toFixed(1)} MB)` }, { status: 400 });
      }
      const rawBuf = Buffer.from(await logoFile.arrayBuffer());
      const { data, ext } = await resizeImage(rawBuf, LOGO_SIZE, "png");
      const fname = `panel-logo.${ext}`;
      fs.writeFileSync(path.join(BRAND_DIR, fname), data);
      const url = `/brand/${fname}?v=${ts}`;
      const db = getBotDb(false);
      if (db) { setSetting(db, KEYS.logo, url); db.close(); }
      result.logoUrl = url;
      saved.push("logo");
    }

    // ── Favicon ───────────────────────────────────────────────
    const favFile = form.get("favicon") as File | null;
    if (favFile) {
      if (favFile.size > MAX_BYTES) {
        return NextResponse.json({ error: `favicon بزرگ‌تر از 5 MB است` }, { status: 400 });
      }
      const rawBuf = Buffer.from(await favFile.arrayBuffer());
      const { data, ext } = await resizeImage(rawBuf, FAVICON_SIZE, "png");
      const fname = `panel-favicon.${ext}`;
      fs.writeFileSync(path.join(BRAND_DIR, fname), data);
      const url = `/brand/${fname}?v=${ts}`;
      const db = getBotDb(false);
      if (db) { setSetting(db, KEYS.favicon, url); db.close(); }
      result.faviconUrl = url;
      saved.push("favicon");
    }

    if (!saved.length) {
      return NextResponse.json({ error: "هیچ فایلی ارسال نشد (فیلدها: logo / favicon)" }, { status: 400 });
    }

    return NextResponse.json({ ok: true, saved, ...result });
  }

  // ── JSON ──────────────────────────────────────────────────
  const body = await req.json().catch(() => ({})) as Record<string, unknown>;
  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "DB unavailable" }, { status: 503 });
  try {
    if (body.panelName  !== undefined) setSetting(db, KEYS.name,    String(body.panelName).trim()  || "NEXORA");
    if (body.tabTitle   !== undefined) setSetting(db, KEYS.title,   String(body.tabTitle).trim());
    if (body.logoUrl    !== undefined) setSetting(db, KEYS.logo,    String(body.logoUrl));
    if (body.faviconUrl !== undefined) setSetting(db, KEYS.favicon, String(body.faviconUrl));
    db.close();
    return NextResponse.json({ ok: true });
  } catch (e) {
    try { db.close(); } catch { /* */ }
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
