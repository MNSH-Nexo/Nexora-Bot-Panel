import { NextRequest, NextResponse } from "next/server";

export async function POST(req: NextRequest) {
  const { username, password } = await req.json().catch(() => ({}));

  // Read credentials from env — set by install.sh via .env.local
  const envUser = process.env.WEB_PANEL_USER ?? "admin";
  const envPass = process.env.WEB_PANEL_PASS ?? "admin1234";

  if (!username || !password) {
    return NextResponse.json({ error: "Missing credentials" }, { status: 400 });
  }

  if (username !== envUser || password !== envPass) {
    return NextResponse.json({ error: "Invalid credentials" }, { status: 401 });
  }

  // Build session token — simple HMAC-like value, good enough for local panel
  const sessionToken = Buffer.from(
    `${username}:${Date.now()}:${Math.random().toString(36).slice(2)}`
  ).toString("base64");

  const res = NextResponse.json({ ok: true });

  res.cookies.set("nexora_session", sessionToken, {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 12,
    secure: false,
  });

  return res;
}
