/**
 * POST /api/auth/change-password
 * تغییر واقعی رمز عبور پنل در فایل .env.local
 */
import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/botdb";
import { readFileSync, writeFileSync } from "fs";
import { resolve } from "path";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => ({})) as Record<string, unknown>;
  const { newPassword } = body;

  if (!newPassword || typeof newPassword !== "string") {
    return NextResponse.json({ error: "newPassword required" }, { status: 400 });
  }
  if (newPassword.length < 8) {
    return NextResponse.json({ error: "رمز عبور باید حداقل ۸ کاراکتر باشد" }, { status: 400 });
  }

  const envPath = resolve(process.cwd(), ".env.local");

  try {
    let content = "";
    try { content = readFileSync(envPath, "utf8"); } catch { content = ""; }

    const escaped = newPassword.replace(/["\\]/g, "\\$&");
    if (content.includes("WEB_PANEL_PASS=")) {
      content = content.replace(/^WEB_PANEL_PASS=.*$/m, "WEB_PANEL_PASS=\"" + escaped + "\"");
    } else {
      content += "\nWEB_PANEL_PASS=\"" + escaped + "\"\n";
    }

    writeFileSync(envPath, content, "utf8");
    return NextResponse.json({ ok: true, message: "رمز عبور تغییر کرد. پنل را ری‌استارت کنید تا اعمال شود." });
  } catch (e) {
    return NextResponse.json({ error: "خطا در نوشتن فایل: " + String(e) }, { status: 500 });
  }
}
