import { NextRequest, NextResponse } from "next/server";
import { getBotDb, requireAuth, getSetting, setSetting } from "@/lib/botdb";

function auth(req: NextRequest) {
  return requireAuth(req as unknown as Request);
}

const ADMIN_CMD_KEY = "admin_login_command";
const ADMIN_CMD_DEFAULT = "admin_secret";

// ── GET /api/security ── خواندن دستور ادمین فعلی
export async function GET(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const db = getBotDb(true);
  if (!db) {
    return NextResponse.json({ admin_command: ADMIN_CMD_DEFAULT, source: "default" });
  }

  try {
    const cmd = getSetting(db, ADMIN_CMD_KEY, ADMIN_CMD_DEFAULT);
    db.close();
    return NextResponse.json({ admin_command: cmd, source: "live" });
  } catch (e) {
    try { db.close(); } catch { /* */ }
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}

// ── POST /api/security ── ذخیره دستور ادمین جدید در DB ربات
export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => ({})) as Record<string, unknown>;
  const { admin_command } = body;

  if (!admin_command || typeof admin_command !== "string") {
    return NextResponse.json({ error: "admin_command required" }, { status: 400 });
  }

  // اعتبارسنجی — فقط حروف انگلیسی، عدد و _ — مانند ربات
  if (!/^[a-zA-Z][a-zA-Z0-9_]{2,31}$/.test(admin_command)) {
    return NextResponse.json({
      error: "دستور نامعتبر — فقط حروف انگلیسی، عدد و _ (۳ تا ۳۲ کاراکتر، شروع با حرف)",
    }, { status: 400 });
  }

  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "DB unavailable — ربات در دسترس نیست" }, { status: 503 });

  try {
    setSetting(db, ADMIN_CMD_KEY, admin_command);
    db.close();
    return NextResponse.json({ ok: true, admin_command });
  } catch (e) {
    try { db.close(); } catch { /* */ }
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
