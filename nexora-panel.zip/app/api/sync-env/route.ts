/**
 * GET  /api/sync-env  — نمایش وضعیت فعلی .env.local و مقادیر bot/.env
 * POST /api/sync-env  — خواندن bot/.env و sync کردن به .env.local پنل
 *
 * این API فقط روی سرور واقعی کار می‌کند (نه sandbox).
 * در صورت نبود فایل، پیام خطای واضح برمی‌گرداند.
 */
import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/botdb";
import fs from "fs";
import path from "path";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

// مسیرهای احتمالی bot/.env روی سرور
const BOT_ENV_CANDIDATES = [
  process.env.BOT_ENV_PATH,           // اگه کاربر دستی تنظیم کرده
  "/opt/nexora-bot/.env",             // مسیر اصلی (ریشه پروژه ربات)
  "/opt/nexora-bot/bot/.env",         // مسیر پیش‌فرض نصب قدیمی
  "/opt/nexora-bot/data/.env",        // fallback قدیمی
  "/root/nexora-bot/.env",            // اگه در home نصب شده
  "/home/nexora/.env",               // fallback دیگر
].filter(Boolean) as string[];

// مسیر .env.local پنل
function getPanelEnvPath(): string {
  return path.join(process.cwd(), ".env.local");
}

/** خواندن یک مقدار از محتوای .env */
function parseEnvValue(content: string, key: string): string {
  const match = content.match(new RegExp(`^${key}=(.*)$`, "m"));
  if (!match) return "";
  return match[1].replace(/^["']|["']$/g, "").trim();
}

/** خواندن تمام key=value های مورد نیاز از bot/.env */
function readBotEnv(filePath: string): Record<string, string> {
  const content = fs.readFileSync(filePath, "utf-8");
  const keys = ["BOT_TOKEN", "ADMIN_IDS", "ADMIN_SECRET", "PANEL_URL", "PANEL_USERNAME", "PANEL_PASSWORD", "SUB_PORT", "WEBHOOK_PORT", "DB_URL", "WEB_PANEL_PATH", "WEB_PANEL_USER", "WEB_PANEL_PASS", "WEB_PANEL_PORT", "WEB_PANEL_ENABLED"];
  const result: Record<string, string> = {};
  for (const k of keys) result[k] = parseEnvValue(content, k);
  return result;
}

/** خواندن تمام key=value های .env.local پنل */
function readPanelEnv(filePath: string): Record<string, string> {
  if (!fs.existsSync(filePath)) return {};
  const content = fs.readFileSync(filePath, "utf-8");
  const keys = [
    "WEB_PANEL_PATH", "WEB_PANEL_USER", "WEB_PANEL_PASS", "WEB_PANEL_PORT",
    "WEB_PANEL_ENABLED", "BOT_TOKEN", "ADMIN_IDS", "PANEL_URL",
    "PANEL_USERNAME", "PANEL_PASSWORD", "BOT_DB_PATH", "NODE_ENV", "SUB_PORT", "WEBHOOK_PORT", "ADMIN_SECRET", "DB_URL",
  ];
  const result: Record<string, string> = {};
  for (const k of keys) result[k] = parseEnvValue(content, k);
  return result;
}

/** نوشتن/آپدیت یک کلید در فایل .env.local — اگه وجود داشت replace، نداشت append */
function upsertEnvFile(filePath: string, updates: Record<string, string>): void {
  let content = fs.existsSync(filePath) ? fs.readFileSync(filePath, "utf-8") : "";

  for (const [key, value] of Object.entries(updates)) {
    const regex = new RegExp(`^${key}=.*$`, "m");
    const line = `${key}=${value}`;
    if (regex.test(content)) {
      content = content.replace(regex, line);
    } else {
      content = content.trimEnd() + "\n" + line + "\n";
    }
  }

  fs.writeFileSync(filePath, content, { encoding: "utf-8", mode: 0o600 });
}

// ── GET: وضعیت ──────────────────────────────────────────────
export async function GET(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const panelEnvPath = getPanelEnvPath();
  const panelEnvExists = fs.existsSync(panelEnvPath);
  const panelEnv = readPanelEnv(panelEnvPath);

  // پیدا کردن bot/.env
  let botEnvPath: string | null = null;
  for (const p of BOT_ENV_CANDIDATES) {
    if (fs.existsSync(p)) { botEnvPath = p; break; }
  }

  let botEnv: Record<string, string> = {};
  let botEnvReadable = false;
  if (botEnvPath) {
    try {
      botEnv = readBotEnv(botEnvPath);
      botEnvReadable = true;
    } catch { botEnvReadable = false; }
  }

  // مقایسه کلیدهای مهم
  const syncKeys = ["BOT_TOKEN", "ADMIN_IDS", "ADMIN_SECRET", "PANEL_URL", "PANEL_USERNAME", "PANEL_PASSWORD", "SUB_PORT", "WEBHOOK_PORT", "DB_URL", "WEB_PANEL_PATH", "WEB_PANEL_USER", "WEB_PANEL_PASS", "WEB_PANEL_PORT", "WEB_PANEL_ENABLED"];
  // DB_URL ربات مسیر Docker است و با پنل متفاوته — از out-of-sync حذف می‌شه
  const IGNORE_DIFF = new Set(["DB_URL"]);
  const outOfSync = syncKeys.filter(k => !IGNORE_DIFF.has(k) && botEnv[k] && botEnv[k] !== panelEnv[k]);

  return NextResponse.json({
    panelEnvPath,
    panelEnvExists,
    panelEnv: {
      ...panelEnv,
      BOT_TOKEN:      panelEnv.BOT_TOKEN      ? `${panelEnv.BOT_TOKEN.slice(0, 10)}...` : "",
      PANEL_PASSWORD: panelEnv.PANEL_PASSWORD  ? "✔ set" : "",
      WEB_PANEL_PASS: panelEnv.WEB_PANEL_PASS  ? "✔ set" : "",
    },
    botEnvPath,
    botEnvReadable,
    botEnv: {
      ...botEnv,
      BOT_TOKEN:      botEnv.BOT_TOKEN      ? `${botEnv.BOT_TOKEN.slice(0, 10)}...` : "",
      PANEL_PASSWORD: botEnv.PANEL_PASSWORD  ? "✔ set" : "",
    },
    outOfSync,
    inSync: outOfSync.length === 0 && botEnvReadable,
  });
}

// ── POST: sync ───────────────────────────────────────────────
export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const forceSync: boolean = body.force === true;

  const panelEnvPath = getPanelEnvPath();

  // پیدا کردن bot/.env
  let botEnvPath: string | null = null;
  for (const p of BOT_ENV_CANDIDATES) {
    if (fs.existsSync(p)) { botEnvPath = p; break; }
  }

  if (!botEnvPath) {
    return NextResponse.json({
      ok: false,
      error: `فایل bot/.env پیدا نشد. مسیرهای بررسی‌شده: ${BOT_ENV_CANDIDATES.join(", ")}`,
      checked: BOT_ENV_CANDIDATES,
    }, { status: 404 });
  }

  let botEnv: Record<string, string>;
  try {
    botEnv = readBotEnv(botEnvPath);
  } catch (e) {
    return NextResponse.json({ ok: false, error: `خطا در خواندن ${botEnvPath}: ${e}` }, { status: 500 });
  }

  // فقط کلیدهایی که مقدار دارن sync می‌شن
  const updates: Record<string, string> = {};
  const syncKeys = ["BOT_TOKEN", "ADMIN_IDS", "ADMIN_SECRET", "PANEL_URL", "PANEL_USERNAME", "PANEL_PASSWORD", "SUB_PORT", "WEBHOOK_PORT", "DB_URL", "WEB_PANEL_PATH", "WEB_PANEL_USER", "WEB_PANEL_PASS", "WEB_PANEL_PORT", "WEB_PANEL_ENABLED"];
  for (const k of syncKeys) {
    if (botEnv[k]) updates[k] = botEnv[k];
  }

  // BOT_DB_PATH: پیدا کردن مسیر واقعی DB
  const dbCandidates = [
    "/var/lib/docker/volumes/nexora_bot_data/_data/bot_data.db",
    "/opt/nexora-bot/data/bot_data.db",
    "/opt/nexora-bot/bot/bot_data.db",
  ];
  for (const p of dbCandidates) {
    if (fs.existsSync(p)) { updates["BOT_DB_PATH"] = p; break; }
  }

  if (Object.keys(updates).length === 0 && !forceSync) {
    return NextResponse.json({
      ok: false,
      error: "هیچ مقدار معتبری در bot/.env پیدا نشد — BOT_TOKEN خالی است؟",
    }, { status: 400 });
  }

  try {
    upsertEnvFile(panelEnvPath, updates);
  } catch (e) {
    return NextResponse.json({ ok: false, error: `خطا در نوشتن .env.local: ${e}` }, { status: 500 });
  }

  const synced = Object.keys(updates);
  return NextResponse.json({
    ok: true,
    message: `${synced.length} متغیر با موفقیت sync شد`,
    synced,
    botEnvPath,
    panelEnvPath,
    note: "وب‌پنل را ری‌استارت کنید تا تغییرات اعمال شود",
  });
}
