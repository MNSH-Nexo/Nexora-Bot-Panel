/**
 * GET/POST /api/bot-config
 * Manages all bot configuration stored in admin_settings table:
 * banner, welcome banner, join channel, payment methods, card info, rate
 */
import { NextRequest, NextResponse } from "next/server";
import { getBotDb, requireAuth, getSetting, setSetting } from "@/lib/botdb";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

const ALL_KEYS = [
  "banner_file_id",
  "welcome_banner_file_id", "welcome_banner_caption",
  "join_channel_id", "join_channel_link", "join_channel_title",
  "payment_crypto_enabled", "payment_card_enabled",
  "payment_crypto_invoice", "crypto_gateway",
  "card_number", "card_holder", "usdt_to_toman_rate",
  "enabled_inbound_ids",
  "admin_login_command",
  "test_sub_enabled", "test_sub_traffic_gb", "test_sub_duration_days", "test_sub_inbound_id",
  "referral_reward_days",
  "referral_reward_type",
  "referral_reward_plan_id",
  "referral_trigger",
  "referral_enabled",
  "referral_custom_traffic_gb",
  "referral_custom_days",
  "referral_inbound_id",
];

export async function GET(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const db = getBotDb(true);
  if (!db) return NextResponse.json({ source: "unavailable", config: {} });

  try {
    const config: Record<string, string> = {};
    for (const key of ALL_KEYS) {
      config[key] = getSetting(db, key, "");
    }
    db.close();
    return NextResponse.json({ source: "live", config });
  } catch (e) {
    db.close();
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json().catch(() => ({}));
  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "DB unavailable" }, { status: 503 });

  try {
    for (const key of ALL_KEYS) {
      if (key in body) {
        setSetting(db, key, String(body[key]));
      }
    }
    db.close();
    return NextResponse.json({ ok: true });
  } catch (e) {
    db.close();
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
