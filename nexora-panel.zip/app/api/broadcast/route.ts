/**
 * POST /api/broadcast
 * ارسال پیام دسته‌جمعی به همه کاربران از طریق ربات
 *
 * حالت‌ها:
 *   1. JSON  { message, target: "all_users" }         → پیام متنی
 *   2. FormData { photo: File, message?, target }      → عکس + کپشن (compress خودکار)
 *   3. JSON  { message, target: "admins" }             → مستقیم از Telegram Bot API
 */
import { NextRequest, NextResponse } from "next/server";
import { getBotDb, requireAuth } from "@/lib/botdb";
import sharp from "sharp";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

const MAX_PHOTO_BYTES = 9.5 * 1024 * 1024; // 9.5MB — زیر سقف 10MB تلگرام
const MAX_DIMENSION  = 2560;               // تلگرام بیشتر از این بزرگ نمی‌خواد
const MIN_DIMENSION  = 320;                // تلگرام کمتر از این را IMAGE_PROCESS_FAILED می‌دهد

async function tgSendMessage(token: string, chatId: string, text: string): Promise<boolean> {
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML", disable_web_page_preview: true }),
    });
    return ((await res.json()) as { ok: boolean }).ok === true;
  } catch { return false; }
}

/**
 * عکس را compress و resize می‌کند تا:
 * - حداکثر MAX_DIMENSION در هر بعد
 * - حداکثر MAX_PHOTO_BYTES سایز فایل
 * خروجی: JPEG با کیفیت بهینه
 */
async function optimizePhoto(input: Uint8Array): Promise<Buffer> {
  let img = sharp(input);
  const meta = await img.metadata();

  // resize برای بزرگ یا کوچک بودن غیرقابل قبول
  const w = meta.width ?? 0;
  const h = meta.height ?? 0;
  const needsResize = w > MAX_DIMENSION || h > MAX_DIMENSION;
  // upscale اگه خیلی کوچیکه — تلگرام عکس‌های کوچکتر از MIN_DIMENSION رو رد می‌کنه
  const needsUpscale = (w > 0 && w < MIN_DIMENSION) || (h > 0 && h < MIN_DIMENSION);
  if (needsResize) {
    img = img.resize(MAX_DIMENSION, MAX_DIMENSION, { fit: "inside", withoutEnlargement: true });
  } else if (needsUpscale) {
    const scale = Math.ceil(MIN_DIMENSION / Math.min(w || MIN_DIMENSION, h || MIN_DIMENSION));
    const nw = Math.min(w * scale, MAX_DIMENSION);
    const nh = Math.min(h * scale, MAX_DIMENSION);
    img = img.resize(nw, nh, { fit: "fill", kernel: "nearest" });
  }

  // تبدیل به JPEG با کیفیت adaptive
  let quality = 85;
  let output = await img.jpeg({ quality }).toBuffer();

  // اگه هنوز بزرگه، کیفیت رو کم کن
  while (output.length > MAX_PHOTO_BYTES && quality > 40) {
    quality -= 10;
    output = await sharp(input)
      .resize(MAX_DIMENSION, MAX_DIMENSION, { fit: "inside", withoutEnlargement: true })
      .jpeg({ quality })
      .toBuffer();
  }

  return output;
}

/**
 * عکس را به تلگرام آپلود می‌کند و file_id برمی‌گرداند.
 */
async function uploadPhotoToTelegram(
  token: string,
  adminId: string,
  photoBytes: Buffer,
  filename: string,
): Promise<{ ok: true; fileId: string } | { ok: false; error: string }> {
  try {
    const form = new FormData();
    form.append("chat_id", adminId);
    form.append("photo", new Blob([photoBytes.buffer.slice(photoBytes.byteOffset, photoBytes.byteOffset + photoBytes.byteLength) as ArrayBuffer], { type: "image/jpeg" }), filename);
    const res = await fetch(`https://api.telegram.org/bot${token}/sendPhoto`, {
      method: "POST",
      body: form,
    });
    const data = await res.json() as {
      ok: boolean;
      result?: { photo?: Array<{ file_id: string }> };
      description?: string;
    };
    if (data.ok && data.result?.photo?.length) {
      const photos = data.result.photo;
      return { ok: true, fileId: photos[photos.length - 1].file_id };
    }
    return { ok: false, error: data.description ?? "آپلود ناموفق بود" };
  } catch (e) {
    return { ok: false, error: String(e) };
  }
}

export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const contentType = req.headers.get("content-type") ?? "";
  let message = "";
  let target = "all_users";
  let photoFileId: string | null = null;

  if (contentType.includes("multipart/form-data")) {
    const form = await req.formData().catch(() => null);
    if (!form) return NextResponse.json({ error: "invalid form data" }, { status: 400 });

    message = String(form.get("message") ?? form.get("caption") ?? "").trim();
    target  = String(form.get("target") ?? "all_users");

    const photoBlob = form.get("photo");
    if (photoBlob && photoBlob instanceof Blob) {
      const botToken = process.env.BOT_TOKEN ?? "";
      const adminIds = (process.env.ADMIN_IDS ?? "").split(",").map(s => s.trim()).filter(Boolean);

      if (!botToken || !adminIds.length) {
        return NextResponse.json({ error: "BOT_TOKEN یا ADMIN_IDS در .env.local تنظیم نشده — ابتدا sync کنید" }, { status: 503 });
      }

      const rawBytes = new Uint8Array(await photoBlob.arrayBuffer());

      // compress و resize خودکار
      let optimized: Buffer;
      try {
        optimized = await optimizePhoto(rawBytes);
      } catch {
        // اگه sharp کار نکرد، همون فایل اصلی رو بفرست
        optimized = Buffer.from(rawBytes);
      }

      const fname = ((photoBlob as File).name ?? "broadcast.jpg").replace(/\.[^.]+$/, ".jpg");
      const uploadResult = await uploadPhotoToTelegram(botToken, adminIds[0], optimized, fname);

      if (!uploadResult.ok) {
        return NextResponse.json({
          error: `آپلود عکس به تلگرام ناموفق بود: ${uploadResult.error}`,
        }, { status: 502 });
      }
      photoFileId = uploadResult.fileId;

    } else {
      photoFileId = String(form.get("photo_file_id") ?? "").trim() || null;
    }

  } else {
    const body = await req.json().catch(() => ({})) as Record<string, unknown>;
    message     = String(body.message ?? "").trim();
    target      = String(body.target ?? "all_users");
    photoFileId = String(body.photo_file_id ?? "").trim() || null;
  }

  if (!message && !photoFileId) {
    return NextResponse.json({ error: "متن پیام یا تصویر الزامی است" }, { status: 400 });
  }

  // ── target=admins ─────────────────────────────────────────
  if (target === "admins") {
    const botToken = process.env.BOT_TOKEN ?? "";
    const adminIds = (process.env.ADMIN_IDS ?? "").split(",").map(s => s.trim()).filter(Boolean);
    if (!botToken) return NextResponse.json({ error: "BOT_TOKEN تنظیم نشده" }, { status: 503 });
    if (!adminIds.length) return NextResponse.json({ error: "ADMIN_IDS تنظیم نشده" }, { status: 503 });
    const results = await Promise.all(adminIds.map(id => tgSendMessage(botToken, id, message)));
    const sent = results.filter(Boolean).length;
    return NextResponse.json({ ok: true, sent, total: adminIds.length, mode: "admins_direct" });
  }

  // ── target=all_users → pending_actions ────────────────────
  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "دیتابیس ربات در دسترس نیست — ربات در حال اجراست؟" }, { status: 503 });

  try {
    db.prepare(`
      CREATE TABLE IF NOT EXISTS pending_actions (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        type       TEXT    NOT NULL,
        payload    TEXT    NOT NULL DEFAULT '{}',
        created_at TEXT    NOT NULL DEFAULT (datetime('now'))
      )
    `).run();

    const payload: Record<string, unknown> = {};
    if (message)     payload.message       = message;
    if (photoFileId) payload.photo_file_id = photoFileId;

    db.prepare(
      "INSERT INTO pending_actions (type, payload, created_at) VALUES ('bot_broadcast', ?, datetime('now'))"
    ).run(JSON.stringify(payload));

    let userCount = 0;
    try {
      const row = db.prepare("SELECT COUNT(*) as c FROM users").get() as { c: number } | undefined;
      userCount = row?.c ?? 0;
    } catch { /* ignore */ }

    db.close();
    return NextResponse.json({
      ok: true,
      mode: "bot_broadcast",
      message: `پیام در صف ربات قرار گرفت — ظرف ۱۵ ثانیه شروع به ارسال می‌شود`,
      estimated_recipients: userCount,
    });

  } catch (e) {
    try { db.close(); } catch { /* */ }
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
