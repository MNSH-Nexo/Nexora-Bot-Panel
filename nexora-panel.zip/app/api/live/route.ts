/**
 * GET /api/live
 * SSE endpoint برای اتصال زنده — push آمار هر ۱۵ ثانیه
 */
import { NextRequest } from "next/server";
import { getBotDb, requireAuth } from "@/lib/botdb";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

function getStats() {
  const db = getBotDb(true);
  if (!db) return { source: "unavailable", pendingPayments: 0, openTickets: 0, expiringSoon: 0, total: 0 };
  try {
    const now     = new Date().toISOString();
    const in7days = new Date(Date.now() + 7 * 86400000).toISOString();
    const q = <T>(sql: string, ...p: unknown[]) => (db.prepare(sql).get(...p) as T);
    const pendingPayments = q<{c:number}>("SELECT COUNT(*) as c FROM payments WHERE status IN ('awaiting_review','waiting','confirming')").c;
    const openTickets     = q<{c:number}>("SELECT COUNT(*) as c FROM tickets WHERE status IN ('open','in_progress')").c;
    const expiringSoon    = q<{c:number}>("SELECT COUNT(*) as c FROM subscriptions WHERE status='active' AND expiry_date BETWEEN ? AND ?", now, in7days).c;
    db.close();
    return { source: "live", pendingPayments, openTickets, expiringSoon, total: pendingPayments + openTickets };
  } catch {
    try { db.close(); } catch { /* */ }
    return { source: "error", pendingPayments: 0, openTickets: 0, expiringSoon: 0, total: 0 };
  }
}

export async function GET(req: NextRequest) {
  if (!requireAuth(req as unknown as Request)) {
    return new Response("Unauthorized", { status: 401 });
  }

  const encoder = new TextEncoder();
  let closed = false;

  const stream = new ReadableStream({
    start(controller) {
      const send = (data: object) => {
        if (closed) return;
        try { controller.enqueue(encoder.encode("data: " + JSON.stringify(data) + "\n\n")); }
        catch { closed = true; }
      };

      send(getStats());

      const interval = setInterval(() => {
        if (closed) { clearInterval(interval); return; }
        send(getStats());
      }, 15000);

      req.signal.addEventListener("abort", () => {
        closed = true;
        clearInterval(interval);
        try { controller.close(); } catch { /* */ }
      });
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      "X-Accel-Buffering": "no",
      Connection: "keep-alive",
    },
  });
}
