import { NextRequest, NextResponse } from "next/server";
import { getBotDb, requireAuth } from "@/lib/botdb";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

export async function GET(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { searchParams } = new URL(req.url);

  // ── proxy عکس رسید از Telegram ──────────────────────────────
  const fileId = searchParams.get("file_id");
  if (fileId) {
    const token = process.env.BOT_TOKEN ?? "";
    if (!token) return NextResponse.json({ error: "BOT_TOKEN not set" }, { status: 503 });
    try {
      // Step 1: دریافت file_path از Telegram
      const infoRes = await fetch(`https://api.telegram.org/bot${token}/getFile?file_id=${encodeURIComponent(fileId)}`);
      const info = await infoRes.json() as { ok: boolean; result?: { file_path: string } };
      if (!info.ok || !info.result?.file_path) {
        return NextResponse.json({ error: "File not found on Telegram" }, { status: 404 });
      }
      // Step 2: دانلود فایل
      const fileRes = await fetch(`https://api.telegram.org/file/bot${token}/${info.result.file_path}`);
      if (!fileRes.ok) return NextResponse.json({ error: "Download failed" }, { status: 502 });
      const blob = await fileRes.arrayBuffer();
      const ct = fileRes.headers.get("content-type") ?? "image/jpeg";
      return new NextResponse(blob, {
        headers: { "Content-Type": ct, "Cache-Control": "private, max-age=3600" },
      });
    } catch (e) {
      return NextResponse.json({ error: String(e) }, { status: 500 });
    }
  }

  const page   = Math.max(1, Number(searchParams.get("page") ?? 1));
  const limit  = Math.min(50, Number(searchParams.get("limit") ?? 20));
  const offset = (page - 1) * limit;
  const status = searchParams.get("status") ?? null;

  const db = getBotDb(true);
  if (!db) return NextResponse.json({ payments: [], total: 0, source: "unavailable" });

  try {
    const where = status ? "WHERE p.status = ?" : "";
    const params: unknown[] = status ? [status] : [];
    const total = (db.prepare(`SELECT COUNT(*) as c FROM payments p ${where}`).get(...params) as { c: number }).c;
    const payments = db.prepare(`
      SELECT p.id, p.order_id, p.amount_usdt, p.amount_rial, p.status, p.payment_method,
             p.receipt_file_id, p.receipt_type, p.created_at,
             u.telegram_id, u.username, u.first_name
      FROM payments p LEFT JOIN users u ON u.id = p.user_id
      ${where}
      ORDER BY p.created_at DESC LIMIT ? OFFSET ?
    `).all(...params, limit, offset);
    db.close();
    return NextResponse.json({ payments, total, page, limit, source: "live" });
  } catch (e) { db.close(); return NextResponse.json({ error: String(e) }, { status: 500 }); }
}

// ── helper: ارسال پیام تلگرام به کاربر ──────────────────────────
async function tgSend(chatId: number | string, text: string): Promise<boolean> {
  const token = process.env.BOT_TOKEN ?? "";
  if (!token || !chatId) return false;
  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML" }),
    });
    const d = await res.json() as { ok: boolean };
    return d.ok;
  } catch { return false; }
}

// ── helper: ربات رو trigger کن تا اشتراک بسازه ─────────────────
// با قرار دادن یک ردیف در جدول pending_actions، ربات polling می‌کنه
// اگه جدول pending_actions وجود نداشت، فقط وضعیت DB آپدیت میشه
// و ربات دفعه بعدی که کاربر پیامی بفرسته متوجه میشه
async function triggerBotApproval(
  db: import("better-sqlite3").Database,
  orderId: string,
  telegramId: number,
  orderIdStr: string,
): Promise<void> {
  // ── روش ۱: جدول pending_actions (اگه ربات آماده باشه)
  try {
    db.prepare(`
      INSERT OR IGNORE INTO pending_actions (type, payload, created_at)
      VALUES ('card_approve', ?, datetime('now'))
    `).run(JSON.stringify({ order_id: orderId, telegram_id: telegramId }));
  } catch {
    // جدول pending_actions وجود نداره — ایرادی نداره
  }
}

// POST: approve or reject a card payment + notify user via Telegram
export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const body = await req.json().catch(() => ({})) as Record<string, unknown>;
  const { action, payment_id } = body;
  if (!payment_id || !["approve","reject","expire"].includes(action as string)) {
    return NextResponse.json({ error: "payment_id and action (approve|reject|expire) required" }, { status: 400 });
  }

  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "DB unavailable" }, { status: 503 });

  try {
    const now = new Date().toISOString();

    // دریافت اطلاعات payment + user
    const row = db.prepare(`
      SELECT p.*, u.telegram_id, u.first_name, u.username
      FROM payments p
      LEFT JOIN users u ON u.id = p.user_id
      WHERE p.id = ?
    `).get(Number(payment_id)) as Record<string, unknown> | undefined;

    if (!row) {
      db.close();
      return NextResponse.json({ error: "Payment not found" }, { status: 404 });
    }

    // جلوگیری از تأیید مجدد
    if (row.status === "confirmed" || row.status === "finished") {
      db.close();
      return NextResponse.json({ error: "Payment already confirmed" }, { status: 409 });
    }

    const telegramId = Number(row.telegram_id ?? 0);
    const orderId    = String(row.order_id ?? "");
    const amountUsdt = Number(row.amount_usdt ?? 0);
    const amountRial = Number(row.amount_rial ?? 0);

    if (action === "approve") {
      // آپدیت وضعیت payment
      db.prepare("UPDATE payments SET status = 'confirmed', updated_at = ? WHERE id = ?")
        .run(now, Number(payment_id));

      // trigger ربات برای ساختن اشتراک
      await triggerBotApproval(db, orderId, telegramId, orderId);

      db.close();

      // ارسال پیام به کاربر از طریق Telegram Bot API
      if (telegramId) {
        const amountStr = amountRial
          ? `${amountRial.toLocaleString()} ریال`
          : `${amountUsdt} USDT`;

        await tgSend(
          telegramId,
          `✅ <b>پرداخت شما تأیید شد!</b>\n` +
          `━━━━━━━━━━━━━━━\n` +
          `🔖 سفارش: <code>${orderId}</code>\n` +
          `💰 مبلغ: ${amountStr}\n\n` +
          `⏳ در حال ساخت اشتراک VPN...\n` +
          `لطفاً چند لحظه صبر کنید و دکمه <b>اشتراک‌های من</b> را بزنید.\n\n` +
          `اگر اشتراک نمایش داده نشد، با پشتیبانی تماس بگیرید:\n` +
          `🔖 کد پیگیری: <code>${orderId}</code>`
        );
      }

      return NextResponse.json({ ok: true, notified: !!telegramId });

    } else if (action === "reject") {
      // رد کردن پرداخت
      db.prepare("UPDATE payments SET status = 'failed', updated_at = ? WHERE id = ?")
        .run(now, Number(payment_id));
      db.close();

      if (telegramId) {
        await tgSend(
          telegramId,
          `❌ <b>پرداخت شما تأیید نشد.</b>\n` +
          `━━━━━━━━━━━━━━━\n` +
          `🔖 سفارش: <code>${orderId}</code>\n\n` +
          `در صورت نیاز به راهنمایی با پشتیبانی تماس بگیرید.`
        );
      }
      return NextResponse.json({ ok: true, notified: !!telegramId });

    } else {
      // expire — منقضی کردن تراکنش کریپتو
      db.prepare("UPDATE payments SET status = 'expired', updated_at = ? WHERE id = ?")
        .run(now, Number(payment_id));
      db.close();

      if (telegramId) {
        await tgSend(
          telegramId,
          `⏰ <b>فاکتور پرداخت شما منقضی شد.</b>\n` +
          `━━━━━━━━━━━━━━━\n` +
          `🔖 سفارش: <code>${orderId}</code>\n\n` +
          `برای خرید مجدد از ربات اقدام کنید.`
        );
      }
      return NextResponse.json({ ok: true, notified: !!telegramId });
    }

  } catch (e) {
    try { db.close(); } catch { /* ignore */ }
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
