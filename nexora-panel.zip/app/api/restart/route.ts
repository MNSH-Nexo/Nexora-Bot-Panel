/**
 * POST /api/restart
 * body: { target: "bot" | "panel" | "both" }
 */
import { NextRequest, NextResponse } from "next/server";
import { requireAuth } from "@/lib/botdb";
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);
function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

async function tryCommand(cmd: string): Promise<{ ok: boolean; out: string }> {
  try {
    const { stdout, stderr } = await execAsync(cmd, { timeout: 15000 });
    return { ok: true, out: (stdout + stderr).trim() };
  } catch (e: unknown) {
    const err = e as { message?: string; stderr?: string };
    return { ok: false, out: err?.stderr ?? err?.message ?? String(e) };
  }
}

export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { target } = await req.json().catch(() => ({ target: "bot" }));
  const results: Array<{ label: string; ok: boolean; out: string }> = [];

  // ── ری‌استارت ربات ──────────────────────────────────────
  if (target === "bot" || target === "both") {
    const candidates = [
      { label: "docker compose (nexora)", cmd: "cd /opt/nexora-bot && docker compose restart bot 2>&1 | tail -5" },
      { label: "systemctl nexora-bot",    cmd: "systemctl restart nexora-bot 2>&1 | tail -5" },
      { label: "supervisorctl nexora-bot", cmd: "supervisorctl restart nexora-bot 2>&1 | tail -5" },
    ];

    let restarted = false;
    for (const c of candidates) {
      const r = await tryCommand(c.cmd);
      if (r.ok) {
        results.push({ label: c.label, ok: true, out: r.out || "ربات با موفقیت ری‌استارت شد" });
        restarted = true;
        break;
      }
    }
    if (!restarted) {
      results.push({ label: "ربات", ok: false, out: "روش ری‌استارت یافت نشد" });
    }
  }

  // ── ری‌استارت وب‌پنل ────────────────────────────────────
  if (target === "panel" || target === "both") {
    // چون پنل با systemd اجرا میشه، systemctl restart خودش رو kill میکنه قبل از ارسال response
    // راه‌حل: اول response رو میفرستیم، بعد با تاخیر کوچک restart میکنیم

    results.push({
      label: "systemctl nexora-panel",
      ok: true,
      out: "وب‌پنل در حال ری‌استارت است — لحظاتی دیگر در دسترس خواهد بود"
    });

    // ارسال response قبل از restart
    const response = NextResponse.json({ ok: true, results, selfRestart: true });

    // بعد از ارسال response، با 1 ثانیه تاخیر restart میکنیم
    setTimeout(async () => {
      // اگه pm2 وجود داره از اون استفاده کن (بدون kill)
      const pm2Check = await tryCommand("which pm2 2>/dev/null || /usr/local/bin/pm2 --version 2>/dev/null");
      if (pm2Check.ok) {
        await tryCommand("pm2 restart nexora-panel 2>&1").catch(() => {});
      } else {
        // systemd — process.exit باعث میشه systemd خودش restart کنه (Restart=always)
        process.exit(0);
      }
    }, 1000);

    return response;
  }

  const allOk = results.every(r => r.ok);
  return NextResponse.json({ ok: allOk, results });
}
