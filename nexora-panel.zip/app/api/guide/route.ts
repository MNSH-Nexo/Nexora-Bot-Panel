/**
 * GET  /api/guide  — خواندن متن راهنما
 * POST /api/guide  — ذخیره متن راهنما
 */
import { NextRequest, NextResponse } from "next/server";
import { getBotDb, requireAuth } from "@/lib/botdb";

function auth(req: NextRequest) { return requireAuth(req as unknown as Request); }

export async function GET(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const db = getBotDb(true);
  if (!db) return NextResponse.json({ text: "" });
  try {
    const row = db.prepare(
      "SELECT value FROM admin_settings WHERE key = 'guide_text'"
    ).get() as { value: string } | undefined;
    db.close();
    return NextResponse.json({ text: row?.value ?? "" });
  } catch { db.close(); return NextResponse.json({ text: "" }); }
}

export async function POST(req: NextRequest) {
  if (!auth(req)) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { text } = await req.json().catch(() => ({ text: "" }));
  if (typeof text !== "string")
    return NextResponse.json({ error: "متن نامعتبر" }, { status: 400 });

  const db = getBotDb(false);
  if (!db) return NextResponse.json({ error: "دیتابیس در دسترس نیست" }, { status: 503 });
  try {
    db.prepare(
      "INSERT INTO admin_settings (key, value) VALUES ('guide_text', ?) " +
      "ON CONFLICT(key) DO UPDATE SET value = excluded.value"
    ).run(text.trim());
    db.close();
    return NextResponse.json({ ok: true });
  } catch (e) { db.close(); return NextResponse.json({ error: String(e) }, { status: 500 }); }
}
