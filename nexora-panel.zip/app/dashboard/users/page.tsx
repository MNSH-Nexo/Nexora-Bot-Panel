"use client";
import React, { useState, useEffect, useCallback, useRef } from "react";
import { apiFetch } from "@/lib/api";
import {
  RefreshCw, Search, Shield, ChevronLeft, ChevronRight,
  ChevronDown, ChevronUp, AlertCircle, Loader2, RotateCcw,
  Trash2, ToggleLeft, ToggleRight, Package, Pencil, X, Save,
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

interface User {
  id: number;
  telegram_id: string;
  username: string | null;
  first_name: string | null;
  is_admin: 0 | 1;
  created_at: string;
  sub_count: number;
  active_until: string | null;
}

interface UsersResponse {
  users: User[];
  total: number;
  source: string;
}

type SubStatus = "active" | "expired" | "depleted" | "disabled" | string;

interface Subscription {
  id: number;
  email: string;
  traffic_limit_gb: number | null;
  used_traffic_bytes: number;
  expiry_date: string | null;
  limit_ip: number | null;
  status: SubStatus;
  inbound_id: number | null;
  created_at: string;
}

interface SubsResponse {
  subscriptions: Subscription[];
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

const LIMIT = 20;

function formatDate(iso: string | null): string {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleDateString("fa-IR", {
      year: "numeric", month: "short", day: "numeric",
    });
  } catch {
    return iso;
  }
}

function bytesToGb(bytes: number): string {
  return (bytes / 1073741824).toFixed(2);
}

function userLabel(u: User): string {
  return u.first_name ?? u.username ?? u.telegram_id;
}

function avatarLetter(u: User): string {
  const label = u.first_name ?? u.username ?? u.telegram_id;
  return label.charAt(0).toUpperCase();
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function SubStatusBadge({ status }: { status: SubStatus }) {
  const map: Record<string, { label: string; cls: string }> = {
    active:   { label: "فعال",    cls: "bg-green-500/10 text-green-400 border-green-500/30" },
    expired:  { label: "منقضی",   cls: "bg-yellow-500/10 text-yellow-400 border-yellow-500/30" },
    depleted: { label: "پر شده",  cls: "bg-orange-500/10 text-orange-400 border-orange-500/30" },
    disabled: { label: "غیرفعال", cls: "bg-muted/20 text-muted-foreground border-border/40" },
  };
  const item = map[status] ?? { label: status, cls: "bg-muted/20 text-muted-foreground border-border/40" };
  return (
    <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full border ${item.cls}`}>
      {item.label}
    </span>
  );
}

function TableSkeleton() {
  return (
    <div className="space-y-2">
      {Array.from({ length: 3 }).map((_, i) => (
        <div key={i} className="rounded-xl bg-card/40 border border-border/30 animate-pulse h-14" />
      ))}
    </div>
  );
}

// ─── Edit Subscription Modal ──────────────────────────────────────────────────

function EditSubModal({ sub, onClose, onSaved }: { sub: Subscription; onClose: () => void; onSaved: () => void }) {
  const [field, setField] = useState<"days" | "traffic" | "email">("days");
  const [value, setValue] = useState("");
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const fieldMeta = {
    days:    { label: "تمدید (روز)", hint: "مثبت = تمدید، منفی = کاهش. مثال: 30", type: "number" },
    traffic: { label: "حجم (GB)",    hint: "حجم کل جدید — 0 = نامحدود", type: "number" },
    email:   { label: "ایمیل",       hint: "شناسه جدید در 3X-UI", type: "text" },
  };

  const handleSave = async () => {
    if (!value.trim()) return;
    setSaving(true); setErr(null);
    try {
      const res = await apiFetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "edit_sub", sub_id: sub.id, field, value: value.trim() }),
      });
      if (!res.ok) throw new Error("عملیات ناموفق بود");
      onSaved(); onClose();
    } catch (e) { setErr(e instanceof Error ? e.message : "خطا"); }
    finally { setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm" dir="rtl">
      <div className="bg-card border border-border rounded-2xl shadow-2xl w-full max-w-sm mx-4 p-5 space-y-4">
        <div className="flex items-center justify-between">
          <p className="text-sm font-bold text-foreground">✏️ ویرایش اشتراک</p>
          <button onClick={onClose} className="p-1 rounded-lg text-muted-foreground hover:text-foreground transition-colors"><X className="w-4 h-4" /></button>
        </div>
        <p className="text-xs font-mono text-muted-foreground bg-muted/20 px-3 py-1.5 rounded-lg">{sub.email}</p>
        <div className="flex gap-1.5">
          {(["days", "traffic", "email"] as const).map(f => (
            <button key={f} onClick={() => { setField(f); setValue(""); setErr(null); }}
              className={`flex-1 px-2 py-1.5 rounded-lg text-xs font-medium transition-colors ${field === f ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
              {fieldMeta[f].label}
            </button>
          ))}
        </div>
        <div className="space-y-1">
          <input type={fieldMeta[field].type} value={value} onChange={e => setValue(e.target.value)}
            placeholder={fieldMeta[field].hint} dir="ltr"
            className="w-full px-3 py-2 rounded-xl bg-input border border-border text-sm text-foreground focus:outline-none focus:border-primary/60 transition-colors" />
          <p className="text-[10px] text-muted-foreground/60">{fieldMeta[field].hint}</p>
        </div>
        {err && <p className="text-xs text-red-400">{err}</p>}
        <div className="flex gap-2 pt-1">
          <button onClick={handleSave} disabled={saving || !value.trim()}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-primary text-primary-foreground text-sm font-semibold hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            {saving ? "در حال ذخیره..." : "ذخیره"}
          </button>
          <button onClick={onClose} className="px-4 py-2 rounded-xl bg-secondary text-muted-foreground text-sm hover:text-foreground transition-colors">انصراف</button>
        </div>
        <p className="text-[10px] text-muted-foreground/50 text-center">تغییرات از طریق ربات به 3X-UI اعمال می‌شود</p>
      </div>
    </div>
  );
}

// ─── Subscription Panel ───────────────────────────────────────────────────────

function SubscriptionPanel({ userId }: { userId: number }) {
  const [subs, setSubs]         = useState<Subscription[] | null>(null);
  const [loading, setLoading]   = useState(true);
  const [error, setError]       = useState<string | null>(null);
  const [actionId, setActionId] = useState<number | null>(null);
  const [editSub, setEditSub]   = useState<Subscription | null>(null);

  const fetchSubs = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const res = await apiFetch(`/api/users?user_id=${userId}`);
      if (!res.ok) throw new Error(`خطا: ${res.status}`);
      const json: SubsResponse = await res.json();
      setSubs(json.subscriptions);
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطا");
    } finally { setLoading(false); }
  }, [userId]);

  useEffect(() => { fetchSubs(); }, [fetchSubs]);

  const doAction = useCallback(async (
    sub: Subscription,
    action: "reset_traffic" | "toggle" | "delete" | "permanent_delete"
  ) => {
    if (action === "delete" && !confirm(`حذف اشتراک «${sub.email}» از 3X-UI؟`)) return;
    if (action === "permanent_delete" && !confirm(`حذف دائمی «${sub.email}» از لیست؟\nاین عمل برگشت‌ناپذیر است.`)) return;
    setActionId(sub.id);
    try {
      const res = await apiFetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action, sub_id: sub.id }),
      });
      const json = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(json?.error ?? `خطای سرور (${res.status})`);

      // ── Optimistic UI update ──
      setSubs(prev => {
        if (!prev) return prev;
        if (action === "permanent_delete") {
          return prev.filter(s => s.id !== sub.id);
        }
        return prev.map(s => {
          if (s.id !== sub.id) return s;
          if (action === "delete")         return { ...s, status: "deleted" };
          if (action === "toggle")         return { ...s, status: s.status === "disabled" ? "active" : "disabled" };
          if (action === "reset_traffic")  return { ...s, used_traffic_bytes: 0 };
          return s;
        });
      });

      // برای delete: بعد از ۱۵ ثانیه (پس از پردازش ربات) یک بار رفرش کنیم
      if (action === "delete") {
        setTimeout(() => fetchSubs(), 16000);
      }
    } catch (e) {
      alert(e instanceof Error ? e.message : "خطا");
    } finally { setActionId(null); }
  }, [fetchSubs]);

  if (loading) {
    return (
      <div className="p-4 border-t border-border/30 bg-muted/5">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="w-3.5 h-3.5 animate-spin" />
          در حال بارگذاری اشتراک‌ها...
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 border-t border-border/30 bg-muted/5 flex items-center gap-2 text-xs text-red-400">
        <AlertCircle className="w-3.5 h-3.5" />
        {error}
      </div>
    );
  }

  if (!subs?.length) {
    return (
      <div className="p-4 border-t border-border/30 bg-muted/5 flex items-center gap-2 text-xs text-muted-foreground">
        <Package className="w-3.5 h-3.5" />
        اشتراکی یافت نشد
      </div>
    );
  }

  return (
    <>
      {editSub && <EditSubModal sub={editSub} onClose={() => setEditSub(null)} onSaved={fetchSubs} />}
      <div className="border-t border-border/30 bg-muted/5 overflow-x-auto">
        <table className="w-full text-xs min-w-[600px]">
          <thead>
            <tr className="border-b border-border/20">
              {["ایمیل / شناسه", "ترافیک", "انقضا", "وضعیت", "عملیات"].map(h => (
                <th key={h} className="text-right text-muted-foreground/70 font-medium py-2 px-4 first:pr-4">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border/10">
            {subs.map(sub => (
              <tr key={sub.id} className={`hover:bg-muted/10 transition-colors ${sub.status === "deleted" ? "opacity-60" : ""}`}>
                <td className="py-2 px-4">
                  <span className="font-mono text-[10px] text-foreground/80">{sub.email}</span>
                </td>
                <td className="py-2 px-4">
                  <div className="flex items-center gap-2">
                    <div className="w-16 h-1.5 rounded-full bg-muted/30 overflow-hidden">
                      {sub.traffic_limit_gb ? (
                        <div className="h-full rounded-full bg-primary/70"
                          style={{ width: `${Math.min(100, (Number(bytesToGb(sub.used_traffic_bytes)) / sub.traffic_limit_gb) * 100)}%` }} />
                      ) : null}
                    </div>
                    <span className="text-muted-foreground whitespace-nowrap">
                      {bytesToGb(sub.used_traffic_bytes)} / {sub.traffic_limit_gb ?? "نامحدود"} GB
                    </span>
                  </div>
                </td>
                <td className="py-2 px-4 text-muted-foreground whitespace-nowrap">{formatDate(sub.expiry_date)}</td>
                <td className="py-2 px-4"><SubStatusBadge status={sub.status} /></td>
                <td className="py-2 px-4">
                  <div className="flex items-center gap-1">
                    {/* ✏️ ویرایش — برای همه */}
                    <button onClick={() => setEditSub(sub)} disabled={actionId === sub.id} title="ویرایش اشتراک"
                      className="p-1.5 rounded-lg border border-purple-500/20 bg-purple-500/5 text-purple-400 hover:bg-purple-500/15 transition-colors disabled:opacity-50">
                      <Pencil className="w-3 h-3" />
                    </button>
                    {/* دکمه‌های عادی فقط برای غیر‌حذف‌شده */}
                    {sub.status !== "deleted" && (
                      <>
                        <button onClick={() => doAction(sub, "reset_traffic")} disabled={actionId === sub.id} title="ریست ترافیک"
                          className="p-1.5 rounded-lg border border-blue-500/20 bg-blue-500/5 text-blue-400 hover:bg-blue-500/15 transition-colors disabled:opacity-50">
                          {actionId === sub.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <RotateCcw className="w-3 h-3" />}
                        </button>
                        <button onClick={() => doAction(sub, "toggle")} disabled={actionId === sub.id}
                          title={sub.status === "disabled" ? "فعال کردن" : "غیرفعال کردن"}
                          className="p-1.5 rounded-lg border border-yellow-500/20 bg-yellow-500/5 text-yellow-400 hover:bg-yellow-500/15 transition-colors disabled:opacity-50">
                          {sub.status === "disabled" ? <ToggleLeft className="w-3 h-3" /> : <ToggleRight className="w-3 h-3" />}
                        </button>
                        <button onClick={() => doAction(sub, "delete")} disabled={actionId === sub.id} title="حذف از 3X-UI"
                          className="p-1.5 rounded-lg border border-red-500/20 bg-red-500/5 text-red-400 hover:bg-red-500/15 transition-colors disabled:opacity-50">
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </>
                    )}
                    {/* 🗑 حذف دائمی — فقط برای اشتراک‌های حذف‌شده */}
                    {sub.status === "deleted" && (
                      <button onClick={() => doAction(sub, "permanent_delete")} disabled={actionId === sub.id}
                        title="حذف دائمی از لیست"
                        className="flex items-center gap-1 px-2 py-1.5 rounded-lg border border-red-600/30 bg-red-600/10 text-red-500 hover:bg-red-600/20 transition-colors disabled:opacity-50 text-[10px]">
                        {actionId === sub.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <><Trash2 className="w-3 h-3" />دائمی</>}
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

// ─── Main Page ────────────────────────────────────────────────────────────────

export default function UsersPage() {
  const [data, setData]           = useState<UsersResponse | null>(null);
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState<string | null>(null);
  const [search, setSearch]       = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [page, setPage]           = useState(1);
  const [expandedUserId, setExpandedUserId] = useState<number | null>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Debounce search input
  const handleSearchChange = useCallback((val: string) => {
    setSearch(val);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      setDebouncedSearch(val);
      setPage(1);
      setExpandedUserId(null);
    }, 500);
  }, []);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ page: String(page), limit: String(LIMIT) });
      if (debouncedSearch) params.set("search", debouncedSearch);
      const res = await apiFetch(`/api/users?${params}`);
      if (!res.ok) throw new Error(`خطا: ${res.status}`);
      const json: UsersResponse = await res.json();
      setData(json);
    } catch (e) {
      setError(e instanceof Error ? e.message : "خطای ناشناخته");
    } finally {
      setLoading(false);
    }
  }, [page, debouncedSearch]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const toggleExpand = useCallback((userId: number) => {
    setExpandedUserId(prev => prev === userId ? null : userId);
  }, []);

  const totalPages = data ? Math.ceil(data.total / LIMIT) : 1;

  return (
    <div className="space-y-6 animate-in-up" dir="rtl">

      {/* ── Header ── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">مدیریت کاربران</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {data && `${data.total} کاربر`}
            {data && (
              <span className={`mr-2 ${data.source === "live" ? "text-green-400" : "text-yellow-400"}`}>
                • {data.source === "live" ? "زنده" : "ناموجود"}
              </span>
            )}
          </p>
        </div>
        <button
          onClick={fetchData}
          disabled={loading}
          className="px-3 py-1.5 rounded-lg text-xs font-medium border border-border/60 bg-card hover:bg-card/80 transition-colors flex items-center gap-1.5 text-muted-foreground"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          بروزرسانی
        </button>
      </div>

      {/* ── Search ── */}
      <div className="rounded-2xl border border-border/60 bg-card p-3">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          <input
            value={search}
            onChange={e => handleSearchChange(e.target.value)}
            placeholder="جستجو بر اساس نام، نام کاربری یا شناسه تلگرام..."
            className="w-full pr-9 pl-4 py-2.5 rounded-xl bg-input border border-border text-sm focus:outline-none focus:border-primary/50 text-foreground placeholder-muted-foreground/50"
          />
        </div>
      </div>

      {/* ── Table Card ── */}
      <div className="rounded-2xl border border-border/60 bg-card overflow-hidden">
        <div className="p-4">
          {loading ? (
            <TableSkeleton />
          ) : error ? (
            <div className="flex flex-col items-center gap-3 py-12 text-center">
              <AlertCircle className="w-8 h-8 text-red-400" />
              <p className="text-sm text-red-400">{error}</p>
              <button onClick={fetchData} className="px-3 py-1.5 rounded-lg text-xs font-medium border border-border/60 bg-card hover:bg-card/80 transition-colors text-muted-foreground">
                تلاش مجدد
              </button>
            </div>
          ) : !data?.users.length ? (
            <div className="flex flex-col items-center gap-2 py-12 text-center">
              <Search className="w-8 h-8 text-muted-foreground/40" />
              <p className="text-sm text-muted-foreground">کاربری یافت نشد</p>
            </div>
          ) : (
            <div className="overflow-x-auto -mx-1">
              <table className="w-full text-xs min-w-[580px]">
                <thead>
                  <tr className="border-b border-border/40">
                     {["نام", "آیدی / یوزرنیم", "تاریخ عضویت", "اشتراک‌ها", "ادمین", "عملیات"].map(h => (
                      <th key={h} className="text-right text-muted-foreground font-medium py-2 px-2 first:pr-0 last:pl-0">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.users.map(u => (
                    <React.Fragment key={u.id}>
                      <tr
                        className="border-b border-border/20 hover:bg-muted/10 transition-colors"
                      >
                        {/* Name + Avatar */}
                         <td className="py-3 px-2 first:pr-0">
                           <div className="flex items-center gap-2">
                             <div className="w-7 h-7 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center text-[11px] font-bold text-primary shrink-0">
                               {avatarLetter(u)}
                             </div>
                             <div className="flex flex-col min-w-0">
                               <span className="text-foreground font-medium truncate">{userLabel(u)}</span>
                               {u.first_name && u.username && (
                                 <span className="text-[10px] text-muted-foreground/60 truncate">@{u.username}</span>
                               )}
                             </div>
                           </div>
                         </td>
                        {/* Telegram ID + username */}
                         <td className="py-3 px-2 hidden sm:table-cell">
                           <div className="flex flex-col gap-0.5">
                             <span className="font-mono text-[10px] text-muted-foreground">{u.telegram_id}</span>
                             {u.username && (
                               <span className="text-[10px] text-primary/70 font-medium">@{u.username}</span>
                             )}
                           </div>
                         </td>
                        {/* Join date */}
                        <td className="py-3 px-2 text-muted-foreground whitespace-nowrap">
                          {formatDate(u.created_at)}
                        </td>
                        {/* Sub count */}
                        <td className="py-3 px-2">
                          {u.sub_count > 0 ? (
                            <span className="text-[10px] font-medium px-2 py-0.5 rounded-full border border-purple-500/30 bg-purple-500/10 text-purple-400">
                              {u.sub_count} اشتراک
                            </span>
                          ) : (
                            <span className="text-[10px] text-muted-foreground/40">—</span>
                          )}
                        </td>
                        {/* Admin */}
                        <td className="py-3 px-2">
                          {u.is_admin === 1 ? (
                            <Shield className="w-4 h-4 text-yellow-400" aria-label="ادمین" />
                          ) : (
                            <span className="text-muted-foreground/30">—</span>
                          )}
                        </td>
                        {/* Actions */}
                        <td className="py-3 px-2 last:pl-0">
                          <button
                            onClick={() => toggleExpand(u.id)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors flex items-center gap-1 ${
                              expandedUserId === u.id
                                ? "border-primary/40 bg-primary/20 text-primary"
                                : "border-border/60 bg-card hover:bg-muted/20 text-muted-foreground"
                            }`}
                          >
                            {expandedUserId === u.id ? (
                              <><ChevronUp className="w-3.5 h-3.5" /> بستن</>
                            ) : (
                              <><ChevronDown className="w-3.5 h-3.5" /> جزئیات</>
                            )}
                          </button>
                        </td>
                      </tr>
                      {expandedUserId === u.id && (
                        <tr key={`${u.id}-subs`}>
                          <td colSpan={6} className="p-0">
                            <SubscriptionPanel userId={u.id} />
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* ── Pagination ── */}
        {!loading && !error && totalPages > 1 && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-border/40">
            <span className="text-xs text-muted-foreground">
              صفحه {page} از {totalPages} — {data?.total} کاربر
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
                className="px-3 py-1.5 rounded-lg text-xs font-medium border border-border/60 bg-card hover:bg-muted/20 disabled:opacity-40 transition-colors flex items-center gap-1 text-muted-foreground"
              >
                <ChevronRight className="w-3.5 h-3.5" />
                قبلی
              </button>
              <button
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                className="px-3 py-1.5 rounded-lg text-xs font-medium border border-border/60 bg-card hover:bg-muted/20 disabled:opacity-40 transition-colors flex items-center gap-1 text-muted-foreground"
              >
                بعدی
                <ChevronLeft className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
