"use client";
import { apiFetch, getWebPrefix } from "@/lib/api";
import { useEffect, useState, useCallback } from "react";
import {
  Save, CreditCard, Coins, ToggleLeft, ToggleRight,
  Image as ImageIcon, Megaphone, Link2, RefreshCw, CheckCircle2, AlertCircle,
  Bot, Palette, Upload, X,
} from "lucide-react";
import { useRef } from "react";

// ── client-side resize با Canvas API ─────────────────────────
async function resizeImageClientSide(
  file: File,
  maxSize: number,
  outputType: "image/png" | "image/webp" = "image/png",
): Promise<File> {
  return new Promise((resolve, reject) => {
    const img = new window.Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      URL.revokeObjectURL(url);
      const { naturalWidth: w, naturalHeight: h } = img;
      // اگه ابعاد در محدوده مجاز بود، نیازی به resize نیست
      if (w <= maxSize && h <= maxSize && file.size < 300 * 1024) {
        resolve(file);
        return;
      }
      const scale = Math.min(maxSize / w, maxSize / h, 1);
      const nw = Math.max(1, Math.round(w * scale));
      const nh = Math.max(1, Math.round(h * scale));
      const canvas = document.createElement("canvas");
      canvas.width  = nw;
      canvas.height = nh;
      const ctx = canvas.getContext("2d");
      if (!ctx) { resolve(file); return; }
      ctx.clearRect(0, 0, nw, nh);
      ctx.drawImage(img, 0, 0, nw, nh);
      canvas.toBlob(blob => {
        if (!blob) { resolve(file); return; }
        const ext = outputType === "image/webp" ? "webp" : "png";
        resolve(new File([blob], `${file.name.replace(/\.[^.]+$/, "")}.${ext}`, { type: outputType }));
      }, outputType, 0.92);
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("Image load failed")); };
    img.src = url;
  });
}

type Config = Record<string, string>;

const DEFAULTS: Config = {
  card_number: "", card_holder: "", usdt_to_toman_rate: "90000",
  payment_crypto_enabled: "1", payment_card_enabled: "1",
  payment_crypto_invoice: "0", crypto_gateway: "maxelpay",
  test_sub_enabled: "1", test_sub_traffic_gb: "1", test_sub_duration_days: "1",
  welcome_banner_caption: "", join_channel_id: "",
  join_channel_link: "", join_channel_title: "",
  referral_reward_days: "3",
};

export default function SettingsPage() {
  const [config, setConfig]   = useState<Config>(DEFAULTS);
  const [source, setSource]   = useState("loading");
  const [saving, setSaving]   = useState(false);
  const [saved, setSaved]     = useState(false);
  const [error, setError]     = useState<string | null>(null);
  const [plans, setPlans]     = useState<Array<{id:number;name:string;traffic_gb:number;duration_days:number}>>([]);

  // Brand
  const [panelName, setPanelName]           = useState("NEXORA");
  const [tabTitle, setTabTitle]             = useState("");
  const [logoPreview, setLogoPreview]       = useState<string | null>(null);
  const [logoFile, setLogoFile]             = useState<File | null>(null);
  const [faviconPreview, setFaviconPreview] = useState<string | null>(null);
  const [faviconFile, setFaviconFile]       = useState<File | null>(null);
  const [brandSaving, setBrandSaving]       = useState(false);
  const [brandSaved, setBrandSaved]         = useState(false);
  const [brandError, setBrandError]         = useState<string | null>(null);
  const [resizing, setResizing]             = useState(false);
  const logoInputRef    = useRef<HTMLInputElement>(null);
  const faviconInputRef = useRef<HTMLInputElement>(null);

  // ── webpath برای ساختن URL کامل تصاویر ─────────────────
  const withPrefix = useCallback((url: string): string => {
    if (!url) return "";
    if (url.startsWith("http")) return url;
    const prefix = getWebPrefix();
    if (prefix && !url.startsWith(prefix)) return prefix + url;
    return url;
  }, []);

  const fetch$ = useCallback(async () => {
    try {
      const [cfgRes, brandRes] = await Promise.all([
        apiFetch("/api/bot-config"),
        apiFetch("/api/brand"),
      ]);
      if (cfgRes.ok) {
        const d = await cfgRes.json();
        setConfig({ ...DEFAULTS, ...(d.config ?? {}) });
        setSource(d.source ?? "unknown");
      }
      if (brandRes.ok) {
        const d = await brandRes.json();
        setPanelName(d.panelName ?? "NEXORA");
        setTabTitle(d.tabTitle ?? "");
        if (d.logoUrl)    setLogoPreview(withPrefix(d.logoUrl));
        if (d.faviconUrl) setFaviconPreview(withPrefix(d.faviconUrl));
      }
    } catch { setError("خطا در دریافت تنظیمات"); }
  }, [withPrefix]);

  useEffect(() => { fetch$(); }, [fetch$]);

  const set = (key: string, val: string) => setConfig(p => ({ ...p, [key]: val }));
  const toggle = (key: string) => setConfig(p => ({ ...p, [key]: p[key] === "1" ? "0" : "1" }));

  const handleSave = async () => {
    setSaving(true); setError(null);
    try {
      const res = await apiFetch("/api/bot-config", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify(config),
      });
      if (res.ok) { setSaved(true); setTimeout(() => setSaved(false), 2500); }
      else { const d = await res.json(); setError(d.error ?? "خطا در ذخیره"); }
    } catch { setError("خطا در اتصال"); }
    finally { setSaving(false); }
  };

  const handleBrandSave = async () => {
    setBrandSaving(true); setBrandError(null);
    try {
      // ── آپلود عکس‌ها ─────────────────────────────────────
      if (logoFile || faviconFile) {
        const form = new FormData();
        if (logoFile)    form.append("logo",    logoFile);
        if (faviconFile) form.append("favicon", faviconFile);
        const uploadRes = await apiFetch("/api/brand", { method: "POST", body: form });
        if (!uploadRes.ok) {
          const d = await uploadRes.json().catch(() => ({})) as Record<string, unknown>;
          setBrandError(String(d.error ?? "خطا در آپلود تصویر"));
          return;
        }
        const uploadData = await uploadRes.json() as Record<string, string>;
        // Preview را با URL سرور + webpath جایگزین کن
        if (uploadData.logoUrl)    { setLogoPreview(withPrefix(uploadData.logoUrl));    setLogoFile(null); }
        if (uploadData.faviconUrl) { setFaviconPreview(withPrefix(uploadData.faviconUrl)); setFaviconFile(null); }
      }

      // ── ذخیره فیلدهای متنی ───────────────────────────────
      const textRes = await apiFetch("/api/brand", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ panelName, tabTitle }),
      });
      if (!textRes.ok) {
        const d = await textRes.json().catch(() => ({})) as Record<string, unknown>;
        setBrandError(String(d.error ?? "خطا در ذخیره"));
        return;
      }

      setBrandSaved(true);
      setTimeout(() => setBrandSaved(false), 3000);

      // ── sidebar را آپدیت کن بدون reload ─────────────────
      // با BroadcastChannel به Sidebar می‌گوییم brand آپدیت شد
      try {
        const bc = new BroadcastChannel("nexora_brand");
        bc.postMessage({ type: "brand_updated" });
        bc.close();
      } catch { /* BroadcastChannel نباشه — مهم نیست */ }

    } catch (err) {
      setBrandError(err instanceof Error ? err.message : "خطا در اتصال");
    } finally {
      setBrandSaving(false);
    }
  };

  const handleLogoPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setBrandError(null);
    setResizing(true);
    try {
      const resized = await resizeImageClientSide(f, 256, "image/png");
      setLogoFile(resized);
      setLogoPreview(URL.createObjectURL(resized));
    } catch {
      setLogoFile(f);
      setLogoPreview(URL.createObjectURL(f));
    } finally { setResizing(false); }
  };

  const handleFaviconPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    setBrandError(null);
    setResizing(true);
    try {
      const resized = await resizeImageClientSide(f, 64, "image/png");
      setFaviconFile(resized);
      setFaviconPreview(URL.createObjectURL(resized));
    } catch {
      setFaviconFile(f);
      setFaviconPreview(URL.createObjectURL(f));
    } finally { setResizing(false); }
  };

  const unavailable = source === "unavailable";

  return (
    <div className="space-y-6 max-w-2xl">
      {/* Header */}
      <div className="animate-in-up flex items-center justify-between" style={{ animationDelay: "0ms" }}>
        <div>
          <h1 className="text-xl font-bold text-foreground">تنظیمات</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            پیکربندی کانال‌های پرداخت، بنرها و تنظیمات ربات
            {source === "live" && <span className="text-green-400/60 mr-2">• زنده</span>}
            {unavailable && <span className="text-yellow-400 mr-2">— دیتابیس در دسترس نیست</span>}
          </p>
        </div>
        <button onClick={fetch$} className="p-2 rounded-lg border border-border hover:border-primary/50 text-muted-foreground hover:text-primary transition-colors">
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {error && (
        <div className="flex items-center gap-2 px-4 py-3 rounded-xl border border-red-500/30 bg-red-500/8 text-red-300 text-sm">
          <AlertCircle className="w-4 h-4 shrink-0" />{error}
        </div>
      )}

      {/* ── روش‌های پرداخت ── */}
      <Section icon={Coins} title="روش‌های پرداخت" delay={60}>
        <ToggleRow label="پرداخت کریپتو" sub="MaxelPay / NOWPayments"
          on={config.payment_crypto_enabled === "1"} onToggle={() => toggle("payment_crypto_enabled")} />
        <div className="border-t border-border/40 pt-3">
          <ToggleRow label="پرداخت کارت به کارت" sub="تأیید دستی توسط ادمین"
            on={config.payment_card_enabled === "1"} onToggle={() => toggle("payment_card_enabled")} />
        </div>
        {config.payment_crypto_enabled === "1" && (
          <div className="pt-3 border-t border-border/40 space-y-3">
            <p className="text-xs font-medium text-muted-foreground">درگاه کریپتو</p>
            <div className="flex gap-2">
              {(["maxelpay","nowpayments"] as const).map(gw => (
                <button key={gw} onClick={() => set("crypto_gateway", gw)}
                  className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition-colors ${
                    config.crypto_gateway === gw ? "bg-primary/15 border-primary/50 text-primary" : "bg-secondary border-border text-muted-foreground hover:text-foreground"
                  }`}>
                  {gw === "maxelpay" ? "MaxelPay 💜" : "NOWPayments 🔵"}
                </button>
              ))}
            </div>
            {config.crypto_gateway === "nowpayments" && (
              <ToggleRow label="حالت Invoice (انتخاب ارز آزاد)" sub="غیرفعال = USDT TRC-20 مستقیم"
                on={config.payment_crypto_invoice === "1"} onToggle={() => toggle("payment_crypto_invoice")} />
            )}
          </div>
        )}
      </Section>

      {/* ── اطلاعات کارت ── */}
      {config.payment_card_enabled === "1" && (
        <Section icon={CreditCard} title="اطلاعات کارت بانکی" delay={120}>
          <Field label="شماره کارت" value={config.card_number} dir="ltr"
            placeholder="XXXX-XXXX-XXXX-XXXX" onChange={v => set("card_number", v)} mono />
          <Field label="نام صاحب کارت" value={config.card_holder}
            placeholder="نام و نام خانوادگی" onChange={v => set("card_holder", v)} />
        </Section>
      )}

      {/* ── نرخ ارز ── */}
      <Section icon={Coins} title="نرخ تبدیل USDT ← تومان" delay={180}>
        <div className="flex gap-2 items-center">
          <input value={config.usdt_to_toman_rate} dir="ltr"
            onChange={e => set("usdt_to_toman_rate", e.target.value)}
            className="flex-1 px-3 py-2.5 rounded-xl bg-input border border-border text-sm text-foreground font-mono focus:outline-none focus:border-primary/50 transition-colors" />
          <span className="text-sm text-muted-foreground shrink-0">تومان / دلار</span>
        </div>
        {config.usdt_to_toman_rate && !isNaN(Number(config.usdt_to_toman_rate)) && Number(config.usdt_to_toman_rate) > 0 && (
          <p className="text-xs text-muted-foreground">
            پلن ۵ دلاری = <span className="text-foreground font-semibold">{(5 * Number(config.usdt_to_toman_rate)).toLocaleString("fa-IR")} تومان</span>
          </p>
        )}
      </Section>

      {/* اشتراک تست از منوی مستقل مدیریت می‌شود */}


      {/* ── بنر ربات ── */}      {/* ── بنر ربات ── */}
      <Section icon={ImageIcon} title="بنر ربات" delay={300}>
        <p className="text-xs text-muted-foreground">بنر به عنوان عکس در پیام‌های ربات نمایش داده می‌شود. برای تنظیم، file_id عکس تلگرام را وارد کنید.</p>
        <Field label="file_id بنر ربات (از Telegram)" value={config.banner_file_id ?? ""}
          dir="ltr" mono placeholder="AgACAgIAAxkBAAI..." onChange={v => set("banner_file_id", v)} />
      </Section>

      {/* ── بنر خوشامدگویی ── */}
      <Section icon={Megaphone} title="بنر خوشامدگویی" delay={340}>
        <Field label="file_id بنر خوشامد (اختیاری)" value={config.welcome_banner_file_id ?? ""}
          dir="ltr" mono placeholder="AgACAgIAAxkBAAI..." onChange={v => set("welcome_banner_file_id", v)} />
        <div>
          <label className="text-xs text-muted-foreground mb-1.5 block">کپشن پیام خوشامدگویی</label>
          <textarea value={config.welcome_banner_caption}
            onChange={e => set("welcome_banner_caption", e.target.value)}
            rows={3} placeholder="👋 به ربات خوش آمدید!&#10;&#10;HTML پشتیبانی می‌شود: <b>bold</b>"
            className="w-full px-3 py-2 rounded-xl bg-input border border-border text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:border-primary/50 transition-colors resize-none leading-relaxed" />
        </div>
      </Section>

      {/* ── کانال اجباری ── */}
      <Section icon={Link2} title="کانال اجباری عضویت" delay={380}>
        <p className="text-xs text-muted-foreground">کاربران برای استفاده از ربات باید عضو این کانال باشند. خالی = غیرفعال.</p>
        <Field label="آیدی کانال (@username یا -100xxx)" value={config.join_channel_id}
          dir="ltr" mono placeholder="@mychannel" onChange={v => set("join_channel_id", v)} />
        <Field label="لینک دعوت کانال" value={config.join_channel_link}
          dir="ltr" mono placeholder="https://t.me/mychannel" onChange={v => set("join_channel_link", v)} />
        <Field label="نام نمایشی کانال" value={config.join_channel_title}
          placeholder="کانال ما" onChange={v => set("join_channel_title", v)} />
      </Section>

      {/* ── برند پنل ── */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4" style={{ animationDelay: "400ms" }}>
        <div className="flex items-center gap-2">
          <Palette className="w-4 h-4 text-primary" />
          <h2 className="text-sm font-semibold text-foreground">برند و ظاهر پنل مدیریت</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Panel name */}
          <div>
            <label className="text-xs text-muted-foreground mb-1.5 block">نام پنل (جایگزین NEXORA در sidebar)</label>
            <input value={panelName} onChange={e => setPanelName(e.target.value)}
              placeholder="NEXORA"
              className="w-full px-3 py-2.5 rounded-xl bg-input border border-border text-sm text-foreground font-semibold tracking-wide focus:outline-none focus:border-primary/50 transition-colors" />
          </div>
          {/* Tab title */}
          <div>
            <label className="text-xs text-muted-foreground mb-1.5 block">عنوان تب مرورگر (خالی = «نام پنل Admin Panel»)</label>
            <input value={tabTitle} onChange={e => setTabTitle(e.target.value)}
              placeholder={`${panelName || "NEXORA"} Admin Panel`}
              className="w-full px-3 py-2.5 rounded-xl bg-input border border-border text-sm text-foreground focus:outline-none focus:border-primary/50 transition-colors" />
          </div>
          {/* Logo upload */}
          <div>
            <label className="text-xs text-muted-foreground mb-1.5 block">لوگوی sidebar (PNG/JPG — ۱:۱)</label>
            <div className="flex items-center gap-3">
              {logoPreview && (
                <div className="relative shrink-0">
                  <img src={logoPreview} alt="logo" className="w-10 h-10 rounded-xl object-cover border border-border/60" />
                  <button onClick={() => { setLogoPreview(null); setLogoFile(null); if (logoInputRef.current) logoInputRef.current.value = ""; }}
                    className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-red-500 flex items-center justify-center">
                    <X className="w-2.5 h-2.5 text-white" />
                  </button>
                </div>
              )}
              <input ref={logoInputRef} type="file" accept="image/*" onChange={handleLogoPick} className="hidden" />
              <button onClick={() => logoInputRef.current?.click()}
                className="flex items-center gap-2 px-3 py-2 rounded-xl border border-border bg-secondary text-xs text-muted-foreground hover:text-foreground hover:border-primary/50 transition-colors">
                <Upload className="w-3.5 h-3.5" />
                {logoPreview ? "تغییر لوگو" : "آپلود لوگو"}
              </button>
            </div>
          </div>
          {/* Favicon upload */}
          <div>
            <label className="text-xs text-muted-foreground mb-1.5 block">آیکون تب مرورگر — Favicon (ICO/PNG/SVG)</label>
            <div className="flex items-center gap-3">
              {faviconPreview && (
                <div className="relative shrink-0">
                  <img src={faviconPreview} alt="favicon" className="w-8 h-8 rounded-lg object-cover border border-border/60" />
                  <button onClick={() => { setFaviconPreview(null); setFaviconFile(null); if (faviconInputRef.current) faviconInputRef.current.value = ""; }}
                    className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-red-500 flex items-center justify-center">
                    <X className="w-2.5 h-2.5 text-white" />
                  </button>
                </div>
              )}
              <input ref={faviconInputRef} type="file" accept="image/*,.ico" onChange={handleFaviconPick} className="hidden" />
              <button onClick={() => faviconInputRef.current?.click()}
                className="flex items-center gap-2 px-3 py-2 rounded-xl border border-border bg-secondary text-xs text-muted-foreground hover:text-foreground hover:border-primary/50 transition-colors">
                <Upload className="w-3.5 h-3.5" />
                {faviconPreview ? "تغییر favicon" : "آپلود favicon"}
              </button>
            </div>
          </div>
        </div>
        {brandError && (
          <div className="flex items-center gap-2 text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
            <AlertCircle className="w-3.5 h-3.5 shrink-0" />{brandError}
          </div>
        )}
        {resizing && (
          <p className="text-xs text-primary/70 animate-pulse">⏳ در حال resize کردن تصویر...</p>
        )}
        <button onClick={handleBrandSave} disabled={brandSaving || resizing}
          className={`flex items-center gap-2 px-5 py-2 rounded-xl text-sm font-semibold transition-all ${
            brandSaved
              ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
              : brandSaving || resizing
                ? "bg-secondary text-muted-foreground cursor-not-allowed"
                : "bg-primary text-primary-foreground hover:bg-primary/90"
          }`}>
          {brandSaved   ? <><CheckCircle2 className="w-4 h-4" />ذخیره شد ✓</>
            : brandSaving ? <><Save className="w-4 h-4 animate-pulse" />در حال ذخیره...</>
            : resizing    ? <>⏳ آماده‌سازی تصویر...</>
            : <><Save className="w-4 h-4" />ذخیره برند</>}
        </button>
      </div>

      {/* Save */}
      <div className="animate-in-up pb-4" style={{ animationDelay: "460ms" }}>
        <button onClick={handleSave} disabled={saving || unavailable}
          className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold transition-all ${
            saved ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
              : unavailable ? "bg-secondary text-muted-foreground cursor-not-allowed"
              : "bg-primary text-primary-foreground hover:bg-primary/90"
          }`}>
          {saved ? <><CheckCircle2 className="w-4 h-4" />ذخیره شد ✓</>
            : saving ? <><Save className="w-4 h-4 animate-pulse" />در حال ذخیره...</>
            : <><Save className="w-4 h-4" />ذخیره همه تنظیمات</>}
        </button>
      </div>
    </div>
  );
}

// ── Helper components ───────────────────────────────────────
function Section({ icon: Icon, title, delay, children, toggle }: {
  icon: React.ElementType; title: string; delay: number;
  children: React.ReactNode;
  toggle?: { on: boolean; onToggle: () => void };
}) {
  return (
    <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4"
      style={{ animationDelay: `${delay}ms` }}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4 text-primary" />
          <h2 className="text-sm font-semibold text-foreground">{title}</h2>
        </div>
        {toggle && (
          <button onClick={toggle.onToggle}>
            {toggle.on ? <ToggleRight className="w-8 h-8 text-primary" /> : <ToggleLeft className="w-8 h-8 text-muted-foreground" />}
          </button>
        )}
      </div>
      {children}
    </div>
  );
}

function ToggleRow({ label, sub, on, onToggle }: { label: string; sub: string; on: boolean; onToggle: () => void }) {
  return (
    <div className="flex items-center justify-between py-1">
      <div>
        <p className="text-sm font-medium text-foreground">{label}</p>
        <p className="text-xs text-muted-foreground mt-0.5">{sub}</p>
      </div>
      <button onClick={onToggle}>
        {on ? <ToggleRight className="w-8 h-8 text-primary" /> : <ToggleLeft className="w-8 h-8 text-muted-foreground" />}
      </button>
    </div>
  );
}

function Field({ label, value, onChange, placeholder, dir, mono }: {
  label: string; value: string; onChange: (v: string) => void;
  placeholder?: string; dir?: string; mono?: boolean;
}) {
  return (
    <div>
      <label className="text-xs text-muted-foreground mb-1.5 block">{label}</label>
      <input value={value} onChange={e => onChange(e.target.value)}
        placeholder={placeholder} dir={dir as "ltr" | "rtl" | undefined}
        className={`w-full px-3 py-2.5 rounded-xl bg-input border border-border text-sm text-foreground focus:outline-none focus:border-primary/50 transition-colors ${mono ? "font-mono" : ""}`} />
    </div>
  );
}
