"use client";
import { useState, useEffect, useRef } from "react";
import { apiFetch } from "@/lib/api";
import { BookOpen, Save, RotateCcw, Eye, EyeOff } from "lucide-react";

export default function GuidePage() {
  const [text, setText]           = useState("");
  const [saved, setSaved]         = useState("");
  const [loading, setLoading]     = useState(true);
  const [saving, setSaving]       = useState(false);
  const [result, setResult]       = useState<{ ok: boolean; msg: string } | null>(null);
  const [preview, setPreview]     = useState(false);
  const textareaRef               = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    apiFetch("/api/guide")
      .then(r => r.json())
      .then(d => { setText(d.text ?? ""); setSaved(d.text ?? ""); })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const handleSave = async () => {
    setSaving(true); setResult(null);
    try {
      const res = await apiFetch("/api/guide", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
      });
      const d = await res.json();
      if (d.ok) { setSaved(text); setResult({ ok: true, msg: "✅ متن با موفقیت ذخیره شد." }); }
      else setResult({ ok: false, msg: d.error ?? "خطا در ذخیره" });
    } catch { setResult({ ok: false, msg: "خطا در اتصال" }); }
    finally { setSaving(false); }
  };

  const isDirty = text !== saved;

  return (
    <div className="space-y-6">
      <div className="animate-in-up" style={{ animationDelay: "0ms" }}>
        <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-primary" /> ویرایش راهنما
        </h1>
        <p className="text-sm text-muted-foreground mt-0.5">
          متنی که اینجا ذخیره کنید، وقتی کاربر دکمه «آموزش و نکات» را بزند برایش ارسال می‌شود.
          از فرمت Markdown پشتیبانی می‌شود.
        </p>
      </div>

      {/* editor card */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4" style={{ animationDelay: "60ms" }}>

        {/* toolbar */}
        <div className="flex items-center justify-between flex-wrap gap-2">
          <span className="text-xs text-muted-foreground">
            پشتیبانی از *bold*, _italic_, `code`, لینک، ایموجی و سایر Markdown تلگرام
          </span>
          <button
            onClick={() => setPreview(v => !v)}
            className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-border/60 bg-secondary hover:border-primary/40 transition-colors text-muted-foreground"
          >
            {preview ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            {preview ? "ویرایش" : "پیش‌نمایش"}
          </button>
        </div>

        {/* textarea یا preview */}
        {preview ? (
          <div className="min-h-[260px] rounded-xl border border-border/40 bg-secondary/40 p-4 text-sm text-foreground/90 whitespace-pre-wrap font-mono leading-relaxed">
            {text || <span className="text-muted-foreground italic">متنی وارد نشده...</span>}
          </div>
        ) : (
          <textarea
            ref={textareaRef}
            value={text}
            onChange={e => setText(e.target.value)}
            placeholder={"🎓 راهنمای استفاده از VPN\n\n*نصب برنامه:*\n1. برنامه Hiddify یا V2rayNG را دانلود کنید.\n2. روی لینک خود کلیک کنید تا اشتراک اضافه شود.\n\n*نکات مهم:*\n- سرعت بستگی به اینترنت شما دارد.\n- در صورت مشکل با پشتیبانی تماس بگیرید."}
            disabled={loading}
            className="w-full min-h-[260px] rounded-xl border border-border/60 bg-secondary/40 p-4 text-sm text-foreground placeholder:text-muted-foreground/50 font-mono leading-relaxed resize-y focus:outline-none focus:border-primary/50 transition-colors disabled:opacity-50"
          />
        )}

        {/* result message */}
        {result && (
          <div className={`rounded-xl px-4 py-3 text-xs border ${
            result.ok ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-300"
                      : "bg-red-500/10 border-red-500/20 text-red-300"
          }`}>
            {result.msg}
          </div>
        )}

        {/* action buttons */}
        <div className="flex items-center gap-3 flex-wrap">
          <button
            onClick={handleSave}
            disabled={saving || loading || !isDirty}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-medium border transition-all ${
              isDirty && !saving
                ? "bg-primary/15 border-primary/40 text-primary hover:bg-primary/25"
                : "bg-secondary border-border text-muted-foreground cursor-not-allowed opacity-50"
            }`}
          >
            <Save className="w-4 h-4" />
            {saving ? "در حال ذخیره..." : "ذخیره"}
          </button>
          <button
            onClick={() => { setText(saved); setResult(null); }}
            disabled={!isDirty || saving}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-medium border border-border/60 bg-secondary text-muted-foreground hover:border-border transition-all disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <RotateCcw className="w-3.5 h-3.5" /> لغو تغییرات
          </button>
          {isDirty && (
            <span className="text-xs text-yellow-400/80">● تغییرات ذخیره نشده</span>
          )}
        </div>
      </div>

      {/* hint card */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5" style={{ animationDelay: "120ms" }}>
        <h3 className="text-sm font-semibold text-foreground mb-3">راهنمای Markdown تلگرام</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs text-muted-foreground font-mono">
          {[
            ["*متن*", "Bold"],
            ["_متن_", "Italic"],
            ["`کد`", "Inline code"],
            ["```\nکد\n```", "Code block"],
            ["[متن](url)", "لینک"],
            ["||متن||", "Spoiler"],
          ].map(([code, desc]) => (
            <div key={code} className="rounded-lg bg-secondary/50 px-3 py-2 flex flex-col gap-1">
              <code className="text-primary/80">{code}</code>
              <span className="text-[10px] text-muted-foreground/60">{desc}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
