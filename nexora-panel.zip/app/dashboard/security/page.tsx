"use client";
import { apiFetch } from "@/lib/api";
import { useState, useEffect } from "react";
import {
  Lock, KeyRound, Eye, EyeOff, Save, Shield, AlertTriangle,
  RefreshCw, CheckCircle2, XCircle, ArrowRightLeft,
} from "lucide-react";

type SyncStatus = {
  panelEnvExists: boolean; botEnvPath: string | null; botEnvReadable: boolean;
  outOfSync: string[]; inSync: boolean; panelEnv: Record<string, string>; botEnv: Record<string, string>;
} | null;

export default function SecurityPage() {
  const [currentCmd, setCurrentCmd]   = useState("admin_secret");
  const [newCmd, setNewCmd]           = useState("");
  const [cmdSaving, setCmdSaving]     = useState(false);
  const [cmdSaved, setCmdSaved]       = useState(false);
  const [cmdError, setCmdError]       = useState("");
  const [cmdLoading, setCmdLoading]   = useState(true);

  const [newPass, setNewPass]         = useState("");
  const [confirmPass, setConfirmPass] = useState("");
  const [showNew, setShowNew]         = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [passSaved, setPassSaved]     = useState(false);
  const [passError, setPassError]     = useState("");

  // Sync state
  const [syncStatus, setSyncStatus]   = useState<SyncStatus>(null);
  const [syncLoading, setSyncLoading] = useState(false);
  const [syncResult, setSyncResult]   = useState<{ ok: boolean; message?: string; error?: string; synced?: string[]; note?: string } | null>(null);

  // بارگذاری دستور فعلی از DB ربات
  const loadCurrentCmd = async () => {
    setCmdLoading(true);
    try {
      const r = await apiFetch("/api/security");
      if (r.ok) {
        const d = await r.json();
        setCurrentCmd(d.admin_command ?? "admin_secret");
      }
    } finally { setCmdLoading(false); }
  };

  const loadSyncStatus = async () => {
    setSyncLoading(true);
    try {
      const r = await apiFetch("/api/sync-env");
      if (r.ok) setSyncStatus(await r.json());
    } finally { setSyncLoading(false); }
  };

  useEffect(() => {
    loadCurrentCmd();
    loadSyncStatus();
  }, []);

  const doSync = async () => {
    setSyncLoading(true); setSyncResult(null);
    try {
      const r = await apiFetch("/api/sync-env", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ force: false }),
      });
      const d = await r.json();
      setSyncResult(d);
      if (d.ok) await loadSyncStatus();
    } catch { setSyncResult({ ok: false, error: "خطا در اتصال" }); }
    finally { setSyncLoading(false); }
  };

  // ذخیره دستور جدید در DB ربات از طریق API
  const handleSaveCmd = async () => {
    if (!newCmd.trim()) return;
    setCmdError("");
    setCmdSaving(true);
    try {
      const r = await apiFetch("/api/security", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ admin_command: newCmd.trim() }),
      });
      const d = await r.json();
      if (r.ok && d.ok) {
        setCurrentCmd(d.admin_command);
        setNewCmd("");
        setCmdSaved(true);
        setTimeout(() => setCmdSaved(false), 3000);
      } else {
        setCmdError(d.error ?? "خطا در ذخیره");
      }
    } catch {
      setCmdError("خطا در اتصال به سرور");
    } finally {
      setCmdSaving(false);
    }
  };

  const [passSaving, setPassSaving] = useState(false);

  const handleSavePass = async () => {
    setPassError("");
    if (newPass.length < 8) { setPassError("رمز عبور باید حداقل ۸ کاراکتر باشد"); return; }
    if (newPass !== confirmPass) { setPassError("رمزهای عبور مطابقت ندارند"); return; }
    setPassSaving(true);
    try {
      const r = await apiFetch("/api/auth/change-password", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ newPassword: newPass }),
      });
      const d = await r.json();
      if (r.ok && d.ok) {
        setNewPass(""); setConfirmPass("");
        setPassSaved(true); setTimeout(() => setPassSaved(false), 4000);
      } else { setPassError(d.error ?? "خطا در تغییر رمز"); }
    } catch { setPassError("خطا در اتصال به سرور"); }
    finally { setPassSaving(false); }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="animate-in-up" style={{ animationDelay: "0ms" }}>
        <h1 className="text-xl font-bold text-foreground">تنظیمات امنیتی</h1>
        <p className="text-sm text-muted-foreground mt-0.5">مدیریت دسترسی و رمزهای عبور پنل</p>
      </div>

      {/* ── Sync .env ── */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4" style={{ animationDelay: "50ms" }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ArrowRightLeft className="w-4 h-4 text-primary" />
            <h2 className="text-sm font-semibold text-foreground">همگام‌سازی .env پنل با ربات</h2>
          </div>
          <button onClick={loadSyncStatus} disabled={syncLoading}
            className="w-7 h-7 rounded-lg border border-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors disabled:opacity-40">
            <RefreshCw className={`w-3.5 h-3.5 ${syncLoading ? "animate-spin" : ""}`} />
          </button>
        </div>

        <p className="text-xs text-muted-foreground">
          اگه نصب اولیه .env.local پنل را به درستی پر نکرده، با این دکمه مقادیر
          <code className="mx-1 px-1 py-0.5 rounded bg-secondary text-primary text-[10px] font-mono">bot/.env</code>
          را به .env.local پنل sync کن. بعد از sync، پنل را ری‌استارت کن.
        </p>

        {syncStatus && (
          <div className="space-y-2">
            <div className={`flex items-center gap-2 px-3 py-2 rounded-xl border text-xs ${
              !syncStatus.botEnvReadable
                ? "bg-yellow-500/10 border-yellow-500/25 text-yellow-400"
                : syncStatus.inSync
                  ? "bg-emerald-500/10 border-emerald-500/25 text-emerald-400"
                  : "bg-orange-500/10 border-orange-500/25 text-orange-400"
            }`}>
              {!syncStatus.botEnvReadable
                ? <><XCircle className="w-3.5 h-3.5" /> فایل bot/.env پیدا نشد</>
                : syncStatus.inSync
                  ? <><CheckCircle2 className="w-3.5 h-3.5" /> .env.local به‌روز است</>
                  : <><AlertTriangle className="w-3.5 h-3.5" /> {syncStatus.outOfSync.length} متغیر out-of-sync: {syncStatus.outOfSync.join(", ")}</>
              }
            </div>

            <div className="grid grid-cols-1 gap-1.5 text-[10px] font-mono text-muted-foreground">
              <div className="flex gap-1">
                <span className="text-muted-foreground/50 shrink-0">bot env:</span>
                <span className={syncStatus.botEnvPath ? "text-foreground" : "text-red-400"}>
                  {syncStatus.botEnvPath ?? "❌ پیدا نشد"}
                </span>
              </div>
            </div>

            {syncStatus.botEnvReadable && syncStatus.outOfSync.length > 0 && (
              <div className="rounded-xl border border-border/40 overflow-hidden text-[10px]">
                <div className="grid grid-cols-3 bg-secondary/40 px-3 py-1.5 text-muted-foreground font-medium">
                  <span>کلید</span><span>ربات</span><span>پنل</span>
                </div>
                {syncStatus.outOfSync.map(k => (
                  <div key={k} className="grid grid-cols-3 px-3 py-1.5 border-t border-border/30 font-mono">
                    <span className="text-orange-400">{k}</span>
                    <span className="text-emerald-400 truncate">{syncStatus.botEnv[k] || "—"}</span>
                    <span className="text-red-400 truncate">{syncStatus.panelEnv[k] || "❌ خالی"}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {syncResult && (
          <div className={`rounded-xl px-4 py-3 text-xs border space-y-1 ${
            syncResult.ok ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-300"
                          : "bg-red-500/10 border-red-500/20 text-red-300"
          }`}>
            <p className="font-medium">{syncResult.message ?? syncResult.error}</p>
            {syncResult.synced && <p className="opacity-70">sync شد: {syncResult.synced.join(", ")}</p>}
            {syncResult.note && <p className="text-yellow-400/80">⚠ {syncResult.note}</p>}
          </div>
        )}

        <button onClick={doSync} disabled={syncLoading || !syncStatus?.botEnvReadable}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
            syncLoading || !syncStatus?.botEnvReadable
              ? "bg-secondary text-muted-foreground cursor-not-allowed opacity-50"
              : "bg-primary text-primary-foreground hover:bg-primary/90"
          }`}>
          {syncLoading
            ? <><RefreshCw className="w-4 h-4 animate-spin" />در حال sync...</>
            : <><ArrowRightLeft className="w-4 h-4" />sync کردن .env</>}
        </button>
      </div>

      {/* Admin command */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4" style={{ animationDelay: "60ms" }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-primary" />
            <h2 className="text-sm font-semibold text-foreground">دستور ورود ادمین ربات</h2>
          </div>
          <button onClick={loadCurrentCmd} disabled={cmdLoading}
            className="w-7 h-7 rounded-lg border border-border flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors disabled:opacity-40">
            <RefreshCw className={`w-3.5 h-3.5 ${cmdLoading ? "animate-spin" : ""}`} />
          </button>
        </div>

        <div className="bg-secondary/40 rounded-xl px-4 py-3 border border-border/40">
          <p className="text-xs text-muted-foreground mb-1">دستور فعلی (از DB ربات):</p>
          {cmdLoading ? (
            <div className="h-5 w-32 bg-secondary animate-pulse rounded" />
          ) : (
            <code className="text-sm text-primary font-mono">/{currentCmd} &lt;رمز&gt;</code>
          )}
        </div>

        <div className="space-y-2">
          <label className="text-xs text-muted-foreground block">دستور جدید (بدون /)</label>
          <div className="flex gap-2">
            <input
              value={newCmd}
              onChange={(e) => setNewCmd(e.target.value.replace(/[^a-z0-9_]/g, ""))}
              placeholder="مثال: my_secret_cmd"
              dir="ltr"
              className="flex-1 px-3 py-2.5 rounded-xl bg-input border border-border text-sm text-foreground font-mono focus:outline-none focus:border-primary/50 transition-colors"
            />
            <button
              onClick={handleSaveCmd}
              disabled={!newCmd.trim() || cmdSaving}
              className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                cmdSaved
                  ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                  : newCmd.trim() && !cmdSaving
                    ? "bg-primary text-primary-foreground hover:bg-primary/90"
                    : "bg-secondary text-muted-foreground cursor-not-allowed"
              }`}
            >
              {cmdSaving ? "در حال ذخیره..." : cmdSaved ? "ذخیره شد ✓" : "تغییر دستور"}
            </button>
          </div>
          {cmdError && (
            <p className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
              {cmdError}
            </p>
          )}
        </div>

        <div className="flex items-start gap-2 bg-yellow-500/8 border border-yellow-500/20 rounded-xl px-3 py-2.5">
          <AlertTriangle className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
          <p className="text-xs text-yellow-300/80">
            بعد از تغییر، دستور جدید بلافاصله در ربات اعمال می‌شود. دستور قدیمی کار نخواهد کرد.
          </p>
        </div>
      </div>

      {/* Panel password */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4" style={{ animationDelay: "120ms" }}>
        <div className="flex items-center gap-2">
          <Lock className="w-4 h-4 text-primary" />
          <h2 className="text-sm font-semibold text-foreground">رمز عبور پنل وب</h2>
        </div>

        <div>
          <label className="text-xs text-muted-foreground mb-1.5 block">رمز عبور جدید</label>
          <div className="relative">
            <input
              type={showNew ? "text" : "password"}
              value={newPass}
              onChange={(e) => setNewPass(e.target.value)}
              placeholder="حداقل ۸ کاراکتر"
              dir="ltr"
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-input border border-border text-sm text-foreground focus:outline-none focus:border-primary/50 transition-colors"
            />
            <button type="button" onClick={() => setShowNew(!showNew)}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">
              {showNew ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        <div>
          <label className="text-xs text-muted-foreground mb-1.5 block">تکرار رمز عبور جدید</label>
          <div className="relative">
            <input
              type={showConfirm ? "text" : "password"}
              value={confirmPass}
              onChange={(e) => setConfirmPass(e.target.value)}
              placeholder="تکرار رمز عبور"
              dir="ltr"
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-input border border-border text-sm text-foreground focus:outline-none focus:border-primary/50 transition-colors"
            />
            <button type="button" onClick={() => setShowConfirm(!showConfirm)}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">
              {showConfirm ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {passError && (
          <p className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
            {passError}
          </p>
        )}

        <button
          onClick={handleSavePass}
          disabled={!newPass || !confirmPass || passSaving}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
            passSaved
              ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
              : newPass && confirmPass
                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                : "bg-secondary text-muted-foreground cursor-not-allowed"
          }`}
        >
          <Save className="w-4 h-4" />
          {passSaved ? "رمز تغییر کرد ✓" : passSaving ? "در حال ذخیره..." : "تغییر رمز عبور"}
        </button>
      </div>

      {/* Info */}
      <div className="animate-in-up rounded-2xl border border-border/40 bg-secondary/20 px-4 py-3" style={{ animationDelay: "180ms" }}>
        <div className="flex items-center gap-2 mb-2">
          <Shield className="w-4 h-4 text-primary" />
          <p className="text-xs font-semibold text-foreground">نکات امنیتی</p>
        </div>
        <ul className="text-xs text-muted-foreground space-y-1 list-disc list-inside">
          <li>دستور ورود ادمین را با کسی به اشتراک نگذارید</li>
          <li>از رمز عبور پیچیده و منحصربه‌فرد استفاده کنید</li>
          <li>در صورت شک به نفوذ، فوری دستور و رمز را تغییر دهید</li>
          <li>پنل وب را با مسیر امن (WEB_PANEL_PATH) محافظت کنید</li>
          <li>تغییر دستور ادمین بلافاصله در DB ربات اعمال می‌شود — بدون ری‌استارت</li>
        </ul>
      </div>
    </div>
  );
}
