"use client";
import { apiFetch } from "@/lib/api";
import { useEffect, useState, useCallback } from "react";
import { UserPlus, Search, Package, Infinity, Wifi, CheckCircle2, ChevronDown, ChevronUp } from "lucide-react";

type UserRow = { id: number; telegram_id: number; first_name?: string; username?: string; };
type PlanRow = { id: number; name: string; traffic_gb: number; duration_days: number; price_usdt: number; limit_ip: number; inbound_ids: number[]; is_active?: boolean; };
type InboundRow = { id: number; remark: string; protocol: string; port: number; };

const protoColor: Record<string, string> = {
  vless:  "bg-blue-500/15 border-blue-500/25 text-blue-400",
  vmess:  "bg-violet-500/15 border-violet-500/25 text-violet-400",
  trojan: "bg-orange-500/15 border-orange-500/25 text-orange-400",
};

type Mode = "plan" | "custom";

export default function ManualSubPage() {
  const [userSearch, setUserSearch]     = useState("");
  const [searchResults, setSearchResults] = useState<UserRow[]>([]);
  const [searching, setSearching]       = useState(false);
  const [plans, setPlans]               = useState<PlanRow[]>([]);
  const [inbounds, setInbounds]         = useState<InboundRow[]>([]);
  const [selectedUser, setSelectedUser] = useState<UserRow | null>(null);
  const [mode, setMode]                 = useState<Mode>("plan");
  const [selectedPlan, setSelectedPlan] = useState<number | null>(null);
  const [customTraffic, setCustomTraffic] = useState("10");
  const [customDays, setCustomDays]     = useState("30");
  const [customLimitIp, setCustomLimitIp] = useState("0");
  const [selectedInbounds, setSelectedInbounds] = useState<number[]>([]);
  const [showInbounds, setShowInbounds] = useState(false);
  const [done, setDone]                 = useState(false);
  const [creating, setCreating]         = useState(false);
  const [createError, setCreateError]   = useState<string | null>(null);
  const [subLink, setSubLink]           = useState<string | null>(null);

  // Fetch plans and inbounds on mount
  useEffect(() => {
    Promise.all([apiFetch("/api/plans"), apiFetch("/api/inbounds")]).then(async ([pr, ir]) => {
      if (pr.ok) { const d = await pr.json(); setPlans((d.plans ?? []).filter((p: PlanRow) => p.is_active !== false)); }
      if (ir.ok) { const d = await ir.json(); setInbounds(d.inbounds ?? []); }
    }).catch(() => {});
  }, []);

  // Search users with debounce
  useEffect(() => {
    if (!userSearch.trim()) { setSearchResults([]); return; }
    const t = setTimeout(async () => {
      setSearching(true);
      try {
        const r = await apiFetch(`/api/users?search=${encodeURIComponent(userSearch)}&limit=6`);
        if (r.ok) { const d = await r.json(); setSearchResults(d.users ?? []); }
      } finally { setSearching(false); }
    }, 400);
    return () => clearTimeout(t);
  }, [userSearch]);

  const toggleInbound = (id: number) =>
    setSelectedInbounds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );

  const canCreate = selectedUser && (
    mode === "plan" ? selectedPlan !== null
      : customTraffic && customDays && selectedInbounds.length > 0
  );

  const handleCreate = async () => {
    if (!canCreate || creating) return;
    setCreating(true); setCreateError(null); setSubLink(null);
    try {
      const body: Record<string, unknown> = {
        user_id:     selectedUser!.id,
        telegram_id: selectedUser!.telegram_id,
        mode,
      };
      if (mode === "plan") {
        body.plan_id = selectedPlan;
      } else {
        body.traffic_gb = Number(customTraffic);
        body.days       = Number(customDays);
        body.limit_ip   = Number(customLimitIp);
        body.inbound_id = selectedInbounds[0] ?? 0;
      }
      const res = await apiFetch("/api/manual-sub", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body:    JSON.stringify(body),
      });
      const data = await res.json() as { ok?: boolean; error?: string; message?: string };
      if (!res.ok || !data.ok) {
        setCreateError(data.error ?? "خطا در ساخت اشتراک");
        return;
      }
      setSubLink(data.message ?? "دستور ارسال شد — ربات ظرف ۱۵ ثانیه اشتراک را می‌سازد و برای کاربر می‌فرستد.");
      setDone(true);
    } catch (e) {
      setCreateError(e instanceof Error ? e.message : "خطای ناشناخته");
    } finally {
      setCreating(false);
    }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="animate-in-up" style={{ animationDelay: "0ms" }}>
        <h1 className="text-xl font-bold text-foreground">اشتراک دستی</h1>
        <p className="text-sm text-muted-foreground mt-0.5">ایجاد اشتراک برای کاربر بدون پرداخت</p>
      </div>

      {/* Step 1: User */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4" style={{ animationDelay: "50ms" }}>
        <div className="flex items-center gap-2">
          <span className="w-6 h-6 rounded-full bg-primary/20 border border-primary/40 text-xs font-bold text-primary flex items-center justify-center">1</span>
          <h2 className="text-sm font-semibold text-foreground">انتخاب کاربر</h2>
        </div>

        {selectedUser ? (
          <div className="flex items-center gap-3 p-3 rounded-xl bg-primary/8 border border-primary/30">
            <div className="w-9 h-9 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center shrink-0">
              <span className="text-xs font-bold text-primary">{(selectedUser.first_name ?? selectedUser.username ?? "?").charAt(0)}</span>
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-foreground">{selectedUser.first_name ?? selectedUser.username ?? `#${selectedUser.telegram_id}`}</p>
              <p className="text-xs text-muted-foreground">{selectedUser.username ? `@${selectedUser.username}` : ""} · {selectedUser.telegram_id}</p>
            </div>
            <button onClick={() => setSelectedUser(null)} className="text-xs text-muted-foreground hover:text-foreground transition-colors">
              تغییر
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            <div className="relative">
              <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                placeholder="جستجو نام، یوزرنیم یا آیدی عددی..."
                className="w-full pr-10 pl-4 py-2.5 rounded-xl bg-input border border-border text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/50 transition-colors"
              />
            </div>
            {searching && <p className="text-xs text-muted-foreground text-center py-2 animate-pulse">در حال جستجو...</p>}
            {!searching && searchResults.length > 0 && (
              <div className="rounded-xl border border-border/60 overflow-hidden">
                {searchResults.map((u) => {
                  const name = u.first_name ?? u.username ?? `#${u.telegram_id}`;
                  return (
                    <button key={u.id} onClick={() => { setSelectedUser(u); setUserSearch(""); setSearchResults([]); }}
                      className="w-full flex items-center gap-3 px-4 py-3 hover:bg-secondary/40 transition-colors border-b border-border/30 last:border-b-0 text-right">
                      <div className="w-7 h-7 rounded-full bg-primary/20 border border-primary/30 flex items-center justify-center shrink-0">
                        <span className="text-xs font-bold text-primary">{name.charAt(0)}</span>
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-foreground">{name}</p>
                        {u.username && <p className="text-xs text-muted-foreground">@{u.username}</p>}
                      </div>
                      <span className="text-xs font-mono text-muted-foreground/60">{u.telegram_id}</span>
                    </button>
                  );
                })}
              </div>
            )}
            {!searching && userSearch && searchResults.length === 0 && (
              <p className="text-xs text-muted-foreground text-center py-2">کاربری یافت نشد</p>
            )}
          </div>
        )}
      </div>

      {/* Step 2: Plan or Custom */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4" style={{ animationDelay: "100ms" }}>
        <div className="flex items-center gap-2">
          <span className="w-6 h-6 rounded-full bg-primary/20 border border-primary/40 text-xs font-bold text-primary flex items-center justify-center">2</span>
          <h2 className="text-sm font-semibold text-foreground">نوع اشتراک</h2>
        </div>

        <div className="flex gap-2">
          {(["plan", "custom"] as Mode[]).map((m) => (
            <button key={m} onClick={() => setMode(m)}
              className={`flex-1 py-2 rounded-xl text-xs font-semibold border transition-colors ${
                mode === m
                  ? "bg-primary/15 border-primary/50 text-primary"
                  : "bg-secondary border-border text-muted-foreground hover:text-foreground"
              }`}>
              {m === "plan" ? "بر اساس پلن موجود" : "پلن دلخواه"}
            </button>
          ))}
        </div>

        {mode === "plan" ? (
          <div className="grid gap-2">
            {plans.length === 0 && <p className="text-xs text-muted-foreground text-center py-2">هیچ پلنی یافت نشد</p>}
            {plans.map((p) => (
              <button key={p.id} onClick={() => setSelectedPlan(p.id)}
                className={`flex items-center gap-3 p-3 rounded-xl border text-right transition-all ${
                  selectedPlan === p.id
                    ? "border-primary/50 bg-primary/8"
                    : "border-border/50 bg-background/40 hover:border-border"
                }`}>
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                  p.traffic_gb === 0 ? "bg-violet-500/15 border border-violet-500/25" : "bg-blue-500/15 border border-blue-500/25"
                }`}>
                  {p.traffic_gb === 0 ? <Infinity className="w-4 h-4 text-violet-400" /> : <Package className="w-4 h-4 text-blue-400" />}
                </div>
                <div className="flex-1">
                  <p className={`text-sm font-medium ${selectedPlan === p.id ? "text-primary" : "text-foreground"}`}>{p.name}</p>
                  <p className="text-xs text-muted-foreground">{p.duration_days} روز · ${p.price_usdt} USDT</p>
                </div>
              </button>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">حجم (GB)</label>
                <input value={customTraffic} onChange={(e) => setCustomTraffic(e.target.value)}
                  type="number" min="0" placeholder="0=unlimited" dir="ltr"
                  className="w-full px-3 py-2 rounded-xl bg-input border border-border text-sm font-mono text-foreground focus:outline-none focus:border-primary/50 transition-colors" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">مدت (روز)</label>
                <input value={customDays} onChange={(e) => setCustomDays(e.target.value)}
                  type="number" min="1" dir="ltr"
                  className="w-full px-3 py-2 rounded-xl bg-input border border-border text-sm font-mono text-foreground focus:outline-none focus:border-primary/50 transition-colors" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground mb-1 block">حداکثر دستگاه</label>
                <input value={customLimitIp} onChange={(e) => setCustomLimitIp(e.target.value)}
                  type="number" min="0" placeholder="0=unlimited" dir="ltr"
                  className="w-full px-3 py-2 rounded-xl bg-input border border-border text-sm font-mono text-foreground focus:outline-none focus:border-primary/50 transition-colors" />
              </div>
            </div>

            {/* Inbound selector */}
            <div>
              <button onClick={() => setShowInbounds(!showInbounds)}
                className="w-full flex items-center justify-between px-4 py-2.5 rounded-xl bg-secondary border border-border text-sm text-muted-foreground hover:text-foreground transition-colors">
                <div className="flex items-center gap-2">
                  <Wifi className="w-4 h-4" />
                  <span>اینباندها ({selectedInbounds.length} انتخاب‌شده)</span>
                </div>
                {showInbounds ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              {showInbounds && (
                <div className="mt-2 rounded-xl border border-border/60 overflow-hidden">
                  {inbounds.map((inb) => {
                    const sel = selectedInbounds.includes(inb.id);
                    return (
                      <button key={inb.id} onClick={() => toggleInbound(inb.id)}
                        className={`w-full flex items-center gap-3 px-4 py-2.5 border-b border-border/30 last:border-b-0 text-right transition-colors ${sel ? "bg-primary/8" : "hover:bg-secondary/30"}`}>
                        <div className={`w-4 h-4 rounded border-2 flex items-center justify-center shrink-0 ${sel ? "border-primary bg-primary" : "border-border"}`}>
                          {sel && <CheckCircle2 className="w-3 h-3 text-primary-foreground" />}
                        </div>
                        <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded border shrink-0 ${protoColor[inb.protocol] ?? "bg-secondary border-border text-muted-foreground"}`}>
                          {inb.protocol.toUpperCase()}
                        </span>
                        <span className={`text-sm ${sel ? "text-primary font-medium" : "text-foreground"}`}>{inb.remark}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Error */}
      {createError && (
        <div className="animate-in-up rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-400 flex items-start gap-2">
          <span className="shrink-0 mt-0.5">⚠️</span>
          <span>{createError}</span>
        </div>
      )}

      {/* Success — show sub link */}
      {done && subLink && (
        <div className="animate-in-up rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-4 space-y-2">
          <p className="text-sm font-semibold text-emerald-400 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" /> دستور ساخت اشتراک به ربات ارسال شد!
          </p>
          <p className="text-xs text-emerald-300/80">{subLink}</p>
        </div>
      )}

      {/* Create button */}
      <div className="animate-in-up" style={{ animationDelay: "150ms" }}>
        <button
          onClick={handleCreate}
          disabled={!canCreate || creating}
          className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold transition-all ${
            done
              ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
              : canCreate && !creating
                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                : "bg-secondary text-muted-foreground cursor-not-allowed"
          }`}
        >
          {creating ? <><span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin inline-block" />در حال ساخت...</>
            : done ? <><CheckCircle2 className="w-4 h-4" />اشتراک ایجاد شد!</>
            : <><UserPlus className="w-4 h-4" />ایجاد اشتراک</>}
        </button>
      </div>
    </div>
  );
}
