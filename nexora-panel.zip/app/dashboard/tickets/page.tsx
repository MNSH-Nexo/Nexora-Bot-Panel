"use client";
import { apiFetch, getWebPrefix } from "@/lib/api";
import { useEffect, useState, useCallback, useRef } from "react";
import {
  MessageSquare, ChevronDown, Send, RefreshCw,
  CheckCircle2, AlertCircle, X, LockOpen, User, Hash, Radio,
} from "lucide-react";

interface TicketMsg {
  id: number; body: string; is_admin_reply: number; created_at: string;
  telegram_id?: number; username?: string; first_name?: string;
}
interface Ticket {
  id: number; subject: string; status: string; created_at: string; updated_at: string;
  telegram_id?: number; username?: string; first_name?: string; msg_count?: number;
}

const statusCfg: Record<string, { label: string; cls: string }> = {
  open:        { label: "باز",       cls: "bg-blue-500/15 text-blue-400 border-blue-500/25" },
  in_progress: { label: "در بررسی", cls: "bg-yellow-500/15 text-yellow-400 border-yellow-500/25" },
  closed:      { label: "بسته",     cls: "bg-secondary text-muted-foreground border-border" },
};

function toJalali(iso: string) {
  try {
    return new Date(iso).toLocaleString("fa-IR", {
      year: "numeric", month: "short", day: "numeric",
      hour: "2-digit", minute: "2-digit",
    });
  } catch { return iso; }
}

type FilterStatus = "all" | "open" | "in_progress" | "closed";

// ── SSE hook با webpath درست ──────────────────────────────────
function useSSE(
  path: string | null,
  handlers: Record<string, (data: unknown) => void>,
  onConnect?: () => void,
  onDisconnect?: () => void,
) {
  const esRef    = useRef<EventSource | null>(null);
  const retryRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const countRef = useRef(0);

  useEffect(() => {
    if (!path) {
      esRef.current?.close();
      esRef.current = null;
      return;
    }

    const connect = () => {
      esRef.current?.close();
      const prefix = getWebPrefix();
      const es = new EventSource(prefix + path);
      esRef.current = es;

      es.onopen = () => { countRef.current = 0; onConnect?.(); };

      // پیام default (بدون event name)
      es.onmessage = (e) => {
        try { handlers["message"]?.(JSON.parse(e.data)); } catch { /* */ }
      };

      // eventهای named
      Object.keys(handlers).forEach(evt => {
        if (evt === "message") return;
        es.addEventListener(evt, (e: MessageEvent) => {
          try { handlers[evt]?.(JSON.parse(e.data)); } catch { /* */ }
        });
      });

      es.onerror = () => {
        onDisconnect?.();
        es.close();
        esRef.current = null;
        const delay = Math.min(2000 * Math.pow(1.5, countRef.current), 30000);
        countRef.current++;
        retryRef.current = setTimeout(connect, delay);
      };

      es.addEventListener("reconnect", () => {
        es.close();
        esRef.current = null;
        retryRef.current = setTimeout(connect, 500);
      });
    };

    connect();

    return () => {
      if (retryRef.current) clearTimeout(retryRef.current);
      esRef.current?.close();
      esRef.current = null;
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [path]);
}

export default function TicketsPage() {
  const [tickets, setTickets]           = useState<Ticket[]>([]);
  const [loading, setLoading]           = useState(true);
  const [source, setSource]             = useState<string>("loading");
  const [expandedId, setExpandedId]     = useState<number | null>(null);
  const [messages, setMessages]         = useState<TicketMsg[]>([]);
  const [loadingMsgs, setLoadingMsgs]   = useState(false);
  const [reply, setReply]               = useState("");
  const [sending, setSending]           = useState(false);
  const [error, setError]               = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<FilterStatus>("all");
  const [listLive, setListLive]         = useState(false);
  const [msgLive, setMsgLive]           = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // ── بارگذاری اولیه لیست ───────────────────────────────────
  const fetchTickets = useCallback(async () => {
    setLoading(true);
    try {
      const params = filterStatus !== "all" ? "?status=" + filterStatus : "";
      const res = await apiFetch("/api/tickets" + params);
      if (res.ok) {
        const d = await res.json();
        setTickets(d.tickets ?? []);
        setSource(d.source ?? "unknown");
      }
    } finally { setLoading(false); }
  }, [filterStatus]);

  useEffect(() => { fetchTickets(); }, [fetchTickets]);

  // scroll به آخرین پیام
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // ── SSE لیست تیکت‌ها (همیشه فعال) ───────────────────────
  useSSE(
    "/api/tickets/stream",
    {
      tickets_list: (data) => {
        const list = data as Ticket[];
        if (filterStatus !== "all") return;
        setTickets(list);
        setSource("live");
        setListLive(true);
      },
      ping: () => { setListLive(true); },
    },
    () => setListLive(true),
    () => setListLive(false),
  );

  // ── SSE پیام‌های تیکت باز ────────────────────────────────
  useSSE(
    expandedId !== null ? "/api/tickets/stream?ticket_id=" + expandedId : null,
    {
      messages: (data) => {
        setMessages(data as TicketMsg[]);
      },
      ticket_status: (data) => {
        const d = data as { status?: string };
        if (d?.status) {
          setTickets(prev => prev.map(t =>
            t.id === expandedId ? { ...t, status: d.status! } : t
          ));
        }
      },
      ping: () => { setMsgLive(true); },
    },
    () => setMsgLive(true),
    () => setMsgLive(false),
  );

  // reset msgLive وقتی تیکت بسته میشه
  useEffect(() => {
    if (expandedId === null) setMsgLive(false);
  }, [expandedId]);

  // ── باز/بستن تیکت ─────────────────────────────────────────
  const openTicket = async (id: number) => {
    if (expandedId === id) { setExpandedId(null); setMessages([]); return; }
    setExpandedId(id);
    setMessages([]);
    setMsgLive(false);
    setLoadingMsgs(true);
    try {
      const res = await apiFetch("/api/tickets?id=" + id);
      if (res.ok) {
        const d = await res.json();
        setMessages(d.messages ?? []);
      }
    } finally { setLoadingMsgs(false); }
  };

  // ── ارسال پاسخ ────────────────────────────────────────────
  const sendReply = async (ticketId: number) => {
    if (!reply.trim() || sending) return;
    setSending(true); setError(null);
    try {
      const res = await apiFetch("/api/tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "reply", ticket_id: ticketId, message: reply.trim() }),
      });
      if (res.ok) {
        setReply("");
        // SSE پیام جدید را push میکنه — ولی اگه تاخیر داشت دستی هم بخوان
        setTimeout(async () => {
          const r2 = await apiFetch("/api/tickets?id=" + ticketId);
          if (r2.ok) { const d = await r2.json(); setMessages(d.messages ?? []); }
        }, 300);
        setTickets(prev => prev.map(t =>
          t.id === ticketId ? { ...t, msg_count: (t.msg_count ?? 0) + 1, status: "in_progress" } : t
        ));
      } else {
        const d = await res.json();
        setError(d.error ?? "خطا در ارسال");
      }
    } finally { setSending(false); }
  };

  const closeTicket = async (ticketId: number) => {
    if (!confirm("آیا مطمئن هستید که می‌خواهید این تیکت را ببندید؟")) return;
    await apiFetch("/api/tickets", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "close", ticket_id: ticketId }),
    });
    setExpandedId(null); setMessages([]);
    await fetchTickets();
  };

  const reopenTicket = async (ticketId: number) => {
    await apiFetch("/api/tickets", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "reopen", ticket_id: ticketId }),
    });
    setMessages([]); setLoadingMsgs(true);
    setExpandedId(ticketId);
    const res = await apiFetch("/api/tickets?id=" + ticketId);
    if (res.ok) { const d = await res.json(); setMessages(d.messages ?? []); }
    setLoadingMsgs(false);
    setTickets(prev => prev.map(t => t.id === ticketId ? { ...t, status: "open" } : t));
  };

  const openCount = tickets.filter(t => t.status !== "closed").length;
  const filters: { key: FilterStatus; label: string }[] = [
    { key: "all",         label: "همه" },
    { key: "open",        label: "باز" },
    { key: "in_progress", label: "در بررسی" },
    { key: "closed",      label: "بسته" },
  ];

  return (
    <div className="space-y-6" dir="rtl">
      {/* Header */}
      <div className="animate-in-up flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-foreground">تیکت‌های پشتیبانی</h1>
          <p className="text-sm text-muted-foreground mt-0.5 flex items-center gap-2 flex-wrap">
            <span>{openCount} تیکت باز از {tickets.length}</span>
            {(listLive || msgLive) ? (
              <span className="flex items-center gap-1 text-green-400 text-xs">
                <Radio className="w-3 h-3 animate-pulse" />زنده
              </span>
            ) : source === "unavailable" ? (
              <span className="text-yellow-400 text-xs">— دیتابیس در دسترس نیست</span>
            ) : (
              <span className="flex items-center gap-1 text-yellow-400/70 text-xs">
                <Radio className="w-3 h-3" />در حال اتصال...
              </span>
            )}
          </p>
        </div>
        <button onClick={fetchTickets} disabled={loading}
          className="p-2 rounded-lg border border-border hover:border-primary/50 text-muted-foreground hover:text-primary transition-colors disabled:opacity-50">
          <RefreshCw className={"w-4 h-4 " + (loading ? "animate-spin" : "")} />
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="rounded-2xl border border-border/60 bg-card p-1 flex gap-1">
        {filters.map(f => (
          <button key={f.key} onClick={() => setFilterStatus(f.key)}
            className={"flex-1 py-1.5 rounded-xl text-xs font-medium transition-colors " + (
              filterStatus === f.key
                ? "bg-primary text-primary-foreground shadow-sm"
                : "text-muted-foreground hover:text-foreground"
            )}>
            {f.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-2">
          {[1,2,3].map(i => <div key={i} className="rounded-2xl border border-border/30 bg-card/40 h-16 animate-pulse" />)}
        </div>
      ) : tickets.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground text-sm">هیچ تیکتی ثبت نشده</div>
      ) : (
        <div className="animate-in-up space-y-2" style={{ animationDelay: "40ms" }}>
          {tickets.map((t, i) => {
            const cfg = statusCfg[t.status] ?? statusCfg.open;
            const isExpanded = expandedId === t.id;
            const displayName = t.first_name ?? t.username ?? ("#" + t.telegram_id);
            const usernameLabel = t.username ? "@" + t.username : null;
            return (
              <div key={t.id}
                className="rounded-2xl border border-border/60 bg-card overflow-hidden transition-all"
                style={{ animationDelay: i * 50 + 80 + "ms" }}>
                <button onClick={() => openTicket(t.id)}
                  className="w-full flex items-center gap-3 px-4 py-3.5 hover:bg-secondary/30 transition-colors text-right">
                  <div className={"w-8 h-8 rounded-xl flex items-center justify-center shrink-0 " + (t.status === "closed" ? "bg-secondary" : "bg-blue-500/15 border border-blue-500/25")}>
                    <MessageSquare className={"w-4 h-4 " + (t.status === "closed" ? "text-muted-foreground" : "text-blue-400")} />
                  </div>
                  <div className="flex-1 min-w-0 text-right">
                    <p className="text-sm font-semibold text-foreground truncate">{t.subject}</p>
                    <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                      <span className="flex items-center gap-1 text-xs text-muted-foreground">
                        <User className="w-3 h-3" />{displayName}
                      </span>
                      {usernameLabel && <span className="text-xs text-primary/70">{usernameLabel}</span>}
                      {t.telegram_id && (
                        <span className="flex items-center gap-0.5 text-[10px] text-muted-foreground/60 font-mono">
                          <Hash className="w-2.5 h-2.5" />{t.telegram_id}
                        </span>
                      )}
                      <span className="text-muted-foreground/40">·</span>
                      <span className="text-xs text-muted-foreground">{toJalali(t.updated_at)}</span>
                      {t.msg_count != null && (
                        <><span className="text-muted-foreground/40">·</span>
                        <span className="text-xs text-muted-foreground">{t.msg_count} پیام</span></>
                      )}
                    </div>
                  </div>
                  {isExpanded && msgLive && (
                    <span className="flex items-center gap-1 text-[10px] text-green-400 shrink-0">
                      <Radio className="w-2.5 h-2.5 animate-pulse" />live
                    </span>
                  )}
                  <span className={"shrink-0 text-[10px] font-medium px-2 py-0.5 rounded-full border " + cfg.cls}>{cfg.label}</span>
                  <ChevronDown className={"w-4 h-4 text-muted-foreground transition-transform shrink-0 " + (isExpanded ? "rotate-180" : "")} />
                </button>

                {isExpanded && (
                  <div className="border-t border-border/60 px-4 py-4 bg-secondary/20 space-y-3">
                    {/* اطلاعات کاربر */}
                    <div className="flex items-center gap-3 text-xs bg-background/40 rounded-xl px-3 py-2 border border-border/30">
                      <User className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-medium text-foreground">{t.first_name || "—"}</span>
                        {t.username && <span className="text-primary/70">@{t.username}</span>}
                        {t.telegram_id && (
                          <span className="font-mono text-muted-foreground/70 bg-muted/30 px-1.5 py-0.5 rounded text-[10px]">
                            ID: {t.telegram_id}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* پیام‌ها */}
                    {loadingMsgs ? (
                      <div className="text-xs text-muted-foreground text-center py-4 animate-pulse">در حال بارگذاری پیام‌ها...</div>
                    ) : (
                      <div className="space-y-2 max-h-72 overflow-y-auto pr-1">
                        {messages.map(m => (
                          <div key={m.id} className={"flex gap-2 " + (m.is_admin_reply ? "flex-row-reverse" : "")}>
                            <div className={"max-w-[80%] rounded-2xl px-3 py-2.5 text-xs leading-relaxed " + (
                              m.is_admin_reply
                                ? "bg-primary/15 border border-primary/25 text-primary-foreground"
                                : "bg-background/80 border border-border/50 text-foreground"
                            )}>
                              <p className={"font-bold text-[10px] mb-1.5 " + (m.is_admin_reply ? "text-primary/80" : "text-muted-foreground")}>
                                {m.is_admin_reply
                                  ? "👨‍💼 ادمین"
                                  : "👤 " + (m.first_name ?? m.username ?? "کاربر") + (m.telegram_id ? " · #" + m.telegram_id : "")
                                }
                              </p>
                              <p className="whitespace-pre-wrap break-words">{m.body}</p>
                              <p className="text-[9px] opacity-50 mt-1.5 text-left">{toJalali(m.created_at)}</p>
                            </div>
                          </div>
                        ))}
                        {messages.length === 0 && (
                          <p className="text-xs text-muted-foreground text-center py-4">هیچ پیامی ثبت نشده است</p>
                        )}
                        <div ref={messagesEndRef} />
                      </div>
                    )}

                    {error && (
                      <div className="flex items-center gap-2 text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
                        <AlertCircle className="w-3.5 h-3.5 shrink-0" />{error}
                        <button onClick={() => setError(null)} className="mr-auto"><X className="w-3 h-3" /></button>
                      </div>
                    )}

                    {t.status !== "closed" && (
                      <>
                        <div className="flex gap-2">
                          <input value={reply} onChange={e => setReply(e.target.value)}
                            onKeyDown={e => e.key === "Enter" && !e.shiftKey && sendReply(t.id)}
                            placeholder="پاسخ ادمین را بنویسید..."
                            className="flex-1 px-3 py-2 rounded-xl bg-background border border-border text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/50 transition-colors" />
                          <button onClick={() => sendReply(t.id)} disabled={!reply.trim() || sending}
                            className={"px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-1.5 transition-colors shrink-0 " + (
                              reply.trim() && !sending
                                ? "bg-primary text-primary-foreground hover:bg-primary/90"
                                : "bg-secondary text-muted-foreground cursor-not-allowed"
                            )}>
                            <Send className="w-3.5 h-3.5" />
                            {sending ? "ارسال..." : "ارسال"}
                          </button>
                        </div>
                        <button onClick={() => closeTicket(t.id)}
                          className="text-xs text-muted-foreground hover:text-red-400 transition-colors flex items-center gap-1 mt-1">
                          <CheckCircle2 className="w-3 h-3" /> بستن تیکت
                        </button>
                      </>
                    )}

                    {t.status === "closed" && (
                      <button onClick={() => reopenTicket(t.id)}
                        className="text-xs text-muted-foreground hover:text-green-400 transition-colors flex items-center gap-1 mt-1 border border-border/40 rounded-lg px-3 py-1.5 hover:border-green-500/30 hover:bg-green-500/10">
                        <LockOpen className="w-3 h-3" /> بازگشایی تیکت
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
