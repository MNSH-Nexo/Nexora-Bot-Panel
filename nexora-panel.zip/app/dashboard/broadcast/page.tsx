"use client";
import { apiFetch } from "@/lib/api";
import { useState, useRef, useCallback } from "react";
import { Send, Users, CheckCircle2, ImagePlus, X, FileImage, AlertCircle, Info } from "lucide-react";

function formatBytes(bytes: number): string {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}

export default function BroadcastPage() {
  const [msg, setMsg]             = useState("");
  const [caption, setCaption]     = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageDims, setImageDims] = useState<{ w: number; h: number } | null>(null);
  const [sent, setSent]           = useState(false);
  const [sending, setSending]     = useState(false);
  const [sendError, setSendError] = useState<string | null>(null);
  const [sendResult, setSendResult] = useState<{ sent: number; total: number } | null>(null);
  const [mode, setMode]           = useState<"text" | "photo">("text");
  const fileRef = useRef<HTMLInputElement>(null);

  const handleImagePick = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setSendError(null);
    if (file.size > 10 * 1024 * 1024) {
      setSendError("حجم تصویر نباید بیش از ۱۰ مگابایت باشد");
      return;
    }
    const url = URL.createObjectURL(file);
    const img = new window.Image();
    img.onload = () => {
      setImageDims({ w: img.naturalWidth, h: img.naturalHeight });
      URL.revokeObjectURL(url);
    };
    img.src = url;
    setImageFile(file);
    setImagePreview(URL.createObjectURL(file));
  }, []);

  const removeImage = useCallback(() => {
    setImageFile(null);
    setImagePreview(null);
    setImageDims(null);
    if (fileRef.current) fileRef.current.value = "";
  }, []);

  const canSend = mode === "text" ? msg.trim().length > 0 : imageFile !== null;

  const handleSend = async () => {
    if (!canSend || sending) return;
    setSending(true); setSendError(null); setSendResult(null);
    try {
      let res: Response;
      if (mode === "photo" && imageFile) {
        const form = new FormData();
        form.append("photo",   imageFile);
        form.append("message", caption.trim());
        form.append("target",  "all_users");
        res = await apiFetch("/api/broadcast", { method: "POST", body: form });
      } else {
        res = await apiFetch("/api/broadcast", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message: msg.trim(), target: "all_users" }),
        });
      }
      const data = await res.json();
      if (res.ok) {
        setSent(true);
        setSendResult({ sent: data.estimated_recipients ?? 0, total: data.estimated_recipients ?? 0 });
        setMsg(""); setCaption(""); removeImage();
        setTimeout(() => { setSent(false); setSendResult(null); }, 7000);
      } else {
        setSendError(data.error ?? "خطا در ارسال");
      }
    } catch {
      setSendError("خطا در اتصال به سرور");
    } finally {
      setSending(false);
    }
  };

  const btnModeClass = (m: "text" | "photo") =>
    mode === m
      ? "bg-primary/15 border-primary/40 text-primary"
      : "bg-secondary border-border text-muted-foreground hover:text-foreground";

  const btnSendClass = sent
    ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
    : canSend && !sending
    ? "bg-primary text-primary-foreground hover:bg-primary/90"
    : "bg-secondary text-muted-foreground cursor-not-allowed";

  return (
    <div className="space-y-6 max-w-2xl">
      <div className="animate-in-up" style={{ animationDelay: "0ms" }}>
        <h1 className="text-xl font-bold text-foreground">پیام دسته‌جمعی</h1>
        <p className="text-sm text-muted-foreground mt-0.5">ارسال پیام به تمام کاربران ربات</p>
      </div>

      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4" style={{ animationDelay: "50ms" }}>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Users className="w-4 h-4" />
          <span>پیام از طریق <span className="text-foreground font-semibold">ربات تلگرام</span> به <span className="text-emerald-400 font-semibold">همه کاربران</span> ارسال می‌شود</span>
        </div>

        {sendError && (
          <div className="flex items-start gap-2 text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2">
            <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
            <span>{sendError}</span>
          </div>
        )}
        {sendResult && (
          <div className="flex items-center gap-2 text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-xl px-3 py-2">
            <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
            پیام در صف ربات قرار گرفت — ظرف ۱۵ ثانیه برای ~{sendResult.total} کاربر ارسال می‌شود
          </div>
        )}

        <div className="flex gap-2">
          {(["text", "photo"] as const).map((m) => (
            <button key={m} onClick={() => { setMode(m); setSendError(null); }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${btnModeClass(m)}`}>
              {m === "text" ? <><Send className="w-3 h-3" />پیام متنی</> : <><FileImage className="w-3 h-3" />عکس + کپشن</>}
            </button>
          ))}
        </div>

        {mode === "text" ? (
          <textarea
            value={msg} onChange={(e) => setMsg(e.target.value)}
            placeholder={"متن پیام...\n\nHTML: <b>bold</b>، <i>italic</i>، <code>code</code>"}
            rows={5}
            className="w-full px-4 py-3 rounded-xl bg-input border border-border text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:border-primary/50 transition-colors resize-none leading-relaxed"
          />
        ) : (
          <div className="space-y-3">
            {!imagePreview ? (
              <button onClick={() => fileRef.current?.click()}
                className="w-full h-32 rounded-xl border-2 border-dashed border-border hover:border-primary/40 flex flex-col items-center justify-center gap-2 text-muted-foreground hover:text-primary transition-colors">
                <ImagePlus className="w-6 h-6" />
                <span className="text-sm">انتخاب تصویر</span>
                <span className="text-xs opacity-60">JPG یا PNG — حداکثر ۱۰ مگابایت — تصاویر بزرگ خودکار فشرده می‌شوند</span>
              </button>
            ) : (
              <div className="relative rounded-xl overflow-hidden border border-border/60">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={imagePreview} alt="preview" className="w-full max-h-48 object-cover" />
                <button onClick={removeImage}
                  className="absolute top-2 left-2 w-7 h-7 bg-background/80 backdrop-blur-sm rounded-full flex items-center justify-center text-muted-foreground hover:text-red-400 transition-colors">
                  <X className="w-3.5 h-3.5" />
                </button>
                <div className="absolute bottom-2 right-2 flex items-center gap-1.5 bg-background/75 backdrop-blur-sm rounded-lg px-2 py-0.5 text-xs text-muted-foreground">
                  {imageDims && <span>{imageDims.w}x{imageDims.h}</span>}
                  {imageDims && <span>.</span>}
                  <span>{formatBytes(imageFile?.size ?? 0)}</span>
                </div>
                {imageFile && imageFile.size > 3 * 1024 * 1024 && (
                  <div className="absolute top-2 right-2 flex items-center gap-1 bg-amber-500/80 backdrop-blur-sm rounded-lg px-2 py-0.5 text-xs text-white">
                    <Info className="w-3 h-3" />
                    خودکار فشرده می‌شود
                  </div>
                )}
              </div>
            )}
            <input ref={fileRef} type="file" accept="image/jpeg,image/png,image/webp,image/gif" onChange={handleImagePick} className="hidden" />
            <textarea
              value={caption} onChange={(e) => setCaption(e.target.value)}
              placeholder="کپشن تصویر (اختیاری)..."
              rows={3}
              className="w-full px-4 py-3 rounded-xl bg-input border border-border text-sm text-foreground placeholder:text-muted-foreground/40 focus:outline-none focus:border-primary/50 transition-colors resize-none"
            />
          </div>
        )}

        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">
            {mode === "text" ? (msg.length + " کاراکتر") : (imageFile ? formatBytes(imageFile.size) : "بدون تصویر")}
          </span>
          <div className="flex gap-2">
            <button onClick={() => { setMsg(""); setCaption(""); removeImage(); setSendError(null); }}
              className="px-4 py-2 rounded-xl bg-secondary text-muted-foreground text-sm hover:text-foreground transition-colors">
              پاک کردن
            </button>
            <button onClick={handleSend} disabled={!canSend || sending}
              className={`flex items-center gap-2 px-5 py-2 rounded-xl text-sm font-semibold transition-all ${btnSendClass}`}>
              {sent ? <><CheckCircle2 className="w-4 h-4" />ارسال شد!</>
                : sending ? <><Send className="w-4 h-4 animate-pulse" />در حال ارسال...</>
                : <><Send className="w-4 h-4" />ارسال نوتیف</>}
            </button>
          </div>
        </div>
      </div>

      {sendResult && (
        <div className="animate-in-up rounded-2xl border border-emerald-500/20 bg-emerald-500/8 p-4 flex items-center gap-3" style={{ animationDelay: "100ms" }}>
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <div>
            <p className="text-sm font-semibold text-emerald-400">پیام با موفقیت در صف قرار گرفت</p>
            <p className="text-xs text-muted-foreground mt-0.5">تقریباً {sendResult.sent} کاربر در ۱۵ ثانیه دریافت می‌کنند</p>
          </div>
        </div>
      )}
    </div>
  );
}
