"use client";
import { apiFetch } from "@/lib/api";
import { useEffect, useState, useCallback } from "react";
import { Link2, ToggleLeft, ToggleRight, Save, Wifi, CheckCircle2, RefreshCw, AlertCircle, Package } from "lucide-react";

type Inbound = { id: number; remark: string; protocol: string; port: number; };
type Plan    = { id: number; name: string; traffic_gb: number; duration_days: number; };

const protoColor: Record<string, string> = {
  vless:  "bg-blue-500/15 border-blue-500/25 text-blue-400",
  vmess:  "bg-violet-500/15 border-violet-500/25 text-violet-400",
  trojan: "bg-orange-500/15 border-orange-500/25 text-orange-400",
};

const TRIGGER_OPTIONS = [
  { value: "on_register",       label: "📋 هنگام ثبت‌نام دوست دعوت‌شده" },
  { value: "on_first_purchase", label: "🛒 بعد از اولین خرید دوست" },
  { value: "on_every_purchase", label: "🔄 بعد از هر خرید دوست" },
] as const;

export default function ReferralPage() {
  const [enabled,      setEnabled]      = useState(true);
  // نوع پاداش
  const [rewardType,   setRewardType]   = useState<"custom" | "plan">("custom");
  // custom reward
  const [trafficGb,    setTrafficGb]    = useState("5");
  const [days,         setDays]         = useState("30");
  const [inboundId,    setInboundId]    = useState<number | null>(null);
  // plan reward
  const [planId,       setPlanId]       = useState<number>(0);
  // trigger
  const [trigger,      setTrigger]      = useState("on_first_purchase");
  // data
  const [inbounds,     setInbounds]     = useState<Inbound[]>([]);
  const [plans,        setPlans]        = useState<Plan[]>([]);
  const [loading,      setLoading]      = useState(true);
  const [saving,       setSaving]       = useState(false);
  const [saved,        setSaved]        = useState(false);
  const [error,        setError]        = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [cfgRes, inbRes, plansRes] = await Promise.all([
        apiFetch("/api/bot-config"),
        apiFetch("/api/inbounds"),
        apiFetch("/api/plans"),
      ]);
      if (cfgRes.ok) {
        const d = await cfgRes.json();
        const c = d.config ?? {};
        setEnabled(c.referral_enabled !== "0");
        setRewardType(c.referral_reward_type === "plan" ? "plan" : "custom");
        if (c.referral_custom_traffic_gb) setTrafficGb(c.referral_custom_traffic_gb);
        if (c.referral_custom_days)       setDays(c.referral_custom_days);
        if (c.referral_inbound_id)        setInboundId(Number(c.referral_inbound_id));
        if (c.referral_reward_plan_id)    setPlanId(Number(c.referral_reward_plan_id));
        if (c.referral_trigger)           setTrigger(c.referral_trigger);
      }
      if (inbRes.ok) {
        const d = await inbRes.json();
        const list: Inbound[] = (d.inbounds ?? []).map((i: Record<string, unknown>) => ({
          id: Number(i.id), remark: String(i.remark ?? `#${i.id}`),
          protocol: String(i.protocol ?? "unknown"), port: Number(i.port ?? 0),
        }));
        setInbounds(list);
        if (!inboundId && list.length > 0) setInboundId(list[0].id);
      }
      if (plansRes.ok) {
        const d = await plansRes.json();
        const list: Plan[] = (d.plans ?? [])
          .filter((p: { is_active: boolean }) => p.is_active)
          .map((p: Plan) => ({ id: p.id, name: p.name, traffic_gb: p.traffic_gb, duration_days: p.duration_days }));
        setPlans(list);
        if (!planId && list.length > 0) setPlanId(list[0].id);
      }
    } finally {
      setLoading(false);
    }
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleSave = async () => {
    setSaving(true); setError(null);
    try {
      const res = await apiFetch("/api/bot-config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          referral_enabled:          enabled ? "1" : "0",
          referral_reward_type:      rewardType,
          referral_custom_traffic_gb: trafficGb,
          referral_custom_days:       days,
          referral_inbound_id:        inboundId?.toString() ?? "",
          referral_reward_plan_id:    planId.toString(),
          referral_trigger:           trigger,
        }),
      });
      if (res.ok) { setSaved(true); setTimeout(() => setSaved(false), 2500); }
      else { const d = await res.json(); setError(d.error ?? "خطا در ذخیره"); }
    } catch { setError("خطا در اتصال"); }
    finally { setSaving(false); }
  };

  return (
    <div className="space-y-6 max-w-2xl">
      {/* Header */}
      <div className="animate-in-up flex items-center justify-between" style={{ animationDelay: "0ms" }}>
        <div>
          <h1 className="text-xl font-bold text-foreground">سیستم دعوت دوستان (Referral)</h1>
          <p className="text-sm text-muted-foreground mt-0.5">پاداش به دعوت‌کننده داده می‌شود</p>
        </div>
        <button onClick={fetchData} disabled={loading}
          className="p-2 rounded-lg border border-border hover:border-primary/50 text-muted-foreground hover:text-primary transition-colors disabled:opacity-50">
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {error && (
        <div className="flex items-center gap-2 px-4 py-3 rounded-xl border border-red-500/30 bg-red-500/8 text-red-300 text-sm">
          <AlertCircle className="w-4 h-4 shrink-0" />{error}
        </div>
      )}

      {/* Enable/disable */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5" style={{ animationDelay: "50ms" }}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-primary/15 border border-primary/25 flex items-center justify-center">
              <Link2 className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">وضعیت سیستم referral</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {enabled ? "کاربران می‌توانند دوست دعوت کنند و پاداش بگیرند" : "سیستم referral غیرفعال است"}
              </p>
            </div>
          </div>
          <button onClick={() => setEnabled(!enabled)}>
            {enabled
              ? <ToggleRight className="w-10 h-10 text-primary" />
              : <ToggleLeft  className="w-10 h-10 text-muted-foreground" />}
          </button>
        </div>
      </div>

      {/* نوع پاداش */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4" style={{ animationDelay: "100ms" }}>
        <h2 className="text-sm font-semibold text-foreground">نوع پاداش دعوت‌کننده</h2>
        <div className="flex gap-2">
          {([
            ["custom", "⚙️ کانفیگ دلخواه"],
            ["plan",   "📦 پلن آماده"],
          ] as [string, string][]).map(([val, label]) => (
            <button key={val} onClick={() => setRewardType(val as "custom" | "plan")}
              className={[
                "flex-1 px-3 py-2.5 rounded-xl text-sm font-medium border transition-colors",
                rewardType === val
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-input border-border text-muted-foreground hover:border-primary/40",
              ].join(" ")}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Custom reward: حجم + روز + اینباند */}
      {rewardType === "custom" && (
        <>
          <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4" style={{ animationDelay: "150ms" }}>
            <h2 className="text-sm font-semibold text-foreground">مشخصات کانفیگ پاداش</h2>
            <div className="grid grid-cols-2 gap-4">
              {[
                { label: "حجم (گیگابایت)", value: trafficGb, set: setTrafficGb, unit: "GB" },
                { label: "مدت (روز)",       value: days,      set: setDays,       unit: "روز" },
              ].map(({ label, value, set, unit }) => (
                <div key={unit}>
                  <label className="text-xs text-muted-foreground mb-1.5 block">{label}</label>
                  <div className="flex items-center gap-2">
                    <input value={value} onChange={e => set(e.target.value)} type="number" min="1" dir="ltr"
                      className="flex-1 px-3 py-2.5 rounded-xl bg-input border border-border text-sm text-foreground font-mono focus:outline-none focus:border-primary/50 transition-colors" />
                    <span className="text-xs text-muted-foreground shrink-0">{unit}</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="bg-secondary/30 rounded-xl px-4 py-3 border border-border/40">
              <p className="text-xs text-muted-foreground">
                پاداش: <span className="text-foreground font-semibold">{trafficGb || "5"} GB</span> به مدت{" "}
                <span className="text-foreground font-semibold">{days || "30"} روز</span>
              </p>
            </div>
          </div>

          {/* Inbound */}
          <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-4" style={{ animationDelay: "200ms" }}>
            <div>
              <h2 className="text-sm font-semibold text-foreground">اینباند پاداش referral</h2>
              <p className="text-xs text-muted-foreground mt-0.5">اینباندی که کانفیگ پاداش روی آن ساخته می‌شود</p>
            </div>
            {loading ? (
              <div className="space-y-2">
                {[1,2,3].map(i => <div key={i} className="h-14 rounded-xl border border-border/30 bg-card/40 animate-pulse" />)}
              </div>
            ) : inbounds.length === 0 ? (
              <div className="px-4 py-3 rounded-xl border border-yellow-500/20 bg-yellow-500/8 text-yellow-300 text-xs">
                اینباندی یافت نشد — اتصال به پنل را بررسی کنید.
              </div>
            ) : (
              <div className="grid gap-2">
                {inbounds.map(inb => {
                  const sel = inboundId === inb.id;
                  return (
                    <button key={inb.id} onClick={() => setInboundId(inb.id)}
                      className={[
                        "flex items-center gap-3 p-3 rounded-xl border text-right transition-all",
                        sel ? "border-primary/50 bg-primary/8" : "border-border/50 bg-background/40 hover:border-border",
                      ].join(" ")}>
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border ${protoColor[inb.protocol] ?? "bg-secondary border-border text-muted-foreground"}`}>
                        <Wifi className="w-4 h-4" />
                      </div>
                      <div className="flex-1 min-w-0 text-right">
                        <p className={`text-sm font-medium ${sel ? "text-primary" : "text-foreground"}`}>{inb.remark}</p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${protoColor[inb.protocol] ?? "bg-secondary border-border text-muted-foreground"}`}>
                            {inb.protocol.toUpperCase()}
                          </span>
                          <span className="text-xs text-muted-foreground">پورت: {inb.port}</span>
                        </div>
                      </div>
                      <div className={`w-4 h-4 rounded-full border-2 shrink-0 flex items-center justify-center ${sel ? "border-primary bg-primary" : "border-border"}`}>
                        {sel && <CheckCircle2 className="w-3 h-3 text-primary-foreground" />}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
            {!inboundId && inbounds.length > 0 && (
              <p className="text-xs text-yellow-400 bg-yellow-500/10 border border-yellow-500/20 rounded-xl px-3 py-2">
                ⚠️ هیچ اینباندی انتخاب نشده — اولین اینباند فعال به‌صورت خودکار استفاده می‌شود
              </p>
            )}
          </div>
        </>
      )}

      {/* Plan reward */}
      {rewardType === "plan" && (
        <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-3" style={{ animationDelay: "150ms" }}>
          <div>
            <h2 className="text-sm font-semibold text-foreground">پلن پاداش</h2>
            <p className="text-xs text-muted-foreground mt-0.5">این پلن رایگان به دعوت‌کننده داده می‌شود</p>
          </div>
          {plans.length === 0 ? (
            <div className="px-4 py-3 rounded-xl border border-yellow-500/20 bg-yellow-500/8 text-yellow-300 text-xs">
              ⚠️ هیچ پلن فعالی یافت نشد. ابتدا از بخش پلن‌ها پلن بسازید.
            </div>
          ) : (
            <div className="grid gap-2">
              {plans.map(p => {
                const sel = planId === p.id;
                return (
                  <button key={p.id} onClick={() => setPlanId(p.id)}
                    className={[
                      "flex items-center gap-3 p-3 rounded-xl border text-right transition-all",
                      sel ? "border-primary/50 bg-primary/8" : "border-border/50 bg-background/40 hover:border-border",
                    ].join(" ")}>
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 border ${sel ? "bg-primary/20 border-primary/40 text-primary" : "bg-secondary border-border text-muted-foreground"}`}>
                      <Package className="w-4 h-4" />
                    </div>
                    <div className="flex-1 min-w-0 text-right">
                      <p className={`text-sm font-medium ${sel ? "text-primary" : "text-foreground"}`}>{p.name}</p>
                      <p className="text-xs text-muted-foreground">{p.traffic_gb} GB — {p.duration_days} روز</p>
                    </div>
                    <div className={`w-4 h-4 rounded-full border-2 shrink-0 flex items-center justify-center ${sel ? "border-primary bg-primary" : "border-border"}`}>
                      {sel && <CheckCircle2 className="w-3 h-3 text-primary-foreground" />}
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* زمان اعطا */}
      <div className="animate-in-up rounded-2xl border border-border/60 bg-card p-5 space-y-3" style={{ animationDelay: "250ms" }}>
        <div>
          <h2 className="text-sm font-semibold text-foreground">زمان اعطای پاداش</h2>
          <p className="text-xs text-muted-foreground mt-0.5">پاداش چه زمانی به دعوت‌کننده داده شود؟</p>
        </div>
        <div className="flex flex-col gap-1.5">
          {TRIGGER_OPTIONS.map(({ value, label }) => (
            <button key={value} onClick={() => setTrigger(value)}
              className={[
                "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm border transition-colors text-right",
                trigger === value
                  ? "bg-primary/10 border-primary text-foreground"
                  : "bg-input border-border text-muted-foreground hover:border-primary/40",
              ].join(" ")}>
              <span className={[
                "w-3 h-3 rounded-full flex-shrink-0 border-2 transition-colors",
                trigger === value ? "bg-primary border-primary" : "border-muted-foreground",
              ].join(" ")} />
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* راهنما */}
      <div className="animate-in-up rounded-2xl border border-border/40 bg-secondary/20 px-4 py-3" style={{ animationDelay: "300ms" }}>
        <p className="text-xs text-muted-foreground leading-relaxed">
          💡 پاداش همیشه به <span className="text-foreground font-semibold">دعوت‌کننده</span> داده می‌شود، نه کاربر دعوت‌شده.
          کاربران لینک دعوت اختصاصی خود را از ربات دریافت می‌کنند.
        </p>
      </div>

      {/* Save */}
      <div className="animate-in-up pb-4" style={{ animationDelay: "350ms" }}>
        <button onClick={handleSave} disabled={saving}
          className={[
            "flex items-center gap-2 px-6 py-2.5 rounded-xl text-sm font-semibold transition-all",
            saved
              ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
              : "bg-primary text-primary-foreground hover:bg-primary/90",
          ].join(" ")}>
          <Save className="w-4 h-4" />
          {saved ? "ذخیره شد ✓" : saving ? "در حال ذخیره..." : "ذخیره تنظیمات"}
        </button>
      </div>
    </div>
  );
}
