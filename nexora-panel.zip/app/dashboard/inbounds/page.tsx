"use client";
import { apiFetch } from "@/lib/api";
import { useCallback, useEffect, useState } from "react";
import { ToggleLeft, ToggleRight, Wifi, WifiOff, Activity, Info, RefreshCw, AlertCircle } from "lucide-react";

type Inbound = {
  id: number; remark: string; protocol: string; port: number;
  enable: boolean; clients: number; up: number; down: number;
  panel_enabled: boolean;
};

const protoColor: Record<string, string> = {
  vless:  "bg-blue-500/15 border-blue-500/25 text-blue-400",
  vmess:  "bg-violet-500/15 border-violet-500/25 text-violet-400",
  trojan: "bg-orange-500/15 border-orange-500/25 text-orange-400",
};

export default function InboundsPage() {
  const [inbounds, setInbounds] = useState<Inbound[]>([]);
  const [loading, setLoading]   = useState(true);
  const [source, setSource]     = useState<string>("loading");
  const [error, setError]       = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const res = await apiFetch("/api/inbounds");
      if (res.ok) {
        const d = await res.json();
        setInbounds(d.inbounds ?? []);
        setSource(d.source ?? "unknown");
      } else {
        setError("خطا در دریافت اطلاعات اینباندها");
      }
    } catch { setError("خطا در اتصال به سرور"); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const togglePanelEnabled = async (inb: Inbound) => {
    const res = await apiFetch("/api/inbounds", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ inbound_id: inb.id }),
    });
    if (res.ok) {
      setInbounds(prev => prev.map(i =>
        i.id === inb.id ? { ...i, panel_enabled: !i.panel_enabled } : i
      ));
    }
  };

  const totalClients = inbounds.filter(x => x.panel_enabled).reduce((s, x) => s + (x.clients ?? 0), 0);

  return (
    <div className="space-y-6">
      <div className="animate-in-up flex items-center justify-between" style={{ animationDelay: "0ms" }}>
        <div>
          <h1 className="text-xl font-bold text-foreground">اینباندهای 3X-UI</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {inbounds.filter(x => x.panel_enabled).length} اینباند فعال — {totalClients} کلاینت
            {source === "live" && <span className="text-green-400/60 mr-2">• زنده</span>}
            {source === "panel_unavailable" && <span className="text-yellow-400 mr-2">— پنل 3X-UI در دسترس نیست</span>}
          </p>
        </div>
        <button onClick={fetchData} disabled={loading}
          className="p-2 rounded-lg border border-border hover:border-primary/50 text-muted-foreground hover:text-primary transition-colors disabled:opacity-50">
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
        </button>
      </div>

      <div className="animate-in-up rounded-2xl border border-blue-500/20 bg-blue-500/5 px-4 py-3.5 flex gap-3" style={{ animationDelay: "30ms" }}>
        <Info className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="text-xs font-semibold text-blue-300">این بخش چه کاری می‌کند؟</p>
          <p className="text-xs text-muted-foreground leading-relaxed">
            اینباندهایی که <span className="text-emerald-400 font-medium">فعال</span> هستند در pool ساخت کانفیگ قرار می‌گیرند.
            ربات به‌صورت <span className="text-foreground font-medium">round-robin</span> بین آن‌ها کانفیگ می‌سازد.
          </p>
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-2 px-4 py-3 rounded-xl border border-red-500/30 bg-red-500/8 text-red-300 text-sm">
          <AlertCircle className="w-4 h-4 shrink-0" />{error}
        </div>
      )}

      {loading ? (
        <div className="space-y-3">
          {[1,2,3].map(i => <div key={i} className="rounded-2xl border border-border/30 bg-card/40 h-20 animate-pulse" />)}
        </div>
      ) : inbounds.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground text-sm">
          {source === "panel_unavailable"
            ? "پنل 3X-UI در دسترس نیست — مطمئن شوید PANEL_URL و PANEL_USERNAME/PASSWORD در .env.local پنل تنظیم شده‌اند."
            : "هیچ اینباندی یافت نشد"}
        </div>
      ) : (
        <div className="animate-in-up grid gap-3" style={{ animationDelay: "50ms" }}>
          {inbounds.map((inb, i) => (
            <div key={inb.id}
              className={`rounded-2xl border p-4 transition-all duration-200 ${
                inb.panel_enabled ? "border-border/60 bg-card hover:border-primary/25" : "border-border/30 bg-card/40 opacity-55"
              }`}
              style={{ animationDelay: `${i * 50 + 80}ms` }}>
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${protoColor[inb.protocol] ?? "bg-secondary border-border text-muted-foreground"}`}>
                  {inb.enable ? <Wifi className="w-5 h-5" /> : <WifiOff className="w-5 h-5" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold text-foreground">{inb.remark}</p>
                    <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${protoColor[inb.protocol] ?? "bg-secondary border-border text-muted-foreground"}`}>
                      {inb.protocol.toUpperCase()}
                    </span>
                    {!inb.enable && (
                      <span className="text-[10px] text-red-400/70 border border-red-400/20 px-1.5 py-0.5 rounded">در پنل غیرفعال</span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 mt-0.5 text-xs text-muted-foreground flex-wrap">
                    <span>پورت: <span className="font-mono">{inb.port}</span></span>
                    <span className="text-muted-foreground/40">·</span>
                    <span>{inb.clients ?? 0} کلاینت</span>
                    {inb.panel_enabled && (inb.up > 0 || inb.down > 0) && (
                      <>
                        <span className="text-muted-foreground/40">·</span>
                        <span className="text-emerald-400/80 flex items-center gap-1">
                          <Activity className="w-3 h-3" />
                          ↑{(inb.up / 1073741824).toFixed(1)} GB  ↓{(inb.down / 1073741824).toFixed(1)} GB
                        </span>
                      </>
                    )}
                  </div>
                </div>
                <button onClick={() => togglePanelEnabled(inb)}
                  className={`p-2 rounded-lg transition-colors shrink-0 ${inb.panel_enabled ? "text-emerald-400 hover:bg-emerald-500/10" : "text-muted-foreground hover:bg-secondary"}`}
                  title={inb.panel_enabled ? "از pool حذف کن" : "به pool اضافه کن"}>
                  {inb.panel_enabled ? <ToggleRight className="w-6 h-6" /> : <ToggleLeft className="w-6 h-6" />}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="animate-in-up rounded-2xl border border-border/40 bg-secondary/20 px-4 py-3 space-y-1" style={{ animationDelay: "300ms" }}>
        <p className="text-xs text-muted-foreground">
          💡 غیرفعال کردن یک اینباند <span className="text-foreground font-medium">اشتراک‌های فعلی را تحت‌تأثیر قرار نمی‌دهد</span> — فقط ساخت کانفیگ جدید روی آن متوقف می‌شود.
        </p>
      </div>
    </div>
  );
}
