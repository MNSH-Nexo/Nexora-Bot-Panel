// Default webpath entry — /nexora
// In production, WEB_PANEL_PATH is read from .env.local
import { redirect } from "next/navigation";
export default function WebPathEntry() {
  redirect("/login");
}
