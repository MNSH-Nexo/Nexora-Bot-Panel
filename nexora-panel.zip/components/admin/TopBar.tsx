"use client";
import { Bell, RefreshCw, LogOut, RotateCcw, Bot, Monitor, Layers } from "lucide-react";
import { useRouter, usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { useLiveStats } from "@/hooks/useLiveStats";

type NotifItem = { type: string; label: string; time: string; link: string };
type NotifData = {
  total: number; pendingPayments: number; openTickets: number;
  expiringSoon: number; items: NotifItem[]; source: string;
};
type RestartTarget = "bot" | "panel" | "both";
type RestartState = "idle" | "loading" | "done" | "error";

function timeAgo(iso: string): string {
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (diff < 60)    return `${diff}ث پیش`;
  if (diff < 3600)  return `${Math.floor(diff / 60)}د پیش`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}س پیش`;
  return `${Math.floor(diff / 86400)}ر پیش`;
}

function NotifDropdown({ onClose, prefix }: { onClose: () => void; prefix: string }) {
  const [data, setData] = useState<NotifData | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    fetch(`${prefix}/api/notifications`)
      .then(r => r.ok ? r.json() : null)
      .then(d => { if (d) setData(d); })
      .finally(() => setLoading(false));
  }, [prefix]);

  const go = (link: string) => { router.push(prefix + link); onClose(); };

  return (
    <div className="absolute left-0 top-10 w-80 rounded-2xl border border-border bg-card shadow-2xl shadow-background/50 z-50 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border/60">
        <span className="text-sm font-semibold text-foreground">اعلان‌ها</span>
        {data && data.total > 0 && (
          <span className="text-xs bg-primary/15 text-primary border border-primary/30 px-2 py-0.5 rounded-full font-medium">
            {data.total} مورد
          </span>
        )}
      </div>
      {data && (
        <div className="flex gap-2 px-4 py-2.5 border-b border-border/40">
          <button onClick={() => go("/dashboard/payments")}
            className={`flex-1 rounded-xl px-2 py-1.5 text-xs font-medium border transition-colors text-center ${data.pendingPayments > 0 ? "bg-yellow-500/10 border-yellow-500/25 text-yellow-400 hover:bg-yellow-500/20" : "bg-secondary border-border text-muted-foreground"}`}>
            💳 {data.pendingPayments} در انتظار
          </button>
          <button onClick={() => go("/dashboard/tickets")}
            className={`flex-1 rounded-xl px-2 py-1.5 text-xs font-medium border transition-colors text-center ${data.openTickets > 0 ? "bg-blue-500/10 border-blue-500/25 text-blue-400 hover:bg-blue-500/20" : "bg-secondary border-border text-muted-foreground"}`}>
            🎫 {data.openTickets} تیکت
          </button>
          <button onClick={() => go("/dashboard/users")}
            className={`flex-1 rounded-xl px-2 py-1.5 text-xs font-medium border transition-colors text-center ${data.expiringSoon > 0 ? "bg-orange-500/10 border-orange-500/25 text-orange-400 hover:bg-orange-500/20" : "bg-secondary border-border text-muted-foreground"}`}>
            ⏰ {data.expiringSoon} انقضا
          </button>
        </div>
      )}
      <div className="max-h-72 overflow-y-auto">
        {loading && (
          <div className="space-y-2 p-3">
            {[1,2,3].map(i => <div key={i} className="h-10 rounded-lg bg-background/60 animate-pulse" />)}
          </div>
        )}
        {!loading && (!data || data.items.length === 0) && (
          <div className="py-8 text-center">
            <p className="text-xs text-muted-foreground">هیچ اعلان جدیدی وجود ندارد</p>
            {data?.source === "unavailable" && <p className="text-xs text-yellow-400/70 mt-1">دیتابیس ربات در دسترس نیست</p>}
          </div>
        )}
        {!loading && data?.items.map((item, i) => (
          <button key={i} onClick={() => go(item.link)}
            className="w-full flex items-start gap-3 px-4 py-2.5 hover:bg-secondary/60 transition-colors text-right border-b border-border/30 last:border-0">
            <span className="mt-0.5 text-base shrink-0">{item.type === "payment" ? "💳" : "🎫"}</span>
            <div className="flex-1 min-w-0">
              <p className="text-xs text-foreground truncate">{item.label}</p>
              <p className="text-[10px] text-muted-foreground/60 mt-0.5">{timeAgo(item.time)}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

function RestartDropdown({ onClose, prefix }: { onClose: () => void; prefix: string }) {
  const [state, setState] = useState<RestartState>("idle");
  const [target, setTarget] = useState<RestartTarget | null>(null);
  const [results, setResults] = useState<Array<{ label: string; ok: boolean; out: string }>>([]);

  const doRestart = async (t: RestartTarget) => {
    setTarget(t); setState("loading"); setResults([]);
    try {
      const res = await fetch(`${prefix}/api/restart`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ target: t }),
      });
      const d = await res.json();
      setResults(d.results ?? []);
      setState(d.ok ? "done" : "error");
    } catch {
      setResults([{ label: "خطا", ok: false, out: "خطا در اتصال" }]);
      setState("error");
    }
    setTimeout(() => { setState("idle"); setResults([]); }, 6000);
  };

  const buttons: Array<{ target: RestartTarget; label: string; icon: React.ReactNode; color: string }> = [
    { target: "bot",   label: "ری‌استارت ربات",   icon: <Bot className="w-3.5 h-3.5" />,     color: "hover:border-blue-500/40 hover:text-blue-400" },
    { target: "panel", label: "ری‌استارت وب‌پنل", icon: <Monitor className="w-3.5 h-3.5" />, color: "hover:border-violet-500/40 hover:text-violet-400" },
    { target: "both",  label: "ری‌استارت هر دو",  icon: <Layers className="w-3.5 h-3.5" />,  color: "hover:border-primary/40 hover:text-primary" },
  ];

  return (
    <div className="absolute left-0 top-10 w-72 rounded-2xl border border-border bg-card shadow-2xl shadow-background/50 z-50 overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-border/60">
        <span className="text-sm font-semibold text-foreground">ری‌استارت سرویس‌ها</span>
      </div>
      <div className="p-3 space-y-2">
        {buttons.map(b => (
          <button key={b.target} onClick={() => doRestart(b.target)} disabled={state === "loading"}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl border border-border bg-secondary text-sm text-muted-foreground transition-all disabled:opacity-50 ${b.color}`}>
            {state === "loading" && target === b.target ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : b.icon}
            {b.label}
          </button>
        ))}
      </div>
      {results.length > 0 && (
        <div className="px-3 pb-3 space-y-1.5">
          {results.map((r, i) => (
            <div key={i} className={`rounded-xl px-3 py-2 text-xs border ${r.ok ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" : "bg-red-500/10 border-red-500/20 text-red-400"}`}>
              <p className="font-medium">{r.label}</p>
              {r.out && <p className="text-[10px] mt-0.5 opacity-80 line-clamp-2">{r.out}</p>}
            </div>
          ))}
        </div>
      )}
      <div className="px-4 py-2.5 border-t border-border/40">
        <p className="text-[10px] text-muted-foreground/50">بعد از تغییر تنظیمات، ری‌استارت کنید</p>
      </div>
    </div>
  );
}

function getPrefix(pathname: string): string {
  const dashIdx = pathname.indexOf("/dashboard");
  if (dashIdx > 0) return pathname.slice(0, dashIdx);
  const loginIdx = pathname.indexOf("/login");
  if (loginIdx > 0) return pathname.slice(0, loginIdx);
  return "";
}

export default function TopBar() {
  const router   = useRouter();
  const pathname = usePathname();
  const [notifOpen,   setNotifOpen]   = useState(false);
  const [restartOpen, setRestartOpen] = useState(false);
  const notifRef   = useRef<HTMLDivElement>(null);
  const restartRef = useRef<HTMLDivElement>(null);

  const prefix = getPrefix(pathname);

  // استفاده از SSE زنده به جای polling
  const { stats, connected } = useLiveStats();
  const notifCount = stats.total;

  // Close on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setNotifOpen(false);
      if (restartRef.current && !restartRef.current.contains(e.target as Node)) setRestartOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleLogout = async () => {
    await fetch(`${prefix}/api/auth/logout`, { method: "POST" });
    router.push(`${prefix}/login`);
  };

  return (
    <header className="h-14 border-b border-border/60 flex items-center justify-between px-4 lg:px-6 bg-background/60 backdrop-blur-sm sticky top-0 z-30">
      <div className="flex items-center gap-2 pr-10 lg:pr-0">
        <span className="text-xs text-muted-foreground font-mono hidden sm:block">
          {new Date().toLocaleDateString("fa-IR")}
        </span>
        <span className="text-xs font-bold text-foreground lg:hidden">NEXORA</span>
        {/* نشانگر وضعیت اتصال زنده */}
        <span title={connected ? "اتصال زنده برقرار" : "در حال اتصال مجدد..."}
          className={`hidden sm:inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full border transition-colors ${connected ? "border-green-500/30 bg-green-500/10 text-green-400" : "border-yellow-500/30 bg-yellow-500/10 text-yellow-400"}`}>
          <span className={`w-1.5 h-1.5 rounded-full ${connected ? "bg-green-400 animate-pulse" : "bg-yellow-400"}`} />
          {connected ? "زنده" : "قطع"}
        </span>
      </div>

      <div className="flex items-center gap-2">
        <div ref={restartRef} className="relative">
          <button onClick={() => { setRestartOpen(p => !p); setNotifOpen(false); }} title="ری‌استارت سرویس‌ها"
            className={`w-8 h-8 rounded-lg border flex items-center justify-center transition-colors ${restartOpen ? "border-primary/50 bg-primary/10 text-primary" : "border-border hover:border-primary/50 text-muted-foreground hover:text-primary"}`}>
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          {restartOpen && <RestartDropdown onClose={() => setRestartOpen(false)} prefix={prefix} />}
        </div>

        <div ref={notifRef} className="relative">
          <button onClick={() => { setNotifOpen(p => !p); setRestartOpen(false); }} title="اعلان‌ها"
            className={`relative w-8 h-8 rounded-lg border flex items-center justify-center transition-colors ${notifOpen ? "border-primary/50 bg-primary/10 text-primary" : "border-border hover:border-primary/50 text-muted-foreground hover:text-primary"}`}>
            <Bell className="w-3.5 h-3.5" />
            {notifCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[16px] h-4 px-0.5 rounded-full bg-primary text-[9px] font-bold text-primary-foreground flex items-center justify-center">
                {notifCount > 99 ? "99+" : notifCount}
              </span>
            )}
          </button>
          {notifOpen && <NotifDropdown onClose={() => setNotifOpen(false)} prefix={prefix} />}
        </div>

        <div className="w-8 h-8 rounded-lg bg-primary/20 border border-primary/40 flex items-center justify-center">
          <span className="text-xs font-bold text-primary">A</span>
        </div>

        <button onClick={handleLogout} title="خروج"
          className="w-8 h-8 rounded-lg border border-border hover:border-red-500/50 flex items-center justify-center text-muted-foreground hover:text-red-400 transition-colors">
          <LogOut className="w-3.5 h-3.5" />
        </button>
      </div>
    </header>
  );
}
