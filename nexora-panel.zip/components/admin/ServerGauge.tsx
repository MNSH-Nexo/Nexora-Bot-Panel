import { LucideIcon } from "lucide-react";

type Color = "blue" | "violet" | "orange";
const colorMap: Record<Color, { bar: string; text: string; bg: string; border: string }> = {
  blue:   { bar: "bg-blue-500",   text: "text-blue-400",   bg: "bg-blue-500/10",   border: "border-blue-500/20" },
  violet: { bar: "bg-violet-500", text: "text-violet-400", bg: "bg-violet-500/10", border: "border-violet-500/20" },
  orange: { bar: "bg-orange-500", text: "text-orange-400", bg: "bg-orange-500/10", border: "border-orange-500/20" },
};

interface Props { icon: LucideIcon; label: string; value: number; color: Color; unavailable?: boolean; }

export default function ServerGauge({ icon: Icon, label, value, color, unavailable }: Props) {
  const c = colorMap[color];
  const warn = value > 85;
  return (
    <div className={`rounded-2xl border ${c.border} ${c.bg} p-3.5 flex items-center gap-3`}>
      <div className="shrink-0">
        <Icon className={`w-4 h-4 ${c.text}`} />
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-xs text-muted-foreground">{label}</span>
          {unavailable
            ? <span className="text-[10px] text-muted-foreground/50">N/A</span>
            : <span className={`text-sm font-bold tabular-nums ${warn ? "text-red-400" : "text-foreground"}`}>{value}٪</span>
          }
        </div>
        <div className="h-1.5 bg-background/60 rounded-full overflow-hidden">
          {!unavailable && (
            <div
              className={`h-full rounded-full transition-all duration-700 ${warn ? "bg-red-500" : c.bar}`}
              style={{ width: `${value}%` }}
            />
          )}
        </div>
      </div>
    </div>
  );
}
