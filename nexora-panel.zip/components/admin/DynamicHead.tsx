"use client";
import { apiFetchAsync } from "@/lib/api";
/**
 * DynamicHead — reads panelName + favicon from /api/brand at runtime
 * and updates document.title + favicon without a full page reload.
 * Placed in root layout so it runs on every page.
 * از apiFetchAsync استفاده می‌کنه چون در layout اجرا میشه
 * و ممکنه pathname هنوز /webpath/ باشه (قبل از /login یا /dashboard)
 */
import { useEffect } from "react";

export default function DynamicHead() {
  useEffect(() => {
    apiFetchAsync("/api/brand")
      .then(r => r.ok ? r.json() : null)
      .then(d => {
        if (!d) return;

        // Update tab title — custom tabTitle takes priority
        const name = (d.panelName ?? "NEXORA").trim() || "NEXORA";
        const customTitle = (d.tabTitle ?? "").trim();
        document.title = customTitle || `${name} Admin Panel`;

        // Update favicon if custom one is set
        const faviconUrl: string = d.faviconUrl ?? "";
        if (faviconUrl) {
          // Remove existing favicons
          document.querySelectorAll("link[rel~='icon']").forEach(el => el.remove());
          const link = document.createElement("link");
          link.rel = "icon";
          link.href = faviconUrl + "?v=" + Date.now();
          document.head.appendChild(link);
        }
      })
      .catch(() => {});
  }, []);

  return null;
}
