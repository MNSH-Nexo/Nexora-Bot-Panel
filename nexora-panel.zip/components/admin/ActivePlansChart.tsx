interface Props {
  active?: number; expired?: number; depleted?: number; disabled?: number;
  activePct?: number; expiredPct?: number; depletedPct?: number; disabledPct?: number;
}

export default function ActivePlansChart({
  active = 0, expired = 0, depleted = 0, disabled = 0,
  activePct = 0, expiredPct = 0, depletedPct = 0, disabledPct = 0,
}: Props) {
  const data = [
    { label: "فعال",      value: active,   color: "bg-violet-500",  pct: activePct },
    { label: "منقضی",    value: expired,  color: "bg-slate-600",   pct: expiredPct },
    { label: "تمام‌شده", value: depleted, color: "bg-orange-500",  pct: depletedPct },
    { label: "غیرفعال",  value: disabled, color: "bg-red-500/70",  pct: disabledPct },
  ];
  const total = active + expired + depleted + disabled;

  return (
    <div className="space-y-4">
      <div className="flex h-3 rounded-full overflow-hidden gap-0.5">
        {data.map((d) => (
          <div key={d.label} className={`${d.color} transition-all duration-500`}
            style={{ width: `${d.pct}%` }} />
        ))}
      </div>

      <div className="space-y-2.5">
        {data.map((d) => (
          <div key={d.label} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className={`w-2.5 h-2.5 rounded-full ${d.color}`} />
              <span className="text-xs text-muted-foreground">{d.label}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-semibold text-foreground tabular-nums">{d.value.toLocaleString("fa-IR")}</span>
              <span className="text-[10px] text-muted-foreground/50 w-7 text-left">{d.pct}٪</span>
            </div>
          </div>
        ))}
      </div>

      <div className="pt-2 border-t border-border/40">
        <p className="text-xs text-muted-foreground">
          جمع کل: <span className="text-foreground font-semibold">{total.toLocaleString("fa-IR")}</span> اشتراک
        </p>
      </div>
    </div>
  );
}
