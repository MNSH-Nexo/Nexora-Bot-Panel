"use client";
import { apiFetch } from "@/lib/api";
import { useEffect, useState } from "react";

type Payment = {
  id: number; order_id: string; amount_usdt: number; status: string;
  payment_method: string; created_at: string;
  username?: string; first_name?: string; telegram_id?: number;
};

const statusBadge: Record<string, string> = {
  confirmed:       "bg-emerald-500/15 text-emerald-400 border-emerald-500/25",
  finished:        "bg-emerald-500/15 text-emerald-400 border-emerald-500/25",
  awaiting_review: "bg-yellow-500/15  text-yellow-400  border-yellow-500/25",
  waiting:         "bg-blue-500/15    text-blue-400    border-blue-500/25",
  confirming:      "bg-blue-500/15    text-blue-400    border-blue-500/25",
  failed:          "bg-red-500/15     text-red-400     border-red-500/25",
  expired:         "bg-red-500/15     text-red-400     border-red-500/25",
};
const statusLabel: Record<string, string> = {
  confirmed: "تایید شد", finished: "تایید شد",
  awaiting_review: "در انتظار", waiting: "در صف", confirming: "در صف",
  failed: "ناموفق", expired: "منقضی",
};
const methodLabel: Record<string, string> = {
  card: "کارت", maxelpay: "MaxelPay", nowpayments: "NOWPay", crypto: "کریپتو",
};

function timeAgo(iso: string): string {
  const diff = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (diff < 60)    return `${diff} ثانیه پیش`;
  if (diff < 3600)  return `${Math.floor(diff / 60)} دقیقه پیش`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} ساعت پیش`;
  return `${Math.floor(diff / 86400)} روز پیش`;
}

export default function RecentPayments() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading]   = useState(true);

  useEffect(() => {
    apiFetch("/api/payments?limit=7")
      .then(r => r.ok ? r.json() : null)
      .then(d => { if (d) setPayments(d.payments ?? []); })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="space-y-2">
      {[1,2,3].map(i => <div key={i} className="h-12 rounded-xl bg-background/40 border border-border/30 animate-pulse" />)}
    </div>
  );

  if (payments.length === 0) return (
    <p className="text-xs text-muted-foreground text-center py-4">هیچ تراکنشی ثبت نشده</p>
  );

  return (
    <div className="space-y-2">
      {payments.map((p) => {
        const user = p.first_name ?? p.username ?? `#${p.telegram_id}`;
        const badge = statusBadge[p.status] ?? "bg-secondary text-muted-foreground border-border";
        const label = statusLabel[p.status] ?? p.status;
        const method = methodLabel[p.payment_method] ?? p.payment_method;
        return (
          <div key={p.id} className="flex items-center gap-3 py-2.5 px-3 rounded-xl bg-background/40 border border-border/40 hover:border-border transition-colors">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-foreground truncate">{user}</span>
                <span className="text-[10px] font-mono text-muted-foreground/60 hidden sm:block">{p.order_id}</span>
              </div>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-xs text-muted-foreground">{method}</span>
                <span className="text-muted-foreground/40">·</span>
                <span className="text-xs text-muted-foreground/60">{timeAgo(p.created_at)}</span>
              </div>
            </div>
            <div className="flex items-center gap-2.5 shrink-0">
              <span className="text-sm font-bold text-foreground tabular-nums">${p.amount_usdt}</span>
              <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full border ${badge}`}>{label}</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}
