/**
 * useLiveStats — React hook برای اتصال زنده SSE
 * هر صفحه‌ای که import کنه، آمار زنده دریافت میکنه
 * بدون نیاز به refresh
 */
"use client";
import { useEffect, useState, useRef, useCallback } from "react";
import { getWebPrefix } from "@/lib/api";

export interface LiveStats {
  source: string;
  pendingPayments: number;
  openTickets: number;
  expiringSoon: number;
  total: number;
}

const DEFAULT: LiveStats = {
  source: "loading",
  pendingPayments: 0,
  openTickets: 0,
  expiringSoon: 0,
  total: 0,
};

export function useLiveStats() {
  const [stats, setStats] = useState<LiveStats>(DEFAULT);
  const [connected, setConnected] = useState(false);
  const esRef = useRef<EventSource | null>(null);
  const retryRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const retryCount = useRef(0);

  const connect = useCallback(() => {
    if (typeof window === "undefined") return;
    if (esRef.current) { esRef.current.close(); esRef.current = null; }

    const prefix = getWebPrefix();
    const url = prefix + "/api/live";

    const es = new EventSource(url);
    esRef.current = es;

    es.onopen = () => { setConnected(true); retryCount.current = 0; };

    es.onmessage = (e) => {
      try {
        const data = JSON.parse(e.data) as LiveStats;
        setStats(data);
        setConnected(true);
      } catch { /* ignore parse errors */ }
    };

    es.onerror = () => {
      setConnected(false);
      es.close();
      esRef.current = null;
      // exponential backoff: 3s, 6s, 12s, max 30s
      const delay = Math.min(3000 * Math.pow(2, retryCount.current), 30000);
      retryCount.current++;
      retryRef.current = setTimeout(connect, delay);
    };
  }, []);

  useEffect(() => {
    connect();
    return () => {
      if (esRef.current) { esRef.current.close(); esRef.current = null; }
      if (retryRef.current) clearTimeout(retryRef.current);
    };
  }, [connect]);

  return { stats, connected };
}
